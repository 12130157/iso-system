--Table.sql

--Table_CUSTOMER_FILE_TYPE_Create.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CUSTOMER_FILE_TYPE]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[CUSTOMER_FILE_TYPE]
GO

CREATE TABLE [dbo].[CUSTOMER_FILE_TYPE] (
	[FILE_TYPE_ID] [int] NOT NULL ,
	[CUSTOMER_ID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO


GO

--Table_DIST_CODE_MAPPING_Create.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DIST_CODE_MAPPING]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DIST_CODE_MAPPING]
GO

CREATE TABLE [dbo].[DIST_CODE_MAPPING] (
	[REAL_DIST_CODE] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[PSEUDO_DIST_CODE] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO


GO

--Table_FILE_TYPE_Create.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FILE_TYPE]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FILE_TYPE]
GO

CREATE TABLE [dbo].[FILE_TYPE] (
	[FILE_TYPE_ID] [int] IDENTITY (1, 1) NOT NULL ,
	[TITLE] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PREFIX] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[EXTENSION] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DESC] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO


GO

--Table_PSEUDO_DIST_CODE_STATUS_Create.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PSEUDO_DIST_CODE_STATUS]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[PSEUDO_DIST_CODE_STATUS]
GO

CREATE TABLE [dbo].[PSEUDO_DIST_CODE_STATUS] (
	[PSEUDO_CODE] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[STATUS] [bit] NOT NULL 
) ON [PRIMARY]
GO


GO

--Table_UPLOAD_MASTERCODE_EVENTS_InsertNewField.sql
/*
  CODER : HUYNT4
  DATE : 25/9/2007
  PURPOSE : INSERT FILE_TYPE_ID COLUMN INTO TABLE 
*/
/*==============================================================*/
/* Add FILE_TYPE_ID column for tables VLACC , UPLOAD_MASTERCODE_EVENTS*/
/*==============================================================*/
IF NOT EXISTS ( SELECT *
  FROM syscolumns sc LEFT JOIN sysobjects so ON so.id = sc.id
  WHERE sc.name = 'FILE_TYPE_ID' AND so.name = 'VLACC')
BEGIN
 ALTER TABLE VLACC ADD FILE_TYPE_ID int NULL 
END
/*----------------------------------------*/
IF NOT EXISTS ( SELECT *
  FROM syscolumns sc LEFT JOIN sysobjects so ON so.id = sc.id
  WHERE sc.name = 'FILE_TYPE_ID' AND so.name = 'UPLOAD_MASTERCODE_EVENTS')
BEGIN
 ALTER TABLE UPLOAD_MASTERCODE_EVENTS ADD FILE_TYPE_ID int NULL 
END


GO

GO

GO




--sp_InsertPseudoCode.sql
declare @i as int
Set @i = 0
while @i < 10
begin 
	INSERT INTO dbo.PSEUDO_DIST_CODE_STATUS values('00' + Cast(@i as varchar),0)
	Set @i = @i + 1
end 

while (@i < 100)
begin
	INSERT INTO dbo.PSEUDO_DIST_CODE_STATUS values('0' + Cast(@i as varchar),0)
	Set @i = @i + 1
end
while (@i < 1000)
begin

	INSERT INTO dbo.PSEUDO_DIST_CODE_STATUS values(Cast(@i as varchar),0)
	Set @i = @i + 1
end

--select * from PSEUDO_DIST_CODE_STATUS 
--delete PSEUDO_DIST_CODE_STATUS
GO

--sp_Synchronyze_Mapping.sql
--Synchronyze PTRCM_DIST_STATUS & DIST_CODE_MAPPING

INSERT INTO DIST_CODE_MAPPING (REAL_DIST_CODE,PSEUDO_DIST_CODE)
SELECT CMCUST AS REAL_DIST_CODE,RIGHT(CMCUST,4) AS PSEUDO_DIST_CODE 
FROM PTRCM

UPDATE PSEUDO_DIST_CODE_STATUS
SET STATUS = 1 
WHERE PSEUDO_CODE IN (SELECT DISTINCT RIGHT(PSEUDO_DIST_CODE,3) AS PSEUDO_CODE FROM DIST_CODE_MAPPING)


--select * from PSEUDO_DIST_CODE_STATUS where status = 1
--select * from DIST_CODE_MAPPING
--SELECT * FROM PTRCM P INNER JOIN DIST_CODE_MAPPING DCM ON P.CMCUST = DCM.REAL_DIST_CODE INNER JOIN PTRCM_DIST_STATUS S ON DCM.PSEUDO_DIST_CODE = S.CMCUST

--select Top 1 * from PSEUDO_DIST_CODE_STATUS where status = 0
GO

--StoredProcedure.sql

--CreateCustFile.sql
/*
    CODER : HUYNT4
    DATE : 2/10/2007
   PURPOSE : CREATE NEW USER WITH FILE TYPE
*/

ALTER PROCEDURE CreateCustFile @FileType int, @FullName varchar(14)
AS


 IF @FileType > 0
            BEGIN    
                    BEGIN TRAN
                          INSERT INTO CUSTOMER_FILE_TYPE(FILE_TYPE_ID,CUSTOMER_ID)
                          VALUES(@FileType,@FullName)
                    IF @@ERROR<>0
                         BEGIN
                                 ROLLBACK TRAN                    
                                 RETURN
                        END
                    COMMIT TRAN

               END
GO

GO

--GetFileType.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetFileType]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetFileType]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/*
   CODER : HUYNT4
   DATE : 25/9/2007
   PURPOSE : GET FILE_TYPE_ID OF CUSTOMER THROUGH USER ACCOUNT
*/
CREATE PROCEDURE GetFileType @UserAcc varchar(14) 
 AS

SELECT FILE_TYPE_ID 
FROM CUSTOMER_FILE_TYPE 
WHERE CUSTOMER_ID LIKE @UserAcc
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--GetListCustCode.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetListCustCode]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetListCustCode]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


/*
   CODER : HUYNT4
   DATE    : 26/9/2007
   PURPOSE : GET PSEUDO CODE OF CUSTOMER THROUGH REGION CODE
*/

CREATE PROCEDURE GetListCustCode @Region int,@CustCode varchar(5),@CustName varchar(50),@Address varchar(100),@Active int
 AS

IF @Region > 0  
  BEGIN
         SELECT P.CMCUST AS CMCUST,CMCCON,ISNULL(PSEUDO_DIST_CODE,'') AS PSEUDO_CODE,(CMCAD1+CMCAD2+CMCAD3) AS ADDRESS
         FROM   PTRCM P LEFT JOIN (DIST_CODE_MAPPING M INNER JOIN PTRCM_DIST_STATUS S ON M.PSEUDO_DIST_CODE = S.CMCUST)
                                                          ON CAST(P.CMCUST AS VARCHAR(5)) = M.REAL_DIST_CODE
         
        WHERE  P.CMCUST LIKE '%' + @CustCode + '%' AND CMCCON  LIKE '%' + @CustName + '%'  AND (CMCAD1+CMCAD2+CMCAD3) LIKE '%' + @Address + '%'   
                       AND CAST(Left(right(P.CMCUST,4),1) AS INT)= @Region  AND ((@Active = 1 And ACTIVE = @Active) OR (@Active = 0 and (ACTIVE = 0 Or ACTIVE is null) ) )
        ORDER BY P.CMCUST 
  END
ELSE
     BEGIN
         SELECT P.CMCUST AS CMCUST,CMCCON,ISNULL(PSEUDO_DIST_CODE,'') AS PSEUDO_CODE, (CMCAD1+CMCAD2+CMCAD3) AS ADDRESS
         FROM  PTRCM P   LEFT JOIN (DIST_CODE_MAPPING M   INNER JOIN PTRCM_DIST_STATUS S ON M.PSEUDO_DIST_CODE = S.CMCUST)                                                      
                                       ON CAST(P.CMCUST AS VARCHAR(5)) = M.REAL_DIST_CODE

            WHERE  P.CMCUST LIKE '%' + @CustCode + '%' AND CMCCON  LIKE '%' + @CustName + '%'  AND (CMCAD1+CMCAD2+CMCAD3) LIKE '%' + @Address + '%'   AND ((@Active = 1 And ACTIVE = @Active) OR (@Active = 0 and (ACTIVE = 0 Or ACTIVE is null) ) )
         ORDER BY P.CMCUST 

     END
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--sp_ChangeStatus.sql
if exists (select * from dbo.sysobjects where id = object_id(N'sp_ChangeStatus') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp_ChangeStatus
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO
-- =============================================================================
-- Script  : sp_ChangeStatus.sql
-- Purpose :  Close week
--	     	 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		27-Sep-2007			Modified (INNER JOIN with DIST_CODE_MAPPING to get real dist code)

-- =============================================================================

CREATE PROCEDURE sp_ChangeStatus
(
@week int,
@year int,
@changelist varchar(4000) -- danh sach ma gia
)
AS
BEGIN
set nocount on
BEGIN TRANSACTION	
	DECLARE @strSQL nvarchar(4000)
	--Tao bang tam
	CREATE TABLE #TMP( UPLOADID NUMERIC(15,0))
	IF @@ERROR<>0 
		BEGIN 
			ROLLBACK 
			RETURN
		END

	Set  @strSQL = 	' INSERT INTO #TMP( UPLOADID )
			SELECT UPLOADID FROM UPLOAD_WEEKLY_EVENTS 
				WHERE (STATUS=5  OR STATUS=1 ) AND [WEEK]= ' + CAST(@week AS NVARCHAR(2)) + ' AND [YEAR]= '+ CAST(@year AS NVARCHAR(4)) + ' AND CMCUST IN (' + @changelist + ' ) '

	exec sp_executesql @strSQL	

	UPDATE UPLOAD_WEEKLY_EVENTS SET STATUS=0 , ISIMPORT=1 WHERE UPLOADID IN (SELECT UPLOADID FROM #TMP)
	
	--Insert record co trang thai Delete cho bang SS_WEEK_STS, ung voi tung NPP tung WEEK
	Set @strSQL=  N'UPDATE SS_WEEK_STS  
			SET  STATUS_DATE= GETDATE()
			WHERE [WEEK] = ' + CAST( @week AS VARCHAR(2)) +
				' AND [YEAR]= ' + CAST(@year AS VARCHAR(4)) + 
				 ' AND STATUS=''D'' AND SENDULV=''N''
				AND REGION_ID = LEFT(CMCUST,1)
				AND CMCUST IN  (' + @changelist + ') ' 

	--PRINT @strSQL
	EXEC ( @strSQL )

	Set @strSQL=  N'INSERT INTO SS_WEEK_STS([WEEK], [YEAR], REGION_ID, REGION_ABV, STATUS,  DIVISION, PROCESSED, SENDULV, STATUS_DATE , CMCUST) 
			SELECT ' + CAST(@week AS VARCHAR(2)) + ' AS [WEEK], '
				 + CAST( @year AS VARCHAR(4)) + ' AS [YEAR],  
				 LEFT(RIGHT(A.CMCUST,4), 1) AS REGION_ID ,
				 case LEFT(RIGHT(CMCUST,4), 1)  when 1 then ''HN''   
								when 2 then ''DD''
								when 3 then ''HE''
								when 4 then ''CT''
					 end AS REGION_ABV ,
				''D'' AS STATUS ,
				''''  AS DIVISION ,
				''N'' AS PROCESSED ,
				''N'' AS SENDULV,
				GETDATE() AS STATUS_DATE,	
				DCM.PSEUDO_DIST_CODE 
			FROM PTRCM A INNER JOIN DIST_CODE_MAPPING DCM ON A.CMCUST = DCM.REAL_DIST_CODE
			WHERE DCM.PSEUDO_DIST_CODE IN (' + @changelist + ')
				 AND DCM.PSEUDO_DIST_CODE NOT IN (SELECT CMCUST 
							FROM SS_WEEK_STS 
							WHERE [WEEK]= ' + CAST(@week as varchar(2)) + 
								' AND [YEAR]=' + CAST(@year AS VARCHAR(4))+
								' AND SENDULV=''N'' AND STATUS=''D'' )' 

	--PRINT @strSQL
	EXEC ( @strSQL )



COMMIT
END
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GO

--sp_ChangeStatusList.sql
if exists (select * from dbo.sysobjects where id = object_id(N'sp_ChangeStatusList') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp_ChangeStatusList
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

-- =============================================================================
-- Script  : sp_ChangeStatusList.sql
-- Purpose :  
--	     	 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		25-Sep-2007			Modified (INNER JOIN with DIST_CODE_MAPPING to get real dist code)
--									Replace RIGHT(PTRCM.CMCUST,4)		by DCM.PSEUDO_DIST_CODE

-- =============================================================================


CREATE PROCEDURE sp_ChangeStatusList
(
@week int,
@year int,
@region int,
@account varchar(60)
)
AS
BEGIN
set nocount on

if @account=''
	BEGIN
		IF  @region<>-100 		  
			    SELECT DISTINCT PTRCM.CMCUST,DCM.PSEUDO_DIST_CODE, PTRCM.CMCNME , 
					AA.ORIGINNAME , AA.UPDATETIME ,AA.UPLOADID, AA.STATUS
					, BB.APPROVEDBY
	        	    FROM (((PTRCM INNER JOIN DIST_CODE_MAPPING DCM ON PTRCM.CMCUST = DCM.REAL_DIST_CODE 
								LEFT JOIN PTRCM_DIST_STATUS ON  DCM.PSEUDO_DIST_CODE = PTRCM_DIST_STATUS.CMCUST )
					LEFT JOIN
		         			(SELECT * FROM UPLOAD_WEEKLY_EVENTS
		                  		WHERE ([Week] = @week  OR [Week] is null)
		                  		AND ([Year]= @year OR [year] is null)) AA
		          			ON DCM.PSEUDO_DIST_CODE =AA.CMCUST )
		          		LEFT JOIN 
						WEEKLY_REPORT_STATISTIC BB 
		         			ON AA.[WEEK] = BB.[WEEK] AND AA.[YEAR] = BB.[YEAR] AND AA.CMCUST = BB.CMCUST )
	
					LEFT JOIN WEEKLY_REOPEN_WEEK C ON C.CMCUST= DCM.PSEUDO_DIST_CODE AND C.[YEAR]=@year AND C.[WEEK]=@week
					LEFT JOIN WEEKLY_CLOSED_WEEK D ON D.WR_REGION=@region AND D.WR_YEAR=@year AND D.WR_WEEK=@week
	
	
		 	WHERE LEFT(DCM.PSEUDO_DIST_CODE,1)= @region AND (PTRCM_DIST_STATUS.ACTIVE IS NULL OR PTRCM_DIST_STATUS.ACTIVE=1 ) AND ( AA.STATUS=5 OR  AA.STATUS=1)
				AND (C.CMCUST IS NOT NULL OR D.WR_YEAR IS NULL)
			ORDER BY PTRCM.CMCUST 
	
		ELSE --All region
			 SELECT DISTINCT PTRCM.CMCUST,DCM.PSEUDO_DIST_CODE, PTRCM.CMCNME , 
					AA.ORIGINNAME , AA.UPDATETIME ,AA.UPLOADID, AA.STATUS
					, BB.APPROVEDBY
	        	    FROM (((PTRCM INNER JOIN DIST_CODE_MAPPING DCM ON PTRCM.CMCUST = DCM.REAL_DIST_CODE
							LEFT JOIN PTRCM_DIST_STATUS ON  DCM.PSEUDO_DIST_CODE = PTRCM_DIST_STATUS.CMCUST )
					LEFT JOIN
		         			(SELECT * FROM UPLOAD_WEEKLY_EVENTS
		                  		WHERE ([Week] = @week  OR [Week] is null)
		                  		AND ([Year]= @year OR [year] is null)) AA
		          			ON DCM.PSEUDO_DIST_CODE = AA.CMCUST )
		          		LEFT JOIN 	WEEKLY_REPORT_STATISTIC BB 
		         			ON AA.[WEEK] = BB.[WEEK] AND AA.[YEAR] = BB.[YEAR] AND AA.CMCUST = BB.CMCUST )
					LEFT JOIN WEEKLY_REOPEN_WEEK C ON C.CMCUST = DCM.PSEUDO_DIST_CODE AND C.[YEAR]=@year AND C.[WEEK]=@week
					LEFT JOIN WEEKLY_CLOSED_WEEK D ON D.WR_REGION=LEFT(DCM.PSEUDO_DIST_CODE,1)  AND D.WR_YEAR=@year AND D.WR_WEEK=@week
	
		 	WHERE (PTRCM_DIST_STATUS.ACTIVE IS NULL OR PTRCM_DIST_STATUS.ACTIVE=1 ) AND ( AA.STATUS=5  OR  AA.STATUS=1)
				AND (C.CMCUST IS NOT NULL OR D.WR_YEAR IS NULL)
			ORDER BY PTRCM.CMCUST 
	END
ELSE
	BEGIN
		if  @region<>-100 		  
			    SELECT DISTINCT PTRCM.CMCUST,DCM.PSEUDO_DIST_CODE, PTRCM.CMCNME , 
					AA.ORIGINNAME , AA.UPDATETIME ,AA.UPLOADID, AA.STATUS
					, BB.APPROVEDBY
	        	    FROM ((((PTRCM INNER JOIN DIST_CODE_MAPPING DCM ON PTRCM.CMCUST = DCM.REAL_DIST_CODE
							LEFT JOIN PTRCM_DIST_STATUS ON  DCM.PSEUDO_DIST_CODE = PTRCM_DIST_STATUS.CMCUST )
					LEFT JOIN
		         			(SELECT * FROM UPLOAD_WEEKLY_EVENTS
		                  		WHERE ([Week] = @week  OR [Week] is null)
		                  		AND ([Year]= @year OR [year] is null)) AA
		          			ON DCM.PSEUDO_DIST_CODE = AA.CMCUST )
		          		LEFT JOIN 
						WEEKLY_REPORT_STATISTIC BB 
		         			ON AA.[WEEK] = BB.[WEEK] AND AA.[YEAR] = BB.[YEAR] AND AA.CMCUST = BB.CMCUST )
	
					LEFT JOIN WEEKLY_REOPEN_WEEK C ON C.CMCUST = DCM.PSEUDO_DIST_CODE AND C.[YEAR]=@year AND C.[WEEK]=@week
					LEFT JOIN WEEKLY_CLOSED_WEEK D ON D.WR_REGION=@region AND D.WR_YEAR=@year AND D.WR_WEEK=@week )
					INNER JOIN VLACM ON PTRCM.CMCUST=VLACM.USERCODE				
	
		 	WHERE LEFT(DCM.PSEUDO_DIST_CODE,1)= @region AND (PTRCM_DIST_STATUS.ACTIVE IS NULL OR PTRCM_DIST_STATUS.ACTIVE=1 ) AND ( AA.STATUS=5 OR  AA.STATUS=1)
				AND (C.CMCUST IS NOT NULL OR D.WR_YEAR IS NULL)
				
				AND VLACM.ACCNAME=@account
	
			ORDER BY PTRCM.CMCUST 
	
		else --All region
			 SELECT DISTINCT PTRCM.CMCUST,DCM.PSEUDO_DIST_CODE, PTRCM.CMCNME , 
					AA.ORIGINNAME , AA.UPDATETIME ,AA.UPLOADID, AA.STATUS
					, BB.APPROVEDBY
	        	    FROM ((((PTRCM INNER JOIN DIST_CODE_MAPPING DCM ON PTRCM.CMCUST = DCM.REAL_DIST_CODE
							LEFT JOIN PTRCM_DIST_STATUS ON  DCM.PSEUDO_DIST_CODE = PTRCM_DIST_STATUS.CMCUST )
					LEFT JOIN
		         			(SELECT * FROM UPLOAD_WEEKLY_EVENTS
		                  		WHERE ([Week] = @week  OR [Week] is null)
		                  		AND ([Year]= @year OR [year] is null)) AA
		          			ON DCM.PSEUDO_DIST_CODE = AA.CMCUST )
		          		LEFT JOIN 
						WEEKLY_REPORT_STATISTIC BB 
		         			ON AA.[WEEK] = BB.[WEEK] AND AA.[YEAR] = BB.[YEAR] AND AA.CMCUST = BB.CMCUST )
					LEFT JOIN WEEKLY_REOPEN_WEEK C ON C.CMCUST = DCM.PSEUDO_DIST_CODE AND C.[YEAR]=@year AND C.[WEEK]=@week
					LEFT JOIN WEEKLY_CLOSED_WEEK D ON D.WR_REGION=LEFT(DCM.PSEUDO_DIST_CODE , 1)  AND D.WR_YEAR=@year AND D.WR_WEEK=@week)
					
					INNER JOIN VLACM ON PTRCM.CMCUST=VLACM.USERCODE				
	
		 	WHERE (PTRCM_DIST_STATUS.ACTIVE IS NULL OR PTRCM_DIST_STATUS.ACTIVE=1 ) AND ( AA.STATUS=5  OR  AA.STATUS=1)
				AND (C.CMCUST IS NOT NULL OR D.WR_YEAR IS NULL)
	
				AND VLACM.ACCNAME=@account
	
			ORDER BY PTRCM.CMCUST 
	END

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--sp_CloseWeek.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_CloseWeek]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_CloseWeek]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
-- =============================================================================
-- Script  : sp_CloseWeek.sql
-- Purpose :  Close week
--	     	 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		26-Sep-2007			Modified (INNER JOIN with DIST_CODE_MAPPING to get real dist code)

-- =============================================================================


CREATE     proc sp_CloseWeek (	
	@region int,	
	@week int,	
	@year int,	
	@Accname varchar(14),	
	@Desc varchar(255),	
	@ret_code int = 0 output
)	
AS	
BEGIN	
	SET NOCOUNT ON	
	----------------------------	
	DECLARE @bookmark INT	
	DECLARE @Nyear INT	
	DECLARE @NWeek INT	
	DECLARE @cmcust NUMERIC(5,0)	
		
	DECLARE @stryearweek VARCHAR(6)	
	DECLARE @uploadid NUMERIC(15,0)	
	DECLARE @id NUMERIC(15,0)	
	DECLARE @tocode NUMERIC(5,0)	
	DECLARE @missing_list VARCHAR(4000)	
	DECLARE @count INT	
	----------------------------	
	set @ret_code = 0

	IF @week=52	
		BEGIN	
			SET @Nweek=1	
			SET @Nyear=@year+1	
		END	
	ELSE	
		BEGIN	
			SET @Nweek=@week+1	
			SET @Nyear= @year	
		END	
		
		
	IF EXISTS(SELECT * FROM WEEKLY_CLOSED_WEEK WHERE WR_REGION=@region AND WR_WEEK=@week AND WR_YEAR=@year AND STATUS='0' )	
	BEGIN	
		Set @bookmark=51	
		INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
		VALUES(@year, @week, @region, @bookmark, 'Tuan W'+ CONVERT(VARCHAR(5), @week) + '-'+ CONVERT(VARCHAR(5), @year) + 'da dong !' )	
		RETURN	
	END	
		
		
	--SYCHRONYZE 2 bang PTRCM vTRCM_DIST_STATUS	
	exec SP_SYNCHRONIZE 'VIETLINK'	
		
	--kiem tra tat ca các báo cáo phai có trang thái: "APPROVED, GUI VE ULV, REJECTED, NULL" 
	CREATE TABLE #DIST_STATUS_TMP (CMCUST NUMERIC(5,0) , STATUS INT NULL, HOLD NUMERIC(5,0) NULL, TER NUMERIC(5,0) NULL, CHANGECODE NUMERIC(5,0) NULL, UPLOADID NUMERIC(15,0) NULL, ISIMPORT NUMERIC(1,0) NULL )	
		
	INSERT INTO #DIST_STATUS_TMP(CMCUST, STATUS, HOLD, TER,CHANGECODE, UPLOADID, ISIMPORT )	
		SELECT A.CMCUST , B.STATUS, D.CMCUST AS HOLD, E.CMCUST AS TER, F.TOCODE AS CHANGECODE, B.UPLOADID AS UPLOADID, B.ISIMPORT AS ISIMPORT	
		FROM (((((PTRCM A INNER JOIN DIST_CODE_MAPPING DCM ON A.CMCUST = DCM.REAL_DIST_CODE
			--Thanhnq modified 
			--LEFT JOIN UPLOAD_WEEKLY_EVENTS B ON RIGHT(A.CMCUST,4)=B.CMCUST AND B.[WEEK]=@week AND B.[YEAR]=@year)
			LEFT JOIN UPLOAD_WEEKLY_EVENTS B ON DCM.PSEUDO_DIST_CODE = B.CMCUST AND B.[WEEK]=@week AND B.[YEAR]=@year)	
			LEFT JOIN PTRCM_DIST_STATUS C ON DCM.PSEUDO_DIST_CODE = C.CMCUST)	
			LEFT JOIN PTRCM_TERMINATE_STATUS E ON A.CMCUST=E.CMCUST AND E.[YEAR]=@year AND E.[WEEK]=@week)	
			LEFT JOIN PTRCM_HOLD_STATUS D ON A.CMCUST=D.CMCUST AND ((D.[YEAR]*100+ D.[WEEK])<= (@year*100+@week))AND E.CMCUST IS NULL )	
			LEFT JOIN PTRCM_CHANGE_CODE F ON A.CMCUST=F.CMCUST AND F.[YEAR]=@Nyear AND F.[WEEK]=@Nweek)	
			LEFT JOIN PTRCM_CHANGE_CODE G ON A.CMCUST=G.TOCODE AND (G.[YEAR]*100+ G.[WEEK])>( @year*100 + @week)	
		WHERE (C.ACTIVE=1 OR C.ACTIVE IS NULL) AND LEFT(RIGHT(A.CMCUST,4),1)=@region AND G.TOCODE IS NULL	
		
		
	if @@error<>0	
	BEGIN	
		ROLLBACK	
		Set @bookmark=50	
		INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
		VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (Khong the lay duoc thong tin trang thai cua cac khach hang)')	
		set @ret_code = @@error
		RETURN @ret_code
	END	
	
	
	/*-------------------------------------------------------------------------------*/	
	/*--Check status all reports ----------------------------------------------------*/	
	/*-------------------------------------------------------------------------------*/	
	-- "APPROVED, GUI VE ULV, REJECTED, NULL, LOI TD-TC, CHECNH LECH TD-TC"	
	IF EXISTS(SELECT CMCUST FROM #DIST_STATUS_TMP WHERE (STATUS<>1 AND STATUS<>5 AND STATUS<>2 AND STATUS IS NOT NULL AND STATUS<>3 AND NOT(STATUS=0 AND ISIMPORT=2) ))	
	BEGIN	
		Set @bookmark=1	
		INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
		VALUES(@year, @week, @region, @bookmark, 'Co bao cao pending ')	
		set @ret_code = 10
		RETURN @ret_code
	END	
		
/*-------------------------------------------------------------------------------*/	
/*--Create temporary table, the same structure as WEEKLY_DATA table -------------*/	
/*-------------------------------------------------------------------------------*/	
	
		CREATE TABLE #WEEKLY_DATA_TMP (	
		[UPLOADID] NUMERIC(15,0) NULL ,	
		[DIVISION] [varchar] (50) NULL ,	
		[PRCODE] [varchar] (50) NULL ,	
		[DESC] [varchar] (50) NULL ,	
		[COLOR] [varchar] (50) NULL ,	
		[SIZE] [varchar] (50) NULL ,	
		[MEASURE] [varchar] (50) NULL ,	
		[PACKAGE] [varchar] (50) NULL ,	
		[UNIT] [varchar] (50) NULL ,	
		[TONDT1] [numeric](15, 2) NULL ,	
		[TONDT2] [numeric](15, 2) NULL ,	
		[NHANTT] [numeric](15, 2) NULL ,	
		[NHANTTO] [numeric](15, 2) NULL ,	
		[TONCT1] [numeric](15, 2) NULL ,	
		[TONCT2] [numeric](15, 2) NULL ,	
		[BANTT] [numeric](15, 2) NULL ,	
		[BANTTO] [numeric](15, 2) NULL ,	
		[DATHANG1] [numeric](15, 2) NULL ,	
		[DATHANG2] [numeric](15, 2) NULL ,	
		[DIEUCHINH] [numeric](15, 2) NULL ,	
		[THUCDAT1] [numeric](15, 2) NULL ,	
		[THUCDAT2] [numeric](15, 2) NULL ,	
		[NHANTT3] [numeric](15, 2) NULL ,	
		[BANTT3] [numeric](15, 2) NULL ,	
		[DONGIA] [numeric](15, 2) NULL ,	
		[CASEQTY] [numeric](18, 3) NULL ,	
		[NETWEIGHT] [numeric](18, 3) NULL,	
		[AMOUNT] [NUMERIC](18,0) NULL	
		)	
			
			
		BEGIN TRANSACTION	
			
		/*-------------------------------------------------------------------------------------*/	
		/*--All ClosingOpening error is loged -------------------------------------------------*/	
		/*-------------------------------------------------------------------------------------*/	
			
		/*Insert into Weekly_report_Error_stock*/	
		INSERT INTO WEEKLY_REPORT_ERROR_STOCK(CMCUST, [WEEK], [YEAR], STATUS)	
		SELECT distinct CMCUST, @week, @year, 1 --Status=1: Is not repoen for these custs	
		FROM #DIST_STATUS_TMP	
		WHERE (UPLOADID IS NOT NULL) AND STATUS=3	
			
		/*-------------------------------------------------------------------------------------*/	
		/*--Retrieve all missing_report customers, exclude Hold and Terminate cust -------------*/	
		/*-------------------------------------------------------------------------------------*/	
			
		SET @missing_list=''	
			
		/*Insert into WEEKLY_REPORT_MISSING_DATA, to trace all missing_report customer*/	
		INSERT INTO WEEKLY_REPORT_MISSING_DATA(CMCUST, [WEEK], [YEAR], STATUS)	
		SELECT distinct CMCUST, @week, @year, 1 --Status=1: Is not repoen for these custs	
		FROM #DIST_STATUS_TMP	
		WHERE (UPLOADID IS NULL) AND (HOLD IS NULL) AND (TER IS NULL)	
			
		INSERT INTO WEEKLY_REPORT_MISSING_DATA(CMCUST, [WEEK], [YEAR], STATUS)	
		SELECT distinct CMCUST, @week, @year, 2	
		FROM #DIST_STATUS_TMP	
		WHERE ( ISIMPORT=2 ) AND (HOLD IS NULL) AND (TER IS NULL)	
			
			
		DECLARE curCustHold CURSOR FORWARD_ONLY	
		FOR SELECT CMCUST FROM #DIST_STATUS_TMP	
		WHERE (UPLOADID IS NULL) AND (HOLD IS NOT NULL) AND (TER IS NULL) AND (CHANGECODE IS NULL)	
			
		OPEN curCustHold	
		FETCH NEXT FROM curCustHold INTO @cmcust	
			
		WHILE @@FETCH_STATUS = 0	
		BEGIN	
			
		--Co lieu trong HouseKeeping week hay kg?	
		--Thanhnq modified
		--IF  EXISTS(SELECT UPLOADID FROM UPLOAD_WEEKLY_EVENTS  WHERE CMCUST=RIGHT(@cmcust,4) AND (([YEAR]*100 + [WEEK])< (@year*100 + @week))     )
		IF  EXISTS(SELECT UPLOADID FROM UPLOAD_WEEKLY_EVENTS U INNER JOIN DIST_CODE_MAPPING DCM ON U.CMCUST = DCM.PSEUDO_DIST_CODE WHERE DCM.REAL_DIST_CODE = @cmcust AND (([YEAR]*100 + [WEEK])< (@year*100 + @week)) )	
		BEGIN	
			--Tu tuan gan nhat co lieu dung	
			SELECT @stryearweek = CAST( MAX(YEAR*100 + WEEK) AS VARCHAR(6))	
			--Thanhnq modified
			--FROM UPLOAD_WEEKLY_EVENTS
			--WHERE CMCUST= RIGHT(@cmcust,4) AND STATUS IN (1,5) AND (([YEAR]*100 + [WEEK])< (@year*100 + @week))  
			FROM UPLOAD_WEEKLY_EVENTS U INNER JOIN DIST_CODE_MAPPING DCM ON U.CMCUST = DCM.PSEUDO_DIST_CODE 
			WHERE DCM.REAL_DIST_CODE = @cmcust AND STATUS IN (1,5) AND (([YEAR]*100 + [WEEK])< (@year*100 + @week))	
			
			
			--Tu uploadid cac tuan gan nhat co lieu	
			SELECT @uploadid=UPLOADID	
			--Thanhnq modified
			--FROM UPLOAD_WEEKLY_EVENTS	
			--WHERE CMCUST=RIGHT(@cmcust,4)AND [WEEK]=RIGHT(@stryearweek,2) AND [YEAR]=LEFT(@stryearweek,4)	
			FROM UPLOAD_WEEKLY_EVENTS U INNER JOIN DIST_CODE_MAPPING DCM ON U.CMCUST = DCM.PSEUDO_DIST_CODE 
			WHERE  DCM.REAL_DIST_CODE = @cmcust AND [WEEK]=RIGHT(@stryearweek,2) AND [YEAR]=LEFT(@stryearweek,4)	
			
			if @@error<>0	
			BEGIN	
				ROLLBACK	
				Set @bookmark=2	

				INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
				VALUES(@year, @week, @region, @bookmark, 'Khach hang co nhieu bao cao trong mot tuan')	
				set @ret_code = @@error
				RETURN @ret_code

			END	
			
		--Roll du lieu Upload_weekly_events	
		INSERT INTO UPLOAD_WEEKLY_EVENTS ([UPDATETIME],[WEEK],[YEAR],[USERID],[CMCUST],[FILEPATH],[FILENAME],[ORIGINNAME],[ISIMPORT],[STATUS] ,[DESC],[EMAIL], comment)	
		SELECT [UPDATETIME],@week,@year,[USERID],[CMCUST],[FILEPATH],[FILENAME],[ORIGINNAME],0 ,0 ,[DESC],[EMAIL], [comment] --set Approved	
		FROM UPLOAD_WEEKLY_EVENTS	
		WHERE UPLOADID=@uploadid	
			
		--Lay UPLOADID moi sinh	
		Set @id = @@IDENTITY	
			
		--Set Approved(tranh fire triger anh huong den @IDentity)	
		UPDATE UPLOAD_WEEKLY_EVENTS SET STATUS=1 WHERE UPLOADID=@id	
			
		if @@error<>0	
		BEGIN	
			ROLLBACK	
			Set @bookmark=3	
			INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
			VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (Khong the keo du lieu trong bang Upload_weekly_events)')	
			set @ret_code = @@error
			RETURN @ret_code

			--RETURN	
		END	
			
		--Roll phan Header và Weekly_header_data và UPLOADID moi	
		INSERT INTO WEEKLY_HEADER_DATA ( [UPLOADID],[FromDate],[ToDate],[TenGSMV],[BanTTuan],[CongDon] ,[TTNoNPP],[CTYNoNPP],[GTTKBan],[GTTKHH],[NPPNoCty],[VonHDNPP],[TongCong])	
		SELECT @id,[FromDate],[ToDate],[TenGSMV],0 ,[CongDon] ,[TTNoNPP],[CTYNoNPP],[GTTKBan],[GTTKHH],[NPPNoCty],[VonHDNPP],[TongCong]	
		FROM WEEKLY_HEADER_DATA	
		WHERE UPLOADID= @uploadid	
		if @@error<>0	
		BEGIN	
			ROLLBACK	
			Set @bookmark=4	
			INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
			VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (Khong the keo du lieu trong bang Weekly_header_data)')	
			set @ret_code = @@error
			RETURN @ret_code
		END	
	
		-- Insert du lieu vbang tam	
		INSERT INTO #WEEKLY_DATA_TMP( [UPLOADID] ,[DIVISION],[PRCODE],[DESC],[COLOR], [SIZE], [MEASURE], [PACKAGE],[UNIT] ,	
		[DATHANG1],[DATHANG2],[DIEUCHINH],[THUCDAT1], [THUCDAT2],[DONGIA], [CASEQTY], [NETWEIGHT] , [AMOUNT],	
		[NHANTT] ,[NHANTTO] ,[NHANTT3] ,[BANTT] ,[BANTTO] , [BANTT3] ,	
		[TONDT1] ,[TONDT2] , [TONCT1] ,[TONCT2] )	
		SELECT @id ,[DIVISION],[PRCODE],[DESC],[COLOR], [SIZE], [MEASURE], [PACKAGE],[UNIT] ,	
		[DATHANG1],[DATHANG2],[DIEUCHINH],[THUCDAT1], [THUCDAT2],[DONGIA], [CASEQTY], 0 , 0 ,	
		0,0,0,0,0,0, --khong nhap, khong ban	
		[TONCT1] ,[TONCT2],[TONCT1] ,[TONCT2]	
		FROM WEEKLY_DATA	
		WHERE UPLOADID = @uploadid	
			
		if @@error<>0	
		BEGIN	
			ROLLBACK	
			Set @bookmark=6	
			INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
			VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (Khong the thao tac du llieu tren bang tam)')	
			
			set @ret_code = @@error
			RETURN @ret_code

--			RETURN	
		END	
		END	
			
		FETCH NEXT FROM curCustHold INTO @cmcust	
		END --While	
		CLOSE curCustHold	
		DEALLOCATE curCustHold	
			
		
	DECLARE curCustTer CURSOR FORWARD_ONLY	
	FOR SELECT CMCUST FROM #DIST_STATUS_TMP	
	WHERE (UPLOADID IS NULL OR (STATUS NOT IN (1,5)) OR STATUS =2 ) AND (TER IS NOT NULL) AND (CHANGECODE IS NULL)	
		
	OPEN curCustTer	
	FETCH NEXT FROM curCustTer INTO @cmcust	
		
	WHILE @@FETCH_STATUS = 0	
	BEGIN	
		
		--Co du lieu trong HouseKeeping hay kg?	
		--Thanhnq modified
		--IF  EXISTS(SELECT UPLOADID FROM UPLOAD_WEEKLY_EVENTS WHERE CMCUST=RIGHT(@cmcust,4)AND (([YEAR]*100 + [WEEK])< (@year*100 + @week)) )	
		IF 	EXISTS(SELECT UPLOADID FROM UPLOAD_WEEKLY_EVENTS U INNER JOIN DIST_CODE_MAPPING DCM ON U.CMCUST = DCM.PSEUDO_DIST_CODE 
				WHERE DCM.REAL_DIST_CODE = @cmcust AND (([YEAR]*100 + [WEEK])< (@year*100 + @week)) )	
			BEGIN	
				--Tinh tuan gan nhat co data
				SELECT @stryearweek = CAST( MAX(YEAR*100 + WEEK) AS VARCHAR(6))	
				--Thanhnq modified
				--FROM UPLOAD_WEEKLY_EVENTS	
				--WHERE CMCUST= RIGHT(@cmcust,4) AND STATUS IN (1,5) AND (([YEAR]*100 + [WEEK])< (@year*100 + @week))	
				FROM UPLOAD_WEEKLY_EVENTS U INNER JOIN DIST_CODE_MAPPING DCM ON U.CMCUST = DCM.PSEUDO_DIST_CODE 
				WHERE DCM.REAL_DIST_CODE = @cmcust AND STATUS IN (1,5) AND (([YEAR]*100 + [WEEK])< (@year*100 + @week))	
					
				SELECT @uploadid=UPLOADID	
				--Thanhnq modified
				--FROM UPLOAD_WEEKLY_EVENTS	
				--WHERE CMCUST=RIGHT(@cmcust,4)AND [WEEK]=RIGHT(@stryearweek,2) AND [YEAR]=LEFT(@stryearweek,4)	
				FROM UPLOAD_WEEKLY_EVENTS U INNER JOIN DIST_CODE_MAPPING DCM ON U.CMCUST = DCM.PSEUDO_DIST_CODE 
				WHERE DCM.REAL_DIST_CODE = @cmcust AND [WEEK]=RIGHT(@stryearweek,2) AND [YEAR]=LEFT(@stryearweek,4)	
					
				if @@error<>0	
					BEGIN	
						ROLLBACK	
						Set @bookmark=12	
						INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
						VALUES(@year, @week, @region, @bookmark, 'Khach hang co nhieu bao cao trong mot tuan')	
						set @ret_code = @@error
						RETURN @ret_code
				
						--RETURN	
					END	
				
				--Roll data c?a Upload_weekly_events	
				INSERT INTO UPLOAD_WEEKLY_EVENTS ([UPDATETIME],[WEEK],[YEAR],[USERID],[CMCUST],[FILEPATH],[FILENAME],[ORIGINNAME],[ISIMPORT],[STATUS] ,[DESC],[EMAIL], [COMMENT])	
				SELECT [UPDATETIME],@week,@year,[USERID],[CMCUST],[FILEPATH],[FILENAME],[ORIGINNAME],0 ,0 ,[DESC],[EMAIL], [COMMENT]	
				FROM UPLOAD_WEEKLY_EVENTS	
				WHERE UPLOADID=@uploadid	
					
				--Lay Uploadid moi sinh	
				Set @id = @@IDENTITY	
					
				--Cap nhat trang thai(tranh fire trigger anh huong den @IDENTITY )	
				UPDATE UPLOAD_WEEKLY_EVENTS SET STATUS=1 WHERE UPLOADID=@ID	
					
				if @@error<>0	
					BEGIN	
						ROLLBACK	
						Set @bookmark=13	
						INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
						VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (Khong the keo du lieu trong bang Upload_weekly_events)')	
						--	RETURN	
						set @ret_code = @@error
						RETURN @ret_code
				
					END	
					
				--Insert data vào b?ng t?m, bao dam TON CUOI =0
				INSERT INTO #WEEKLY_DATA_TMP( [UPLOADID] ,[DIVISION],[PRCODE],[DESC],[COLOR], [SIZE], [MEASURE], [PACKAGE],[UNIT] ,	
					[DATHANG1],[DATHANG2],[DIEUCHINH],[THUCDAT1], [THUCDAT2],[DONGIA], [CASEQTY], [NETWEIGHT] ,[AMOUNT],	
					[NHANTT] ,[NHANTTO] ,[NHANTT3] ,[BANTT] ,[BANTTO] , [BANTT3] ,	
					[TONDT1] ,[TONDT2] , [TONCT1] ,[TONCT2] )	
				SELECT @id ,[DIVISION],[PRCODE],[DESC],[COLOR], [SIZE], [MEASURE], [PACKAGE],[UNIT] ,	
					[DATHANG1],[DATHANG2],[DIEUCHINH],[THUCDAT1], [THUCDAT2],[DONGIA], [CASEQTY],isnull((((([BANTT]+[TONCT1])+ [BANTT3])/WEEKLY_DESC.PCS_PER_CASE )*WEEKLY_DESC.NET_WEIGHT), 0) AS [NETWEIGHT] ,((([BANTT]+[TONCT1])+ [BANTT3] )*[DONGIA]) AS [AMOUNT],	
					0,0,0, ([BANTT]+[TONCT1]) AS [BANTT] , ([BANTTO]+[TONCT2]) AS [BANTTO] ,[BANTT3],	
					[TONCT1] ,[TONCT2],0,0	
				FROM WEEKLY_DATA LEFT JOIN WEEKLY_DESC ON WEEKLY_DATA.PRCODE=WEEKLY_DESC.P_ID	
				WHERE UPLOADID = @uploadid	
					
				if @@error<>0	
					BEGIN	
						ROLLBACK	
						Set @bookmark=16	
						INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
						VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (Khong the thao tac du llieu tren bang tam)')	
						set @ret_code = @@error
						RETURN @ret_code
				
						--RETURN	
					END	
					
					
				
				INSERT INTO WEEKLY_HEADER_DATA ( [UPLOADID],[FromDate],[ToDate],[TenGSMV],[CongDon] ,[TTNoNPP],[CTYNoNPP],[GTTKBan],[GTTKHH],[NPPNoCty],[VonHDNPP],[TongCong], [BanTTuan])	
				SELECT @id , A.[FromDate],A.[ToDate],A.[TenGSMV],A.[CongDon] ,A.[TTNoNPP],A.[CTYNoNPP],A.[GTTKBan],A.[GTTKHH],A.[NPPNoCty],A.[VonHDNPP],A.[TongCong], SUM(B.AMOUNT) AS [BanTTuan]	
				FROM WEEKLY_HEADER_DATA A LEFT JOIN #WEEKLY_DATA_TMP B ON A.UPLOADID = B.UPLOADID	
				WHERE A.UPLOADID= @uploadid	
				GROUP BY A.[FromDate],A.[ToDate],A.[TenGSMV],A.[CongDon] ,A.[TTNoNPP],A.[CTYNoNPP],A.[GTTKBan],A.[GTTKHH],A.[NPPNoCty],A.[VonHDNPP],A.[TongCong]	
					
				if @@error<>0	
					BEGIN	
						ROLLBACK	
						Set @bookmark=14	
						INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
						VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (Khong the keo du lieu trong bang Weekly_header_data)')	
						set @ret_code = @@error
						RETURN @ret_code
				
						--RETURN	
					END	
						
			END	--IF
		
		FETCH NEXT FROM curCustTer INTO @cmcust	
	END --While	
	CLOSE curCustTer	
	DEALLOCATE curCustTer	
		
	--Cac NPP co bao cao duoc Approved, ma TON CUOI <> 0 , thi chuyen thanh so SALE	
	DECLARE curCustTerHaveReport CURSOR FORWARD_ONLY	
		FOR SELECT UPLOADID FROM #DIST_STATUS_TMP	
				WHERE (UPLOADID IS NOT NULL) AND( STATUS IN (1,5) ) AND (TER IS NOT NULL) AND (CHANGECODE IS NULL)	

		
	OPEN curCustTerHaveReport	
	FETCH NEXT FROM curCustTerHaveReport INTO @uploadid	
		
	WHILE @@FETCH_STATUS = 0	
	BEGIN	
		IF EXISTS (SELECT * FROM WEEKLY_DATA WHERE UPLOADID=@uploadid AND ([TONCT1]<>0 OR TONCT2<>0))	
		BEGIN	
			--Insert data vào b?ng t?m, bao dam TON CUOI =0
			INSERT INTO #WEEKLY_DATA_TMP( [UPLOADID] ,[DIVISION],[PRCODE],[DESC],[COLOR], [SIZE], [MEASURE], [PACKAGE],[UNIT] ,	
				[DATHANG1],[DATHANG2],[DIEUCHINH],[THUCDAT1], [THUCDAT2],[DONGIA], [CASEQTY], [NETWEIGHT] , [AMOUNT],	
				[NHANTT] ,[NHANTTO] ,[NHANTT3] ,[BANTT] ,[BANTTO] , [BANTT3] ,	
				[TONDT1] ,[TONDT2] , [TONCT1] ,[TONCT2] )	
			SELECT UPLOADID ,[DIVISION],[PRCODE],[DESC],[COLOR], [SIZE], [MEASURE], [PACKAGE],[UNIT] ,	
				[DATHANG1],[DATHANG2],[DIEUCHINH],[THUCDAT1], [THUCDAT2],[DONGIA], [CASEQTY], [NETWEIGHT] , ((([BANTT] + [TONCT1]) + [BANTT3])*[DONGIA] )AS [AMOUNT],	
				0,0,0, ([BANTT] + [TONCT1])AS [BANTT] , ([BANTTO]+[TONCT2]) AS [BANTTO] , [BANTT3] ,	
				[TONDT1] ,[TONDT2], 0, 0	
			FROM WEEKLY_DATA	
			WHERE UPLOADID = @uploadid	
				
			if @@error<>0	
				BEGIN	
					ROLLBACK	
					Set @bookmark=18	
					INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
					VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (Khong the thao tac du lieu tren bang tam)')	
					--RETURN	
					set @ret_code = @@error
					RETURN @ret_code
			
				END	
			--Xoa du lieu (da duoc copy sang bang tam )	
			DELETE WEEKLY_DATA WHERE UPLOADID = @uploadid	
			
		END	
		
		FETCH NEXT FROM curCustTerHaveReport INTO @uploadid	
	END --while	
	CLOSE curCustTerHaveReport	
	DEALLOCATE curCustTerHaveReport	
		
	--Inactivate terminate customers	
	UPDATE PTRCM_DIST_STATUS	
	SET ACTIVE=0	
	WHERE CMCUST IN (SELECT /*RIGHT(CMCUST,4)*/ DCM.PSEUDO_DIST_CODE AS CMCUST FROM #DIST_STATUS_TMP A INNER JOIN DIST_CODE_MAPPING DCM ON A.CMCUST = DCM.REAL_DIST_CODE WHERE A.TER IS NOT NULL )	
		
	if @@error<>0	
		BEGIN	
			ROLLBACK	
			Set @bookmark=19	
			INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
			VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (Khong the NGUNG HOAT DONG cac khach hang bi Terminate)')	
			set @ret_code = @@error
			RETURN @ret_code
	
		--RETURN	
		END	
		
		
	/*-------------------------------------------------------------------------------------*/	
	/*--Change code A->B ------------------------------------------------------------------*/	
	/*-------------------------------------------------------------------------------------*/	
		
	DECLARE curCustChangeCode CURSOR FORWARD_ONLY	
		FOR SELECT CMCUST, CHANGECODE FROM #DIST_STATUS_TMP WHERE (CHANGECODE IS NOT NULL)AND(HOLD IS NULL)AND(TER IS NULL)	
		
	OPEN curCustChangeCode	
	FETCH NEXT FROM curCustChangeCode INTO @cmcust, @tocode	
		
	WHILE @@FETCH_STATUS = 0	
	BEGIN	
		
		-- Delete old data in Upload_Weekly_events, Weekly_header_data, weekly_data	
		DELETE FROM WEEKLY_DATA WHERE UPLOADID IN (SELECT UPLOADID FROM UPLOAD_WEEKLY_EVENTS WHERE CMCUST=RIGHT(@tocode,4))	
			
		DELETE FROM WEEKLY_HEADER_DATA WHERE UPLOADID IN (SELECT UPLOADID FROM UPLOAD_WEEKLY_EVENTS WHERE CMCUST=RIGHT(@tocode,4))	
			
		DELETE FROM UPLOAD_WEEKLY_EVENTS WHERE UPLOADID IN (SELECT UPLOADID FROM UPLOAD_WEEKLY_EVENTS WHERE CMCUST=RIGHT(@tocode,4))	
			
		--Insert du lieu tu A sang B	
		DECLARE curUpLoadId CURSOR FORWARD_ONLY	
			FOR SELECT U.UPLOADID FROM UPLOAD_WEEKLY_EVENTS U 
				INNER JOIN DIST_CODE_MAPPING DCM ON U.CMCUST = DCM.PSEUDO_DIST_CODE 
				WHERE DCM.REAL_DIST_CODE = @cmcust AND (([YEAR]*100+ [WEEK])<= (@year*100 + @week)) --4 Tuan truoc	
			
			
		OPEN curUpLoadId	
		FETCH NEXT FROM curUpLoadId INTO @uploadid	
			
		WHILE @@FETCH_STATUS = 0	
		BEGIN	
			--Copy data c?a Upload_weekly_events	
			INSERT INTO UPLOAD_WEEKLY_EVENTS ([UPDATETIME],[WEEK],[YEAR],[USERID],[CMCUST],[FILEPATH],[FILENAME],[ORIGINNAME],[ISIMPORT],[STATUS] ,[DESC],[EMAIL], [COMMENT])	
			SELECT [UPDATETIME],[WEEK],[YEAR],[USERID],/*RIGHT(@tocode,4)*/DCM.PSEUDO_DIST_CODE ,[FILEPATH],[FILENAME],[ORIGINNAME],[ISIMPORT] ,0 ,[DESC],[EMAIL], [COMMENT]	
			FROM UPLOAD_WEEKLY_EVENTS	, DIST_CODE_MAPPING DCM 
			WHERE UPLOADID = @uploadid AND DCM.REAL_DIST_CODE = @tocode
				
			--Lay UPLOADID moi sinh	
			Set @id = @@IDENTITY	
				
			--set  gui ve ULV",tranh fire trigger , anh huong den @IDENTITY	
			UPDATE UPLOAD_WEEKLY_EVENTS SET STATUS=5 WHERE UPLOADID=@ID	
				
			if @@error<>0	
				BEGIN	
					ROLLBACK	
					Set @bookmark=23	
					INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
					VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (A->B : Khong the keo du lieu trong bang Upload_weekly_events)')	
					--RETURN	
					set @ret_code = @@error
					RETURN @ret_code
			
				END	
				
			
			INSERT INTO WEEKLY_HEADER_DATA ( [UPLOADID],[FromDate],[ToDate],[TenGSMV],[BanTTuan],[CongDon] ,[TTNoNPP],[CTYNoNPP],[GTTKBan],[GTTKHH],[NPPNoCty],[VonHDNPP],[TongCong])	
			SELECT @id,[FromDate],[ToDate],[TenGSMV],[BanTTuan],[CongDon] ,[TTNoNPP],[CTYNoNPP],[GTTKBan],[GTTKHH],[NPPNoCty],[VonHDNPP],[TongCong]	
			FROM WEEKLY_HEADER_DATA	
			WHERE UPLOADID= @uploadid	
			if @@error<>0	
			BEGIN	
				ROLLBACK	
				Set @bookmark=24	
				INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
				VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (A->B : Khong the keo du lieu trong bang Weekly_header_data)')	
				set @ret_code = @@error
				RETURN @ret_code
		
			--RETURN	
			END	
				
				
			--copy data vào b?ng t?m
			INSERT INTO #WEEKLY_DATA_TMP( [UPLOADID] ,[DIVISION],[PRCODE],[DESC],[COLOR], [SIZE], [MEASURE], [PACKAGE],[UNIT] ,	
				[DATHANG1],[DATHANG2],[DIEUCHINH],[THUCDAT1], [THUCDAT2],[DONGIA], [CASEQTY], [NETWEIGHT] ,[AMOUNT],	
				[NHANTT] ,[NHANTTO] ,[NHANTT3] ,[BANTT] ,[BANTTO] , [BANTT3] ,	
				[TONDT1] ,[TONDT2] , [TONCT1] ,[TONCT2] )	
			SELECT @id ,[DIVISION],[PRCODE],[DESC],[COLOR], [SIZE], [MEASURE], [PACKAGE],[UNIT] ,	
				[DATHANG1],[DATHANG2],[DIEUCHINH],[THUCDAT1], [THUCDAT2],[DONGIA], [CASEQTY], [NETWEIGHT] , [AMOUNT],	
				[NHANTT] ,[NHANTTO] ,[NHANTT3] ,[BANTT] ,[BANTTO] , [BANTT3] ,	
				[TONDT1] ,[TONDT2] , [TONCT1] ,[TONCT2]	
			FROM WEEKLY_DATA	
			WHERE UPLOADID = @uploadid	
				
			if @@error<>0	
			BEGIN	
				ROLLBACK	
				Set @bookmark=26	
				INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
				VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (A->B : Khong the thao tac du lieu tren bang tam)')	
				set @ret_code = @@error
				RETURN @ret_code
		
			--RETURN	
			END	
				
			FETCH NEXT FROM curUpLoadId INTO @uploadid	
		END --While	
	CLOSE curUpLoadId	
	DEALLOCATE curUpLoadId	
		
	FETCH NEXT FROM curCustChangeCode INTO @cmcust, @tocode	
	END --While	
	CLOSE curCustChangeCode	
	DEALLOCATE curCustChangeCode	
		
	--Inactive Code A	
	UPDATE PTRCM_DIST_STATUS	
	SET ACTIVE =0	
	--Thanhnq modified
	--WHERE CMCUST IN (SELECT RIGHT(CMCUST,4) AS CMCUST FROM #DIST_STATUS_TMP 
	WHERE CMCUST IN (SELECT DCM.PSEUDO_DIST_CODE AS CMCUST FROM #DIST_STATUS_TMP DST INNER JOIN DIST_CODE_MAPPING DCM ON DST.CMCUST = DCM.REAL_DIST_CODE
					 WHERE (CHANGECODE IS NOT NULL))--AND(HOLD IS NULL)AND(TER IS NULL) )	
			
	if @@error<>0	
		BEGIN	
			ROLLBACK	
			Set @bookmark=27	
			INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
			VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (A->B : Khong the NGUNG HOAT DONG ma A)')	
			--RETURN	
			set @ret_code = @@error
			RETURN @ret_code
	
		END	
			
			
		/*----------------------------------------------------------------------------------------------------------------------*/	
		/*--Chuyen data tu bang ta.m #WEEKLY_DATA_TMP sang bang chinh Weekly_data ---------------------------------------------*/	
		/*----------------------------------------------------------------------------------------------------------------------*/	
			
	INSERT INTO WEEKLY_DATA( [UPLOADID] ,[DIVISION],[PRCODE],[DESC],[COLOR], [SIZE], [MEASURE], [PACKAGE],[UNIT] ,	
		[DATHANG1],[DATHANG2],[DIEUCHINH],[THUCDAT1], [THUCDAT2],[DONGIA], [CASEQTY], [NETWEIGHT] , [AMOUNT],	
		[NHANTT] ,[NHANTTO] ,[NHANTT3] ,[BANTT] ,[BANTTO] , [BANTT3] ,	
		[TONDT1] ,[TONDT2] , [TONCT1] ,[TONCT2] )	
	SELECT [UPLOADID] ,[DIVISION],[PRCODE],[DESC],[COLOR], [SIZE], [MEASURE], [PACKAGE],[UNIT] ,	
		[DATHANG1],[DATHANG2],[DIEUCHINH],[THUCDAT1], [THUCDAT2],[DONGIA], [CASEQTY], [NETWEIGHT] , [AMOUNT],	
		[NHANTT] ,[NHANTTO] ,[NHANTT3] ,[BANTT] ,[BANTTO] , [BANTT3] ,	
		[TONDT1] ,[TONDT2] , [TONCT1] ,[TONCT2]	
	FROM #WEEKLY_DATA_TMP	
		
	if @@error<>0	
		BEGIN	
			ROLLBACK	
			Set @bookmark= 7	
			INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
			VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (Khong the do du lieu tu bang tam sang Weekly_data)')	
			set @ret_code = @@error
			RETURN @ret_code
		END	
	/*----------------------------------------------------------------------------------------------------------------------*/	
	/*--Sinh template tuan sau cho code B khi A->B--------------------------------------------------------------------------*/	
	/*----------------------------------------------------------------------------------------------------------------------*/	
		
	DELETE WEEKLY_REPORT_TEMPLATE	
	--Thanhnq modified
	--WHERE CMCUST IN (SELECT RIGHT(CHANGECODE,4) FROM #DIST_STATUS_TMP 	
	WHERE CMCUST IN (SELECT DCM.PSEUDO_DIST_CODE AS CMCUST FROM #DIST_STATUS_TMP DST INNER JOIN DIST_CODE_MAPPING DCM ON DST.CHANGECODE = DCM.REAL_DIST_CODE
					 WHERE (CHANGECODE IS NOT NULL) AND(HOLD IS NULL)AND(TER IS NULL) )	
		
	if @@error<>0	
		BEGIN	
			ROLLBACK	
			Set @bookmark= 100	
			INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
			VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu.(Khong the xoa cac mau bao cao cu cua ma moi (khi doi ma) )')	
			set @ret_code = @@error
			RETURN @ret_code
		END	
		
	INSERT INTO WEEKLY_REPORT_TEMPLATE(CMCUST, WR_YEAR, WR_WEEK, WR_STATUS, WR_FILENAME, UpdatedDate, tpl_version )	
	SELECT /*RIGHT(A.CHANGECODE,4)*/DCM.PSEUDO_DIST_CODE ,@NYear, @NWeek , '0' ,'', GETDATE(),1	
	--Thanhnq modified
	--FROM #DIST_STATUS_TMP A 
	FROM #DIST_STATUS_TMP A INNER JOIN DIST_CODE_MAPPING DCM ON A.CHANGECODE = DCM.REAL_DIST_CODE
	--INNER JOIN PTRCM_DIST_STATUS B ON RIGHT(A.CHANGECODE,4)= B.CMCUST	
	INNER JOIN PTRCM_DIST_STATUS B  ON DCM.PSEUDO_DIST_CODE = B.CMCUST
	WHERE (A.CHANGECODE IS NOT NULL) AND(A.HOLD IS NULL)AND(A.TER IS NULL)	
		AND B.ACTIVE=1 AND (B.DMS_FLAG='0' OR B.GEN_TPL='1')	
		
	if @@error<>0	
		BEGIN	
			ROLLBACK	
			Set @bookmark= 10	
			INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
			VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu.(Khong the sinh mau bao cao cho ma moi)')	
			set @ret_code = @@error
			RETURN @ret_code
		END	
		
	--Truong hop REOPEN, cap nhat lai template	
	--tang version cho template tuan sau	
	UPDATE WEEKLY_REPORT_TEMPLATE	
	SET TPL_VERSION=TPL_VERSION+1 , WR_FILENAME = '', WR_STATUS='0' , UpdatedDate=GETDATE()	
	WHERE WR_WEEK=@Nweek AND WR_YEAR=@Nyear	
		AND CMCUST IN ( SELECT CMCUST FROM WEEKLY_REOPEN_WEEK	
						WHERE [WEEK]=@week AND [YEAR]=@year AND LEFT(CMCUST,1)=@region )	
	if @@error<>0	
		BEGIN	
			ROLLBACK	
			Set @bookmark= 11	
			INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
			VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu.(Khong the cap nhat version mau bao cao khi mo lai tuan )')	
			set @ret_code = @@error
			RETURN @ret_code
		END	
		
	--Insert data voi nhung NPP chua co template trong tuan	
	INSERT INTO WEEKLY_REPORT_TEMPLATE(CMCUST, WR_YEAR, WR_WEEK, WR_STATUS, WR_FILENAME, UpdatedDate, tpl_version )	
	--Thanhnq modified
	--SELECT RIGHT(A.CMCUST,4) ,@NYear, @NWeek , '0' ,'', GETDATE(),1
	SELECT DCM.PSEUDO_DIST_CODE ,@NYear, @NWeek , '0' ,'', GETDATE(),1	
	--FROM (PTRCM A 
			--LEFT JOIN PTRCM_DIST_STATUS B ON RIGHT(A.CMCUST,4)=B.CMCUST)	
	FROM (PTRCM A INNER JOIN DIST_CODE_MAPPING DCM ON A.CMCUST = DCM.REAL_DIST_CODE  
			LEFT JOIN PTRCM_DIST_STATUS B ON DCM.PSEUDO_DIST_CODE=B.CMCUST)
		 	--LEFT JOIN WEEKLY_REPORT_TEMPLATE C ON RIGHT(A.CMCUST,4) = C.CMCUST AND C.WR_WEEK= @NWeek AND C.WR_YEAR=@NYear
			LEFT JOIN WEEKLY_REPORT_TEMPLATE C ON DCM.PSEUDO_DIST_CODE = C.CMCUST AND C.WR_WEEK= @NWeek AND C.WR_YEAR=@NYear	

	WHERE LEFT(RIGHT(A.CMCUST,4),1) = @region AND ( B.CMCUST IS NULL OR ( B.ACTIVE=1 AND (B.DMS_FLAG ='0' OR B.GEN_TPL='1' )))	
		AND C.CMCUST IS NULL	
		
	if @@error<>0	
		BEGIN	
			ROLLBACK	
			Set @bookmark= 9	
			INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
			VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu.(Khong the tao mau bao cao)')	
			set @ret_code = @@error
			RETURN @ret_code
		END	
	/*----------------------------------------------------------------------------------------------------------------------*/	
	
	/*----------------------------------------------------------------------------------------------------------------------*/	
		
	--Xoá data trong b?ng Reopen.
	DELETE WEEKLY_REOPEN_WEEK	
	WHERE [WEEK]=@week AND [YEAR]=@year AND LEFT(CMCUST,1)=@region	
		
	if @@error<>0	
	BEGIN	
		ROLLBACK	
		Set @bookmark=32	
		INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
		VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu. (Khong the xoa du lieu trong bang Weekly_reopen_week)')	
		set @ret_code = @@error
		RETURN @ret_code
	END	
		
	/*----------------------------------------------------------------------------------------------------------------------*/	
	/*--Set trang thai de Gui ve ULV ---------------------------------------------------------------------------------------*/	
	/*----------------------------------------------------------------------------------------------------------------------*/	
		
	IF EXISTS (SELECT * FROM SS_WEEK_STS WHERE [WEEK]=@week AND [YEAR]=@year AND [REGION_ID]=@region AND SENDULV='N' AND (STATUS='R' OR STATUS='C') )	
		BEGIN	
			UPDATE SS_WEEK_STS SET STATUS='C', STATUS_DATE = GETDATE()	
			WHERE [WEEK]=@week AND [YEAR]=@year AND [REGION_ID]=@region AND SENDULV='N' AND (STATUS='R' OR STATUS='C')	
		END	
	ELSE	
		BEGIN	
			INSERT INTO SS_WEEK_STS([WEEK], [YEAR], REGION_ID, REGION_ABV, STATUS, DIVISION, PROCESSED, SENDULV, STATUS_DATE)	
			VALUES(@week , @year ,	
			@region , case @region 	when 1 then 'HN'	
									when 2 then 'DD'	
									when 3 then 'HE'	
									when 4 then 'CT'	
									end ,	
			'C', '' ,'N','N', getdate() )	
		END	
		
		
	/*----------------------------------------------------------------------------------------------------------------------*/	
	/*--Insert vbang Weekly_closed_week ---------------------------------------------------------------------------------*/	
	/*----------------------------------------------------------------------------------------------------------------------*/	
		
	IF NOT EXISTS(SELECT * FROM WEEKLY_CLOSED_WEEK WHERE WR_WEEK=@week AND WR_YEAR=@year AND WR_REGION=@region)	
		INSERT INTO WEEKLY_CLOSED_WEEK(WR_YEAR, WR_WEEK, WR_REGION, STATUS, ACCNAME, CLOSED_DATE,UPDATED_ACC, UPDATED_DATE, CLOSE_DESC)	
		VALUES (@year, @week, @region, 0, @Accname, getdate(), @Accname, getdate(), @desc )	
	ELSE	
		UPDATE WEEKLY_CLOSED_WEEK	
		SET STATUS=0 , UPDATED_ACC=@Accname , UPDATED_DATE=getdate(),CLOSE_DESC=@desc	
		WHERE WR_YEAR=@year AND WR_WEEK=@week AND WR_REGION=@region	
		
	if @@error<>0	
		BEGIN	
			ROLLBACK	
			Set @bookmark= 8	
			INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
			VALUES(@year, @week, @region, @bookmark, 'Loi Co so du lieu.(Khong the cap nhat thong tin dong tuan)')	
			set @ret_code = @@error
			RETURN @ret_code
		END	
		
	--Write status of Close Week function
	Set @bookmark= 100		
	INSERT INTO WEEKLY_CLOSE_LOG([YEAR], [WEEK], REGION, BOOKMARK, [DESC])	
	VALUES(@year, @week, @region, @bookmark, 'Close week successful')	
			
	COMMIT	
	set @ret_code = 0
	RETURN @ret_code

END --main	


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--sp_ErrorReport.sql
if exists (select * from sysobjects where id = object_id(N'sp_ErrorReport') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp_ErrorReport
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO
-- =============================================================================
-- Script  : sp_ErrorReport.sql
-- Purpose :  
--	     	 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		27-Sep-2007			Modified (INNER JOIN with DIST_CODE_MAPPING to get real dist code)
--												replace RIGHT(CMCUST,4) by DCM.PSEUDO_DIST_CODE

-- =============================================================================

create proc sp_ErrorReport (
@sortby int,
@FromDate NUMERIC(6,0),
@ToDate NUMERIC(6,0),
@region int,
@dms int,
@active int,
@errorType int
)
AS
BEGIN

	SELECT  B.UPLOADID AS [ID] ,  CASE LEFT(A.CMCUST ,1)	WHEN 1 THEN 'NORTH'
									WHEN 2 THEN 'CENTER'
									WHEN 3 THEN 'HCME'
									WHEN 4 THEN 'MeKongDelta' 
									ELSE '' END AS REGION , 
	        ISNULL(E.TENGSMV,'') AS SUP,
		A.CMCUST AS CMCODE, 
		ISNULL(C.CMCNME,'') AS CMNME,
		A.[WEEK] AS [WEEK], 
		'dinh dang Loi' AS ERRORFORMAT ,
		'nguon bc' AS ERRORSOURCE , 
		LEFT(A.UPDATETIME,10) AS UPLOADDATE, 
		ISNULL(A.USERID,'') AS UPLOAD_ACC
	FROM (((UPLOAD_WEEKLY_ERROR B LEFT JOIN UPLOAD_WEEKLY_EVENTS A ON   A.UPLOADID=B.UPLOADID) 
		 LEFT JOIN (PTRCM C INNER JOIN DIST_CODE_MAPPING DCM ON C.CMCUST = DCM.REAL_DIST_CODE )ON DCM.PSEUDO_DIST_CODE = A.CMCUST )LEFT JOIN PTRCM_DIST_STATUS D ON A.CMCUST=D.CMCUST)
		LEFT JOIN WEEKLY_HEADER_DATA E ON E.UPLOADID=B.UPLOADID
	WHERE CAST((A.[YEAR]*100 +A.[WEEK]) AS VARCHAR(6)) BETWEEN @FromDate and @ToDate
		AND LEFT(A.CMCUST ,1)= @region
		AND D.DMS_FLAG=@dms
		AND D.ACTIVE=@active
		--AND ERRORTYPE= @errorType
	ORDER BY E.TENGSMV
	--ORDER BY  A.CMCUST 	
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--sp_ExportMissingData.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_ExportMissingData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_ExportMissingData]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

-- =============================================================================
-- Script  : sp_CloseWeek.sql
-- Purpose :  Close week
--	     	 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		26-Sep-2007			Modified (INNER JOIN with DIST_CODE_MAPPING to get real dist code)

-- =============================================================================


CREATE   PROCEDURE sp_ExportMissingData 

AS
BEGIN 
	DECLARE @serverName varchar(50) 
	DECLARE @databaseName varchar(50) 
	DECLARE @strPass varchar(255) 
	DECLARE @strUserName varchar(50) 
	DECLARE @IsFileExist smallint 
	DECLARE @strPath varchar(100) 
	DECLARE @strFilename varchar(255) 
	DECLARE @bcpCommand varchar(2000) 

	DECLARE @intReturn int 
	DECLARE @isStopWeb decimal(9, 0) 
	DECLARE @isStopApp decimal(9, 0) 
	/** Calculate Period week*/

	DECLARE @HKYear 	INT
	DECLARE @HKWeek 	INT
	DECLARE @DEF_HKWeek INT
	DECLARE @CurWeek 	INT
	DECLARE @CurYear 	INT

	/*
	SET @strPath = 'D:\Working\Export\' 
	SET @serverName = 'trieulv' 
	SET @databaseName= 'Vietlink' 
	SET @strUserName ='sa' 
	SET @strPass = '' 
	*/
	
	SET @strPath='E:\Unilink\Customer\Vietnam\ApprovedDataSingapore\' 
	SET @serverName= 'DMZSSQL10003' 
	SET @databaseName= 'VietLink' 
	SET @strUserName ='vietuser' 
	SET @strPass = 'vietuser' 
	

	/*Get Current week, current year*/

	SELECT  @CurWeek= CONVERT(INT, SUBSTRING(TIER_1,2,2)) , @CurYear = CONVERT(INT, TIER_4)
	FROM BKM_0_X
	WHERE TIER_0 = CONVERT( VARCHAR(8), (GETDATE()-7) , 112)

	--SET @CurWeekYear = CONVERT(CHAR(6), @CurYear*100 + @CurWeek )

	/*Get HouseKeeping_period definition*/
	SELECT @DEF_HKWeek = CONVERT(INT, NVALUE)
	FROM SYSTEM_PARAMETERS	
	WHERE DEFNAME LIKE 'DEF_HOUSEKEEPING_PERIOD'
	
	/*Calculate Houskeeping time in database*/
	SET @HKWeek = 0
	SET @HKYear = 0

	IF ((@CurWeek - @DEF_HKWeek) <=0 )
	BEGIN
		SET @HKWeek = 52 + (@CurWeek - @DEF_HKWeek)
		SET @HKYear = @CurYear-1
	END	
	ELSE
	BEGIN
		SET @HKWeek = @CurWeek - @DEF_HKWeek
		SET @HKYear = @CurYear
	END

	SET @strFilename = @strPath + 'MissingDataList.LST' 

	SET @intReturn = 0 
	-- Get current varibale of application 
	--SELECT @isStopWeb = NVALUE FROM SYSTEM_PARAMETERS WHERE DEFNAME = 'DEF_WEBAPP_PAUSE' 
	--SELECT @isStopApp = NVALUE FROM SYSTEM_PARAMETERS WHERE DEFNAME = 'DEF_PROGRAM_PAUSE' 
	-- Disable application 
	--IF @isStopWeb = 0 
	--	UPDATE SYSTEM_PARAMETERS SET NVALUE = 1 WHERE DEFNAME = 'DEF_WEBAPP_PAUSE' 
	--IF @isStopApp = 0 
	--	UPDATE SYSTEM_PARAMETERS SET NVALUE = 1 WHERE DEFNAME = 'DEF_PROGRAM_PAUSE' 
	-- Check export folder exists or not 
	CREATE TABLE #FileExists(
		DoesExists int, 
		FileIsDir int, 
		DirExists int) 

	IF (@@ERROR <> 0) GOTO Error_End 

	INSERT INTO #FileExists EXEC master..xp_fileexist @strPath 

	IF (@@ERROR <> 0) GOTO Error_End 

	IF EXISTS (SELECT DoesExists FROM #FileExists FE WHERE FE.FileIsDir = 1 AND FE.DirExists = 1) 
		SET @IsFileExist = 1 

	ELSE 
		SET @IsFileExist = 0 


	DROP TABLE #FileExists 

	IF (@@ERROR <> 0) GOTO Error_End 
	 
	 
	 -- If output folder is not exist then exit SP with error  
	IF @IsFileExist <> 1 BEGIN 
	 	SET @intReturn = -1 
	 	GOTO Normal_End 
	END 

	BEGIN TRANSACTION

		--Insert data from WEEKLY_REPOPRT_MISSING_DATA table
	TRUNCATE TABLE VL_WEEKLY_MISSING_DATA_EXPORT

	INSERT INTO VL_WEEKLY_MISSING_DATA_EXPORT
	(
	 CMCUST,[WR_WEEK],[WR_YEAR], CUSTNAME, CUSTPHONE, SUPNAME, SUPPHONE, ASMNAME,ASMPHONE, STATUS
	)

	SELECT /*RIGHT(BB.CMCUST,4)*/BB.PSEUDO_DIST_CODE AS CMCUST,BB.[WEEK] AS WR_WEEK, BB.[YEAR] AS WR_YEAR
			, ISNULL (LEFT(BB.CUSTNAME,50),'') AS CUSTNAME
			, ISNULL (LEFT(BB.CUSTPHONE,20),'') AS CUSTPHONE
			, ISNULL (LEFT(BB.SUPNAME,50),'' )  AS SUPNAME
			, ISNULL (LEFT(BB.SUPPHONE,20),'')  AS SUPPHONE
			, ISNULL (LEFT(A.ACCNAME,50),'')    AS ASMNAME
			, ISNULL (LEFT(A.PHONE,20),'') 	   AS ASMPHONE
			, '0' AS STATUS
	FROM VLACC A
		INNER JOIN VL_ASM_ACCOUNTS B
			ON A.ACCNAME = B.ACCNAME
		
		RIGHT JOIN  (
		
			SELECT AA.PSEUDO_DIST_CODE,AA.CMCUST, AA.[WEEK], AA.[YEAR], AA.CUSTNAME, AA.CUSTPHONE, ISNULL (A.ACCNAME,'') AS SUPNAME, ISNULL (A.PHONE,'') AS SUPPHONE 
			
			FROM VLACC A 
				INNER JOIN VL_SALESUP_ACCOUNTS B
					ON A.ACCNAME = B.ACCNAME
				RIGHT JOIN 		
					(
						SELECT B.PSEUDO_DIST_CODE,A.CMCUST, B.[WEEK], B.[YEAR], CONVERT (VARCHAR,A.CMCNME) AS CUSTNAME, CONVERT(VARCHAR,LEFT(A.CMPHON,20)) AS CUSTPHONE
						FROM PTRCM A
									
							INNER JOIN ( SELECT DISTINCT E.CMCUST,DCM.PSEUDO_DIST_CODE, E.[WEEK], E.[YEAR]
										 FROM WEEKLY_REPORT_MISSING_DATA E INNER JOIN DIST_CODE_MAPPING DCM ON E.CMCUST = DCM.REAL_DIST_CODE
										 INNER JOIN PTRCM_DIST_STATUS Z 
												--ON RIGHT(E.CMCUST,4) = Z.CMCUST
												ON DCM.PSEUDO_DIST_CODE = Z.CMCUST
										 WHERE (1 =1 )	AND E.STATUS = 0
												AND (E.[YEAR] *100 + E.[WEEK] > @HKYear*100 + @HKWeek)
												AND Z.ACTIVE = 1
										 		
												AND E.CMCUST NOT IN 
												(
													--Get Holding distributor list
													SELECT DISTINCT CMCUST
													FROM PTRCM_HOLD_STATUS
													WHERE [YEAR] * 100 + [WEEK] <=  @HKYear*100 + @HKWeek
												)							
					
							) B
								ON A.CMCUST = B.CMCUST

					) AA
				ON B.USERCODE = AA.CMCUST
		) BB
		
		ON B.USERNAME = BB.SUPNAME
		AND (BB.[YEAR] *100 + BB.[WEEK] > @HKYear*100 + @HKWeek)
		
		SET @bcpCommand = 'bcp "SELECT CMCUST, [WEEK], CUSTNAME, CUSTPHONE, SUPNAME, SUPPHONE, ASMNAME, ASMPHONE FROM ' + @databaseName + '..vwExportMissingData" queryout '  
		SET @bcpCommand = @bcpCommand + '"' + @strFilename + '" -t " " -S '+ @serverName +' -U '+ @strUserName +' -P '+ @strPass +' -c' 

	--	Print @bcpCommand
	-- Export week need to open or close  
	EXEC master..xp_cmdshell @bcpCommand 

	IF (@@ERROR <> 0) GOTO Error_End 
	 
	 
	COMMIT TRANSACTION 

 
Error_End: 
 
	SET @intReturn = @@ERROR
	 
	IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION 
	 
Normal_End: 
 
	-- Restore cuurent status of application 
RETURN @intReturn 
 
END


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--sp_ListAllTel.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_ListAllTel]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_ListAllTel]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO
-- =============================================================================
-- Script  : sp_ListAllTel.sql
-- Purpose :  
--	     	 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		26-Sep-2007			Modified (INNER JOIN with DIST_CODE_MAPPING to get real dist code)

-- =============================================================================

create proc sp_ListAllTel(
	@curDate varchar(10)--current date
)
AS
BEGIN
	SET NOCOUNT ON
	-----------------------------------------
	DECLARE @curWeek varchar(10)--current week

	set @curWeek = (select tier_1 from bkm_0_x where tier_0=@curDate)
	--LAY HOLD
	create table #hold_temp (holdcode numeric(5,0))
	INSERT INTO #HOLD_TEMP(HOLDCODE) 
	SELECT CMCUST FROM PTRCM_HOLD_STATUS
				WHERE [WEEK]=LEFT(RIGHT(@CURWEEK,7),2)
				AND [YEAR] = RIGHT(@CURWEEK,4)
				AND CMCUST NOT IN (SELECT CMCUST FROM PTRCM_TERMINATE_STATUS)
	--LAT TERMINATE
	CREATE TABLE #TERMINATE_TEMP (TERCODE NUMERIC(5,0))
	INSERT INTO #TERMINATE_TEMP (TERCODE)
	SELECT CMCUST FROM PTRCM
	WHERE CMCUST IN (SELECT CMCUST FROM PTRCM_TERMINATE_STATUS)
	--------------------------------------------------------
	--******************--

	CREATE TABLE #RESULT (
		CMCUST NUMERIC(5,0)
		,DISTNAME VARCHAR(30)
		,ACCNAME VARCHAR(14)
		,ACTIVE VARCHAR(1)
		,TYPE VARCHAR(1)
		,CMCAD1 VARCHAR(100)
		,CUSTPHONE VARCHAR(25)
		,SUPNAME VARCHAR(14)
		,SUPPHONE VARCHAR(25)
		,ASMNAME VARCHAR(14)
		,ASMPHONE VARCHAR(25)
		,HOLDCODE NUMERIC(5,0)
		,TERCODE NUMERIC(5,0)
	)
	INSERT INTO #RESULT(CMCUST,DISTNAME,ACCNAME,ACTIVE,TYPE,CMCAD1,CUSTPHONE
		,SUPNAME,SUPPHONE,ASMNAME,ASMPHONE,HOLDCODE,TERCODE)
	SELECT A.CMCUST, A.CMCNME AS DISTNAME, C.ACCNAME
	,ISNULL(B.ACTIVE,'0') AS ACTIVE
	,ISNULL(B.DMS_FLAG,'0') AS TYPE,A.CMCAD1, C.PHONE AS CUSTPHONE 
	, D.ACCNAME AS SUPNAME, D.PHONE AS SUPPHONE
	,D.ASMNAME,D.ASMPHONE 
	,H.CMCUST
	,T.CMCUST
--Thanhnq modified 27-Sep-2007
FROM PTRCM A INNER JOIN DIST_CODE_MAPPING DCM ON A.CMCUST = DCM.REAL_DIST_CODE
--INNER JOIN PTRCM_DIST_STATUS B ON RIGHT(A.CMCUST,4) = B.CMCUST 
INNER JOIN PTRCM_DIST_STATUS B ON DCM.PSEUDO_DIST_CODE = B.CMCUST 
-----------------------------------------------------------------------
LEFT JOIN (SELECT CMCUST FROM PTRCM_HOLD_STATUS
	WHERE CMCUST NOT IN (SELECT CMCUST FROM PTRCM_TERMINATE_STATUS)
	--AND [WEEK] = LEFT(RIGHT(@CURWEEK,7),2) AND [YEAR] = RIGHT(@CURWEEK,4)) H
	AND [YEAR]*100+[WEEK] >=RIGHT(@CURWEEK,4)*100+LEFT(RIGHT(@CURWEEK,7),2)) H
ON A.CMCUST = H.CMCUST
--**************
LEFT JOIN (
--declare @curweek varchar(14)
--set @curweek = 'wr20_2006'
SELECT CMCUST FROM PTRCM_TERMINATE_STATUS
		WHERE [YEAR]*100+[WEEK] >=RIGHT(@CURWEEK,4)*100+LEFT(RIGHT(@CURWEEK,7),2)
) T
ON A.CMCUST = T.CMCUST
----------------------------------------------------------------------
LEFT JOIN ( SELECT C.ACCNAME,C.USERCODE, D.PHONE FROM VLACM C 
		INNER JOIN VLACC D ON C.ACCNAME = D.ACCNAME AND D.USERTYPE = 'CUSTOMER' ) C 
		ON C.USERCODE = A.CMCUST 
		LEFT JOIN ( 
			SELECT * FROM (
				SELECT A.*, B.PHONE 
				FROM VL_SALESUP_ACCOUNTS A 
				INNER JOIN VLACC B ON A.ACCNAME = B.ACCNAME ) C 
			LEFT JOIN (
				SELECT A.ACCNAME AS ASMNAME, A.USERNAME,B.PHONE AS ASMPHONE 
				FROM VL_ASM_ACCOUNTS A 
				INNER JOIN VLACC B ON A.ACCNAME = B.ACCNAME) D 
				ON C.ACCNAME = D.USERNAME ) D 
			ON A.CMCUST = D.USERCODE 
			WHERE 1 = 1 
--AND A.CMCUST = '21149'
AND ISNULL(T.CMCUST,0) <> 0
ORDER BY A.CMCUST

SELECT * FROM #RESULT
	
DROP TABLE #HOLD_TEMP
DROP TABLE #TERMINATE_TEMP
DROP TABLE #RESULT
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--sp_ListSupASMNPPTel.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_ListSupASMNPPTel]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_ListSupASMNPPTel]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

-- =============================================================================
-- Script  : sp_ListSupASMNPPTel.sql
-- Purpose :  
--	     	 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		25-Sep-2007			Modified (INNER JOIN with DIST_CODE_MAPPING to get real dist code)
--												Replace RIGHT(A.CMCUST,4) by DCM.PSEUDO_DIST_CODE

-- =============================================================================


CREATE   proc sp_ListSupASMNPPTel(
	@REGION VARCHAR(1)
	,@TYPE VARCHAR(1)
	,@STATUS VARCHAR(1)
	,@HOLD VARCHAR(1)
	,@TER VARCHAR(1)
)
AS
	BEGIN
		SET NOCOUNT ON
		-----------------------------------------
		DECLARE @curWeek varchar(10)--current week
		DECLARE @CON VARCHAR(1000)
	
		DECLARE @OLD_CMCUST NUMERIC(5,0)
		DECLARE @OLD_DISTNAME VARCHAR(30)
		DECLARE @OLD_ACCNAME VARCHAR(14)
		DECLARE @OLD_ACTIVE VARCHAR(1)
		DECLARE @OLD_DMS VARCHAR(1)
		DECLARE @OLD_ADDR VARCHAR(100)
		DECLARE @OLD_CUSTPHONE VARCHAR(1000)
		DECLARE @OLD_SUPNAME VARCHAR(14)
		DECLARE @OLD_SUPPHONE VARCHAR(25)
		DECLARE @OLD_ASMNAME VARCHAR(14)
		DECLARE @OLD_ASMPHONE VARCHAR(25)
		DECLARE @OLD_HOLDCODE NUMERIC(5,0)
		DECLARE @OLD_TERCODE NUMERIC(5,0)
		DECLARE @OLD_HOLDSTATUS VARCHAR(1)
		DECLARE @OLD_TERSTATUS VARCHAR(1)
	
		DECLARE @NEW_CMCUST NUMERIC(5,0)
		DECLARE @NEW_DISTNAME VARCHAR(30)
		DECLARE @NEW_ACCNAME VARCHAR(14)
		DECLARE @NEW_ACTIVE VARCHAR(1)
		DECLARE @NEW_DMS VARCHAR(1)
		DECLARE @NEW_ADDR VARCHAR(100)
		DECLARE @NEW_CUSTPHONE VARCHAR(1000)
		DECLARE @NEW_SUPNAME VARCHAR(14)
		DECLARE @NEW_SUPPHONE VARCHAR(25)
		DECLARE @NEW_ASMNAME VARCHAR(14)
		DECLARE @NEW_ASMPHONE VARCHAR(25)
		DECLARE @NEW_HOLDCODE NUMERIC(5,0)
		DECLARE @NEW_TERCODE NUMERIC(5,0)
		DECLARE @NEW_HOLDSTATUS VARCHAR(1)
		DECLARE @NEW_TERSTATUS VARCHAR(1)
		
		DECLARE @TEL VARCHAR(1000)
	
		SET @CON = ''
		
		SET @CON = '1=1'
		set @curWeek = (select tier_1 from bkm_0_x where tier_0=convert(varchar(10),getDate()-7,112))
		--LAY HOLD
	--	create table #hold_temp (holdcode numeric(5,0))
	--	INSERT INTO #HOLD_TEMP(HOLDCODE) 
	--	SELECT CMCUST FROM PTRCM_HOLD_STATUS
	--				WHERE [WEEK]=LEFT(RIGHT(@CURWEEK,7),2)
	--				AND [YEAR] = RIGHT(@CURWEEK,4)
	--				AND CMCUST NOT IN (SELECT CMCUST FROM PTRCM_TERMINATE_STATUS)
		--LAT TERMINATE
	--	CREATE TABLE #TERMINATE_TEMP (TERCODE NUMERIC(5,0))
	--	INSERT INTO #TERMINATE_TEMP (TERCODE)
	--	SELECT CMCUST FROM PTRCM
	--	WHERE CMCUST IN (SELECT CMCUST FROM PTRCM_TERMINATE_STATUS)
		--------------------------------------------------------
		--******************--
	
		CREATE TABLE #RESULT (
			CMCUST NUMERIC(5,0)
			,DISTNAME VARCHAR(30)
			,ACCNAME VARCHAR(14)
			,ACTIVE VARCHAR(1)
			,TYPE VARCHAR(1)
			,CMCAD1 VARCHAR(100)
			,CUSTPHONE VARCHAR(1000)
			,SUPNAME VARCHAR(14)
			,SUPPHONE VARCHAR(25)
			,ASMNAME VARCHAR(14)
			,ASMPHONE VARCHAR(25)
			,HOLDCODE NUMERIC(5,0)
			,TERCODE NUMERIC(5,0)
			,HOLD VARCHAR(1)
			,TER VARCHAR(1)
		)
		INSERT INTO #RESULT(CMCUST,DISTNAME,ACCNAME,ACTIVE,TYPE,CMCAD1,CUSTPHONE
			,SUPNAME,SUPPHONE,ASMNAME,ASMPHONE,HOLDCODE,TERCODE,HOLD,TER)
		SELECT A.CMCUST, ISNULL(A.CMCNME,'') AS DISTNAME, ISNULL(C.ACCNAME,'') AS ACCNAME
		,ISNULL(B.ACTIVE,'0') AS ACTIVE
		,ISNULL(B.DMS_FLAG,'0') AS TYPE,A.CMCAD1, ISNULL(C.PHONE,'') AS CUSTPHONE 
		, ISNULL(D.ACCNAME,'') AS SUPNAME, ISNULL(D.PHONE,'') AS SUPPHONE
		,ISNULL(D.ASMNAME,'') AS ASMNAME,ISNULL(D.ASMPHONE,'') AS ASMPHONE 
		,ISNULL(H.CMCUST,'0') AS HCMCUST
		,ISNULL(T.CMCUST,'0') AS TCMCUST
		,CASE ISNULL(H.CMCUST,'0')
			WHEN '0' THEN ''
			ELSE 'H'
		END AS HOLD
		,CASE ISNULL(T.CMCUST,'0')
			WHEN '0' THEN ''
			ELSE 'T'
		END AS TER
	FROM PTRCM A INNER JOIN DIST_CODE_MAPPING DCM ON A.CMCUST = DCM.REAL_DIST_CODE
	INNER JOIN PTRCM_DIST_STATUS B ON DCM.PSEUDO_DIST_CODE = B.CMCUST 
	-----------------------------------------------------------------------
	LEFT JOIN (SELECT CMCUST FROM PTRCM_HOLD_STATUS
		WHERE CMCUST NOT IN (SELECT CMCUST FROM PTRCM_TERMINATE_STATUS)
		AND [YEAR]*100+[WEEK] <=RIGHT(@CURWEEK,4)*100+LEFT(RIGHT(@CURWEEK,7),2)) H
	ON A.CMCUST = H.CMCUST
	--**************
	LEFT JOIN (
	SELECT CMCUST FROM PTRCM_TERMINATE_STATUS
			WHERE [YEAR]*100+[WEEK] <=RIGHT(@CURWEEK,4)*100+LEFT(RIGHT(@CURWEEK,7),2)
	) T
	ON A.CMCUST = T.CMCUST
	----------------------------------------------------------------------
	LEFT JOIN ( SELECT C.ACCNAME,C.USERCODE, D.PHONE FROM VLACM C 
			INNER JOIN VLACC D ON C.ACCNAME = D.ACCNAME AND D.USERTYPE = 'CUSTOMER' ) C 
			ON C.USERCODE = A.CMCUST 
			LEFT JOIN ( 
				SELECT * FROM (
					SELECT A.*, B.PHONE 
					FROM VL_SALESUP_ACCOUNTS A 
					INNER JOIN VLACC B ON A.ACCNAME = B.ACCNAME ) C 
				LEFT JOIN (
					SELECT A.ACCNAME AS ASMNAME, A.USERNAME,B.PHONE AS ASMPHONE 
					FROM VL_ASM_ACCOUNTS A 
					INNER JOIN VLACC B ON A.ACCNAME = B.ACCNAME) D 
					ON C.ACCNAME = D.USERNAME ) D 
				ON A.CMCUST = D.USERCODE 
	----------------------------------------------------
	--DEBUG--
	--SELECT * FROM #RESULT
	--WHERE CMCUST IN (SELECT CMCUST FROM #RESULT GROUP BY CMCUST HAVING COUNT(*) >1)
	--ORDER BY CMCUST
	--RETURN
	--ENDDEBUG--
	DECLARE CURSOR_1 CURSOR FOR
	SELECT * FROM #RESULT
	WHERE CMCUST IN (SELECT CMCUST FROM #RESULT 
				GROUP BY CMCUST 
				HAVING COUNT(*) > '1')
	
	OPEN CURSOR_1
	FETCH NEXT FROM CURSOR_1 INTO @NEW_CMCUST,@NEW_DISTNAME,@NEW_ACCNAME,@NEW_ACTIVE
	,@NEW_DMS,@NEW_ADDR,@NEW_CUSTPHONE,@NEW_SUPNAME,@NEW_SUPPHONE,@NEW_ASMNAME,@NEW_ASMPHONE,@NEW_HOLDCODE
	,@NEW_TERCODE,@NEW_HOLDSTATUS,@NEW_TERSTATUS
	
	SET @OLD_CMCUST = @NEW_CMCUST
	SET @OLD_DISTNAME = @NEW_DISTNAME
	SET @OLD_ACCNAME = @NEW_ACCNAME
	SET @OLD_ACTIVE = @NEW_ACTIVE
	SET @OLD_DMS = @NEW_DMS
	SET @OLD_ADDR = @NEW_ADDR
	SET @OLD_CUSTPHONE = @NEW_CUSTPHONE
	SET @OLD_SUPNAME = @NEW_SUPNAME
	SET @OLD_SUPPHONE = @NEW_SUPPHONE
	SET @OLD_ASMNAME = @NEW_ASMNAME
	SET @OLD_ASMPHONE = @NEW_ASMPHONE
	SET @OLD_HOLDCODE = @NEW_HOLDCODE
	SET @OLD_TERCODE = @NEW_TERCODE
	SET @OLD_HOLDSTATUS = @NEW_HOLDSTATUS
	SET @OLD_TERSTATUS = @NEW_TERSTATUS
	SET @TEL =''
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @OLD_CMCUST <> @NEW_CMCUST
		BEGIN
			DELETE FROM #RESULT WHERE CMCUST = @OLD_CMCUST
			INSERT INTO #RESULT VALUES(@OLD_CMCUST,@OLD_DISTNAME,@OLD_ACCNAME
			,@OLD_ACTIVE,@OLD_DMS,@OLD_ADDR,@TEL,@OLD_SUPNAME,@OLD_SUPPHONE
			,@OLD_ASMNAME,@OLD_ASMPHONE,@OLD_HOLDCODE,@OLD_TERCODE,@OLD_HOLDSTATUS,@OLD_TERSTATUS)
	--		SET @TEL = @NEW_CUSTPHONE
			SET @TEL = ''
			SET @OLD_CMCUST = @NEW_CMCUST
		END
		IF @TEL = ''
			SET @TEL = @NEW_CUSTPHONE
		ELSE
			
			SET @TEL = @TEL + '/'+ @NEW_CUSTPHONE	
	
		FETCH NEXT FROM CURSOR_1 INTO @NEW_CMCUST,@NEW_DISTNAME,@NEW_ACCNAME,@NEW_ACTIVE
		,@NEW_DMS,@NEW_ADDR,@NEW_CUSTPHONE,@NEW_SUPNAME,@NEW_SUPPHONE,@NEW_ASMNAME,@NEW_ASMPHONE,@NEW_HOLDCODE
		,@NEW_TERCODE,@NEW_HOLDSTATUS,@NEW_TERSTATUS
	END
	
	CREATE TABLE #RESULT_1 (
			CMCUST NUMERIC(5,0)
			,DISTNAME VARCHAR(30)
			,ACCNAME VARCHAR(14)
			,ACTIVE VARCHAR(1)
			,TYPE VARCHAR(1)
			,CMCAD1 VARCHAR(100)
			,CUSTPHONE VARCHAR(1000)
			,SUPNAME VARCHAR(14)
			,SUPPHONE VARCHAR(25)
			,ASMNAME VARCHAR(14)
			,ASMPHONE VARCHAR(25)
			,HOLDCODE NUMERIC(5,0)
			,TERCODE NUMERIC(5,0)
			,HOLD VARCHAR(1)
			,TER VARCHAR(1)
		)
	INSERT INTO #RESULT_1 (CMCUST,DISTNAME,ACCNAME,ACTIVE,TYPE,CMCAD1,CUSTPHONE,SUPNAME
		,SUPPHONE,ASMNAME,ASMPHONE,HOLDCODE,TERCODE,HOLD,TER)
	SELECT * FROM #RESULT A
	WHERE 1=1
	AND LEFT(RIGHT(A.CMCUST,4),1) LIKE '%'+@REGION+'%'
	AND ISNULL(A.ACTIVE,'0') LIKE '%'+@STATUS+'%'
	AND ISNULL(A.TYPE,'0') LIKE '%'+@TYPE+'%'
	AND A.HOLD LIKE '%'+@HOLD+'%'
	AND A.TER LIKE '%'+@TER+'%'
	
	SELECT * FROM #RESULT_1
	ORDER BY CMCUST
	
	DROP TABLE #RESULT
	DROP TABLE #RESULT_1
	CLOSE CURSOR_1
	DEALLOCATE CURSOR_1
END


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--sp_ListTel.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_ListTel]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_ListTel]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO
-- =============================================================================
-- Script  : sp_CloseWeek.sql
-- Purpose :  Close week
--	     	 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		26-Sep-2007			Modified (INNER JOIN with DIST_CODE_MAPPING to get real dist code)

-- =============================================================================

create proc sp_ListTel(
	@curDate varchar(10)--current date
)
AS
BEGIN
	SET NOCOUNT ON
	-----------------------------------------
	DECLARE @curWeek varchar(10)--current week

	set @curWeek = (select tier_1 from bkm_0_x where tier_0=@curDate)
	--LAY HOLD
	create table #hold_temp (holdcode numeric(5,0))
	INSERT INTO #HOLD_TEMP(HOLDCODE) 
	SELECT CMCUST FROM PTRCM_HOLD_STATUS
				WHERE [WEEK]=LEFT(RIGHT(@CURWEEK,7),2)
				AND [YEAR] = RIGHT(@CURWEEK,4)
				AND CMCUST NOT IN (SELECT CMCUST FROM PTRCM_TERMINATE_STATUS)
	--LAT TERMINATE
	CREATE TABLE #TERMINATE_TEMP (TERCODE NUMERIC(5,0))
	INSERT INTO #TERMINATE_TEMP (TERCODE)
	SELECT CMCUST FROM PTRCM
	WHERE CMCUST IN (SELECT CMCUST FROM PTRCM_TERMINATE_STATUS)
	--------------------------------------------------------
	--******************--

	CREATE TABLE #RESULT (
		CMCUST NUMERIC(5,0)
		,DISTNAME VARCHAR(30)
		,ACCNAME VARCHAR(14)
		,ACTIVE VARCHAR(1)
		,TYPE VARCHAR(1)
		,CMCAD1 VARCHAR(100)
		,CUSTPHONE VARCHAR(25)
		,SUPNAME VARCHAR(14)
		,SUPPHONE VARCHAR(25)
		,ASMNAME VARCHAR(14)
		,ASMPHONE VARCHAR(25)
		,HOLDCODE NUMERIC(5,0)
		,TERCODE NUMERIC(5,0)
	)
	INSERT INTO #RESULT(CMCUST,DISTNAME,ACCNAME,ACTIVE,TYPE,CMCAD1,CUSTPHONE
		,SUPNAME,SUPPHONE,ASMNAME,ASMPHONE,HOLDCODE,TERCODE)
	SELECT A.CMCUST, A.CMCNME AS DISTNAME, C.ACCNAME
	,ISNULL(B.ACTIVE,'0') AS ACTIVE
	,ISNULL(B.DMS_FLAG,'0') AS TYPE,A.CMCAD1, C.PHONE AS CUSTPHONE 
	, D.ACCNAME AS SUPNAME, D.PHONE AS SUPPHONE
	,D.ASMNAME,D.ASMPHONE 
	,H.CMCUST
	,T.CMCUST
FROM PTRCM A INNER JOIN DIST_CODE_MAPPING DCM ON A.CMCUST = DCM.REAL_DIST_CODE
INNER JOIN PTRCM_DIST_STATUS B ON DCM.PSEUDO_DIST_CODE = B.CMCUST 
-----------------------------------------------------------------------
LEFT JOIN (SELECT CMCUST FROM PTRCM_HOLD_STATUS
	WHERE CMCUST NOT IN (SELECT CMCUST FROM PTRCM_TERMINATE_STATUS)
	--AND [WEEK] = LEFT(RIGHT(@CURWEEK,7),2) AND [YEAR] = RIGHT(@CURWEEK,4)) H
	AND [YEAR]*100+[WEEK] >=RIGHT(@CURWEEK,4)*100+LEFT(RIGHT(@CURWEEK,7),2)) H
ON A.CMCUST = H.CMCUST
--**************
LEFT JOIN (
--declare @curweek varchar(14)
--set @curweek = 'wr20_2006'
SELECT CMCUST FROM PTRCM_TERMINATE_STATUS
		WHERE [YEAR]*100+[WEEK] >=RIGHT(@CURWEEK,4)*100+LEFT(RIGHT(@CURWEEK,7),2)
) T
ON A.CMCUST = T.CMCUST
----------------------------------------------------------------------
LEFT JOIN ( SELECT C.ACCNAME,C.USERCODE, D.PHONE FROM VLACM C 
		INNER JOIN VLACC D ON C.ACCNAME = D.ACCNAME AND D.USERTYPE = 'CUSTOMER' ) C 
		ON C.USERCODE = A.CMCUST 
		LEFT JOIN ( 
			SELECT * FROM (
				SELECT A.*, B.PHONE 
				FROM VL_SALESUP_ACCOUNTS A 
				INNER JOIN VLACC B ON A.ACCNAME = B.ACCNAME ) C 
			LEFT JOIN (
				SELECT A.ACCNAME AS ASMNAME, A.USERNAME,B.PHONE AS ASMPHONE 
				FROM VL_ASM_ACCOUNTS A 
				INNER JOIN VLACC B ON A.ACCNAME = B.ACCNAME) D 
				ON C.ACCNAME = D.USERNAME ) D 
			ON A.CMCUST = D.USERCODE 
			WHERE 1 = 1 
--AND A.CMCUST = '21149'
AND ISNULL(T.CMCUST,0) <> 0
ORDER BY A.CMCUST

SELECT * FROM #RESULT
	
DROP TABLE #HOLD_TEMP
DROP TABLE #TERMINATE_TEMP
DROP TABLE #RESULT
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--sp_Reopen.sql
if exists (select * from sysobjects where id = object_id(N'sp_Reopen') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp_Reopen
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROC sp_Reopen(
@year int,
@week int,
@curYear int,
@curWeek int,
@reopenList nvarchar(4000),
@region int,
@acount varchar(100)
)
AS
BEGIN
	begin transaction
	set nocount on
	DECLARE @WeekYear numeric(6,0)
	DECLARE @curWeekYear numeric(6,0)
	DECLARE @tmp numeric(6,0)
	DECLARE @strSQL nvarchar(4000)

	DECLARE @WeekTmp int
	DECLARE @YearTmp int


	Set @WeekYear= @year*100 + @week
	Set @curWeekYear= @curYear*100 + @curWeek
 

	--Xoa tat ca data trong bang Weekly_reopen_week
	Set @strSQL= N'	DELETE WEEKLY_REOPEN_WEEK
			WHERE  CMCUST IN (' + @reopenList + ' )	AND ([YEAR]*100+ [WEEK]) >= ' + CAST( @WeekYear AS NVARCHAR(6))+ ' AND ([YEAR]*100+ [WEEK]) <= ' + CAST( @curWeekYear AS NVARCHAR(6)) 

	EXEC sp_executesql @strSQL
	if @@error<>0 
		rollback
		
	--insert vao WEEKLY_REOPEN_WEEK voi data cua cac tuan tro ve sau.
	--Update Mo tuan cho vung trong bang Weekly_closed_Week
	IF(@WeekYear > @curWeekYear )	
		return
	ELSE
	BEGIN
		Set @tmp= @WeekYear
		WHILE (@tmp <= @curWeekYear )
			BEGIN
				--Insert cac record cho bang WEEKLY_REOPEN_WEEK
				Set @strSQL= N'	INSERT INTO WEEKLY_REOPEN_WEEK (CMCUST, [YEAR], [WEEK])
						SELECT DCM.PSEUDO_DIST_CODE 
							, LEFT('+ CAST( @tmp AS NVARCHAR(6)) + ',4)  
							, RIGHT('+ CAST( @tmp AS NVARCHAR(6)) + ',2)
						FROM PTRCM A INNER JOIN DIST_CODE_MAPPING DCM ON A.CMCUST = DCM.REAL_DIST_CODE
						WHERE DCM.PSEUDO_DIST_CODE IN (' + @reopenList + ')'
				EXEC ( @strSQL )

				--Insert record co trang thai Delete cho bang SS_WEEK_STS, ung voi tung NPP tung WEEK
				Set @strSQL=  N'UPDATE SS_WEEK_STS  
						SET  STATUS_DATE= GETDATE()
						WHERE [WEEK] = RIGHT('+ CAST( @tmp AS NVARCHAR(6)) + ',2) 
							AND [YEAR]= LEFT('+ CAST( @tmp AS NVARCHAR(6)) + ',4)
							AND REGION_ID = ' + CAST(@region AS VARCHAR(1))  + '
							AND STATUS=''D'' AND SENDULV=''N''
							AND CMCUST IN  (' + @reopenList + ') ' 

				EXEC ( @strSQL )

				Set @strSQL=  N'INSERT INTO SS_WEEK_STS([WEEK], [YEAR], REGION_ID, REGION_ABV, STATUS,  DIVISION, PROCESSED, SENDULV, STATUS_DATE , CMCUST) 
						SELECT 	RIGHT('+ CAST( @tmp AS NVARCHAR(6)) + ',2) AS [WEEK],
							LEFT('+ CAST( @tmp AS NVARCHAR(6)) + ',4)  AS [YEAR], ' 
							+ CAST(@region AS VARCHAR(1))  + ' AS REGION_ID ,
							 case ' + CAST(@region AS VARCHAR(1)) + ' when 1 then ''HN''   
										when 2 then ''DD''
										when 3 then ''HE''
										when 4 then ''CT''
								 end AS REGION_ABV ,
							''D'' AS STATUS ,
							''''  AS DIVISION ,
							''N'' AS PROCESSED ,
							''N'' AS SENDULV,
							GETDATE() AS STATUS_DATE,	
							DCM.PSEUDO_DIST_CODE 
						FROM PTRCM A INNER JOIN DIST_CODE_MAPPING DCM ON A.CMCUST = DCM.REAL_DIST_CODE
						WHERE DCM.PSEUDO_DIST_CODE IN (' + @reopenList + ')
							 AND DCM.PSEUDO_DIST_CODE NOT IN (SELECT CMCUST 
										FROM SS_WEEK_STS 
										WHERE [WEEK]=RIGHT( ' + CAST(@tmp AS VARCHAR(6)) + ', 2) 
											AND [YEAR]=LEFT(' + CAST(@tmp AS VARCHAR(6))+ ', 4) 
											AND [REGION_ID]=' + CAST(@region AS VARCHAR(1)) + ' 
											AND SENDULV=''N'' AND STATUS=''D'' )' 

				 EXEC ( @strSQL )

				--Reopen week cho ca region
				IF EXISTS(SELECT * FROM WEEKLY_CLOSED_WEEK WHERE WR_YEAR=LEFT(@tmp,4) AND WR_WEEK=RIGHT(@tmp,2) AND WR_REGION=@region  )
					UPDATE WEEKLY_CLOSED_WEEK 
					SET STATUS=1 , UPDATED_ACC=@acount, UPDATED_DATE=getdate() 
					WHERE WR_YEAR=LEFT(@tmp,4) AND WR_WEEK=RIGHT(@tmp,2) AND WR_REGION=@region
				if @@error<>0 
					rollback


				--Reset trang thai cua bao cao lai thanh "Cho kiem tra"
				Set @strSQL= N'UPDATE UPLOAD_WEEKLY_EVENTS SET STATUS=0, ISIMPORT=1
						WHERE 	[WEEK]= RIGHT('+ CAST( @tmp AS NVARCHAR(6)) + ',2) 
						AND	[YEAR]=	LEFT('+ CAST( @tmp AS NVARCHAR(6)) + ',4)  
						AND 	CMCUST IN (' + @reopenList + ')'
				EXEC ( @strSQL )
				
				if @@error<>0 
					rollback


				Set @YearTmp= LEFT(@tmp ,4)
				Set @WeekTmp= RIGHT(@tmp , 2 )

				--Set trang thai de Gui ve ULV
				IF EXISTS (SELECT * FROM SS_WEEK_STS WHERE [WEEK]=@WeekTmp AND [YEAR]=@YearTmp AND [REGION_ID]=@region AND SENDULV='N' AND ( STATUS='C'OR STATUS='R') ) 	
				BEGIN
					UPDATE SS_WEEK_STS SET STATUS='R', STATUS_DATE= GETDATE()
					WHERE [WEEK]=@WeekTmp AND [YEAR]=@YearTmp AND [REGION_ID]=@region
						 AND SENDULV='N'AND ( STATUS='C' OR STATUS='R' )
				END
				ELSE
				BEGIN
					INSERT INTO SS_WEEK_STS([WEEK], [YEAR], REGION_ID, REGION_ABV, STATUS,  DIVISION, PROCESSED, SENDULV, STATUS_DATE ) 
					VALUES(@WeekTmp , @YearTmp ,
						 @region , case @region when 1 then 'HN' 
									when 2 then 'DD'
									when 3 then 'HE'
									when 4 then 'CT' 
									end  ,
						 'R', '' ,'N','N', getdate() )
				END


				--Tang  @tmp
				IF ( @WeekTmp=52 )
				BEGIN
					Set @WeekTmp=1
					Set @YearTmp=@YearTmp+1
				END
				ELSE 
				BEGIN
					Set @WeekTmp= @WeekTmp + 1
				END
				Set @tmp=@YearTmp*100 + @WeekTmp

			END
	END	
	
	commit
END


GO

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--SP_REOPEN_WEEK.sql
DROP PROC  SP_REOPEN_WEEK
GO

CREATE PROC SP_REOPEN_WEEK
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @cmcust NUMERIC(5,0)
	DECLARE @tocode NUMERIC(5,0)
	DECLARE @missing_list VARCHAR(50)	
	DECLARE @yearweek CHAR(6)	
	DECLARE @week INT
	DECLARE @year INT
	DECLARE @Cweek INT
	DECLARE @Cyear INT
	DECLARE @Nweek INT
	DECLARE @Nyear INT
	DECLARE @Region INT

BEGIN TRANSACTION
/*-------------------------------------------------------------------------------------*/
/*-- Reopen week cho nhung missing_report customers, -----------------------------------*/
/*-------------------------------------------------------------------------------------*/

	SELECT @Cweek= SUBSTRING(TIER_1, 2 ,2 ) , @Cyear= tier_4
	FROM BKM_0_X
	WHERE TIER_0= CONVERT(VARCHAR(8), (GETDATE()-7) , 112) 	

	CREATE TABLE #REOPEN_WEEK_TMP (
		CMCUST NUMERIC(5,0),
		[YEAR] INT ,
		[WEEK] INT )

	IF @@error <>0 GOTO FAIL

	INSERT INTO #REOPEN_WEEK_TMP (CMCUST, [YEAR], [WEEK])
	SELECT CMCUST, [YEAR], [WEEK]
	FROM WEEKLY_REPORT_MISSING_DATA
	WHERE STATUS=1
	UNION 
	SELECT CMCUST, [YEAR], [WEEK]
	FROM WEEKLY_REPORT_ERROR_STOCK
	WHERE STATUS=1


        /*Select all missing_report customer */	  
	DECLARE curReOpenCust CURSOR FORWARD_ONLY
		FOR 	SELECT CMCUST, MIN([YEAR]*100+[WEEK]) as YEARWEEK
			FROM #REOPEN_WEEK_TMP
			GROUP BY CMCUST
	
       OPEN curReOpenCust

	IF @@error <>0 GOTO FAIL

       FETCH NEXT FROM curReOpenCust INTO @cmcust, @yearweek

       WHILE @@FETCH_STATUS = 0 
       BEGIN
		SET @week= RIGHT(@yearweek, 2)
		SET @year= LEFT(@yearweek, 4 )
		
		SET @Region = LEFT(RIGHT(@cmcust,4),1)

		IF @week=52
			BEGIN
				SET @Nweek=1
				SET @Nyear=@year+1
			END
		ELSE	
			BEGIN
				SET @Nweek=@week+1 
				SET @Nyear= @year
			END

		SET @missing_list = ''
		--Neu A->B thi reopen cho B. Binh thuong thi reopen cho A.
		IF EXISTS (SELECT TOCODE FROM PTRCM_CHANGE_CODE WHERE CMCUST=@cmcust AND [WEEK]=@Nweek AND [YEAR]=@Nyear )
			BEGIN
				--Thanhnq modified 27-Sep-2007
				--SELECT @tocode=TOCODE FROM PTRCM_CHANGE_CODE  WHERE CMCUST=@cmcust AND [WEEK]=@Nweek AND [YEAR]=@Nyear
				SELECT @tocode=DCM.PSEUDO_DIST_CODE FROM PTRCM_CHANGE_CODE P INNER JOIN DIST_CODE_MAPPING DCM ON P.CMCUST = DCM.REAL_DIST_CODE WHERE P.CMCUST=@cmcust AND [WEEK]=@Nweek AND [YEAR]=@Nyear
				--SET @missing_list= CONVERT( CHAR(4), RIGHT(@tocode,4) )
				SET @missing_list= CONVERT( CHAR(4), @tocode)
			END
		ELSE	
			BEGIN
				SELECT @tocode=PSEUDO_DIST_CODE FROM DIST_CODE_MAPPING WHERE REAL_DIST_CODE = @cmcust 
				--SET @missing_list= CONVERT( CHAR(4), RIGHT(@cmcust,4) )
				SET @missing_list= CONVERT( CHAR(4), @tocode)
			END
			
		EXEC sp_Reopen @year, @week, @Cyear , @Cweek, @missing_list,@Region,'VIETLINK'

		IF @@error <>0 GOTO FAIL

		FETCH NEXT FROM curReOpenCust INTO @cmcust,@yearweek
	END --While 
	CLOSE curReOpenCust
	DEALLOCATE curReOpenCust

	IF @@error <>0 GOTO FAIL

	UPDATE WEEKLY_REPORT_MISSING_DATA 
	SET STATUS=0

	IF @@error <>0 GOTO FAIL
	
	UPDATE WEEKLY_REPORT_ERROR_STOCK 
	SET STATUS=0

	IF @@error <>0 GOTO FAIL	
	
COMMIT
	GOTO END_PROC
FAIL:
	ROLLBACK	
END_PROC:
END








GO

--sp_Synchronize.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_Synchronize]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_Synchronize]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

-- =============================================================================
-- Script  : sp_Synchronize.sql
-- Purpose :  Synchronize data of PTRCM & PTRCM_DIST_STATUS
--	     	 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		21-Sep-2007			Modified (Get pseudo dist code from mapping table 
--											to insert into PTRCM_DIST_STATUS instead 
--											of 4 right chars of CMCUST in PTRCM.)
-- =============================================================================


CREATE PROCEDURE sp_Synchronize(
@acc varchar(20)
)
AS
BEGIN
	SET NOCOUNT ON
	begin transaction
	--DONG BO DU LIEU 2 BANG PTRCM, VA PTRCM_DIST_STATUS
	
	-- delete PTRCM_DIST_STATUS cac du lieu khong co trong PTRCM
	DELETE PTRCM_DIST_STATUS 
	--ThanhNQ Comment 21-Sep-2007
	--WHERE CMCUST  NOT IN  ( SELECT DISTINCT  RIGHT(CMCUST,4)  FROM PTRCM  WHERE    LEFT(CMCUST,1) in ( 2,1,9) )
	WHERE CMCUST  NOT IN  ( SELECT DISTINCT  DCM.PSEUDO_DIST_CODE  FROM PTRCM P INNER JOIN DIST_CODE_MAPPING DCM ON P.CMCUST = DCM.REAL_DIST_CODE  WHERE    LEFT(CMCUST,1) in ( 2,1,9,4) )


	-- Insert vao PTRCM_DIST_STATUS cac du lieu chua co
	INSERT INTO PTRCM_DIST_STATUS(CMCUST, DMS_FLAG, GEN_TPL, UPDATED_DATE, UPDATED_ACC, ACTIVE )
	 	--SELECT  DISTINCT RIGHT(A.CMCUST, 4), 0, 0, Getdate(), @acc , 1
		SELECT  DISTINCT DCM.PSEUDO_DIST_CODE, 0, 0, Getdate(), @acc , 1
	 	FROM PTRCM A	/*++ThanhNQ add*/ INNER JOIN DIST_CODE_MAPPING DCM ON A.CMCUST = DCM.REAL_DIST_CODE --End
	 	--WHERE LEFT( A.CMCUST,1) in (2,1,9)   AND   RIGHT(A.CMCUST, 4) NOT IN (SELECT CMCUST FROM PTRCM_DIST_STATUS)
		WHERE LEFT( A.CMCUST,1) in (2,1,9,4)   AND   DCM.PSEUDO_DIST_CODE NOT IN (SELECT CMCUST FROM PTRCM_DIST_STATUS)
	commit
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--sp_TurnoverSale.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_TurnoverSale]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_TurnoverSale]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

-- =============================================================================
-- Script  : sp_TurnoverSale.sql
-- Purpose :  REPORT FOR TURNOVER
--	     	 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
--TRIEULV : 						Created
-- ThanhNQ		26-Sep-2007			Modified (INNER JOIN with DIST_CODE_MAPPING to get real dist code)

-- =============================================================================



CREATE     PROCEDURE sp_TurnoverSale 
( 
	@inFromRegion   as int,
	@inToRegion		as int,
	@inFromYear		as int,
	@inFromWeek		as int,
	@inToYear		as int,
	@inToWeek		as int

 )
AS

BEGIN


	DECLARE @intFWeek	as NUMERIC(2,0)
	DECLARE @intFYear	As NUMERIC(4,0)
	DECLARE @lngFromYW	as Numeric(7,0)

	DECLARE @intTWeek	as NUMERIC
	DECLARE @intTYear	As NUMERIC
	DECLARE @lngToYW	as Numeric(7,0)

	DECLARE @strSQL 	AS varchar(2000)
	
	SET NOCOUNT ON

		
--	print SubString( @inFromWeek,2,2)

--	Set @intFWeek	= CAST(RIGHT( @inFromWeek,2)AS NUMERIC(2,0))
--	Set @intFYear	= CAST(LEFT(@inFromWeek,4) AS NUMERIC(4,0))
	Set @intFYear	= @inFromYear
	Set @intFWeek	= @inFromWeek
	Set @intTYear	= @inToYear
	Set @intTWeek	= @inToWeek

	Set @lngFromYW  = @intFYear
	Set @lngFromYW  = @lngFromYW * 100 + @intFWeek


--	Set @intTWeek	= CAST(RIGHT( @inToWeek,2) AS NUMERIC(2,0))
--	Set @intTYear	= CAST(LEFT(@inToWeek,4) AS NUMERIC(4,0))

	Set @lngToYW  = @intTYear
	Set @lngToYW  = (@lngToYW) * 100 + @intTWeek
	

	SELECT LEFT(RIGHT(X.CMCUST,4),1) AS REGION
					,X.CMCUST,X.[WEEK], X.[YEAR], M.CMCNME, X.SALEINWEEK 
	FROM PTRCM M
	INNER JOIN (

			SELECT A.CMCUST,B.[WEEK],B.[YEAR], SUM(C.BANTT + C.BANTT3) AS SALEINWEEK 
			 		FROM PTRCM A INNER JOIN DIST_CODE_MAPPING DCM ON A.CMCUST = DCM.REAL_DIST_CODE
			 		INNER JOIN UPLOAD_WEEKLY_EVENTS B
			 			--ON B.CMCUST = RIGHT(A.CMCUST,4)
						ON B.CMCUST = DCM.PSEUDO_DIST_CODE
			 		INNER JOIN WEEKLY_DATA C
			 			ON B.UPLOADID = C.UPLOADID
			 		WHERE (1=1) 
			 			AND B.[YEAR]*100 + B.[WEEK] >= @lngFromYW AND B.[YEAR]*100 + B.[WEEK] <= @lngToYW 
						AND LEFT(B.CMCUST,1) >= @inFromRegion AND LEFT(B.CMCUST,1) <=@inToRegion 
			
			GROUP BY A.CMCUST, B.[WEEK], B.[YEAR]
	) X ON X.CMCUST = M.CMCUST
	
	--print @strSQL
			
	
	---EXEC ( @strSQL )

	if ( @@error <> 0 )
		return 
END


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--sp_UploadFile.sql
if exists (select * from dbo.sysobjects where id = object_id(N'sp_UploadFile') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp_UploadFile
GO

CREATE PROCEDURE sp_UploadFile
(
@week int,
@year int,
@cus_code VARCHAR(5),
@strReportCbo int,
@strStatusCbo int,
@arr_cus_code varchar(8000) , 
@strDistStatus int,
@strView varchar(10)
)
AS
BEGIN
set nocount on

DECLARE @strReport NVARCHAR(100)
DECLARE @strStat NVARCHAR(100)
DECLARE @strDistStat NVARCHAR(100)
DECLARE @str NVARCHAR(4000)
DECLARE @PWEEK INT
DECLARE @PYEAR INT
DECLARE @strTmp1 Nvarchar(4000)

	SET @strReport = Case @strReportCbo
				WHEN 1 THEN ' AND AA.ORIGINNAME IS NOT NULL '
				WHEN 2 THEN ' AND AA.ORIGINNAME IS NULL'
				ELSE ' '
			End 

	SET @strStat= Case @strStatusCbo
				WHEN 0 THEN ' AND AA.Status = 0 AND AA.IsImport = 1 '
				WHEN 1 THEN ' AND AA.Status = 1 '
				WHEN 5 THEN ' AND AA.Status = 5 '
				WHEN 2 THEN ' AND AA.Status = 2 '
				WHEN 3 THEN ' AND AA.Status = 0 AND AA.IsImport = 0 '
				WHEN 4 THEN ' AND AA.Status = 0 AND AA.IsImport = 2 '
				WHEN 6 THEN ' AND AA.Status = 3 '
				ELSE ' '
			End 

	SET  @strDistStat= Case  @strDistStatus
				WHEN '0' THEN '  AND  PTRCM_DIST_STATUS.ACTIVE = 0 '
				WHEN '1' THEN '  AND PTRCM_DIST_STATUS.ACTIVE = 1 '
				ELSE ' '
			End

	IF @week > 1 BEGIN
		SET @PWeek = @Week - 1
		SET @PYear = @Year

	END ELSE BEGIN
		SET @PWeek = 52
		SET @PYear = @Year -1
	  END

IF @strView='View' BEGIN

	IF @cus_code <> '-100' 	BEGIN
--Thanhnq modified: replate Right(PTRCM.CMCUST,4) = DCM.PSEUDO_DIST_CODE
--		SET @STR = 'SELECT DISTINCT Right(PTRCM.CMCUST,4) CMCUST
		SET @STR = 'SELECT DISTINCT DCM.PSEUDO_DIST_CODE CMCUST
		        		 , PTRCM.CMCUST CMCUST2
		        		 , AA.ORIGINNAME AS ORIGINNAME
		        		 , AA.UPDATETIME, AA.STATUS, AA.isImport
		        		 , AA.UploadID, BB.APPROVEDBY, BB.APPROVEDTIMe
					 , ISNULL( CC.STATUS,1) AS PREWEEK_STATUS
					 , ISNULL(PTRCM_DIST_STATUS.ACTIVE,1)  AS ACTIVE
					 , EE.CMCUST AS IS_REOPEN
					 , DD.STATUS AS IS_WEEK_OPEN
					 , FF.CMCUST AS IS_DIST_OPEN_PREWEEK
					 , GG.STATUS AS IS_PREWEEK_OPEN	
				, AA.SENDDATE
		                    FROM ((((( PTRCM INNER JOIN DIST_CODE_MAPPING DCM ON PTRCM.CMCUST = DCM.REAL_DIST_CODE LEFT JOIN PTRCM_DIST_STATUS ON  DCM.PSEUDO_DIST_CODE = PTRCM_DIST_STATUS.CMCUST )
						LEFT JOIN
		                 			(SELECT * FROM UPLOAD_WEEKLY_EVENTS
			                  		WHERE ([Week] = '+ CAST(@WEEK AS NVARCHAR(2)) +' OR [Week] is null)
			                  		AND ([Year]= ' + CAST(@YEAR AS NVARCHAR(4)) + ' OR [year] is null)) AA
		                  			ON DCM.PSEUDO_DIST_CODE = AA.CMCUST )
		                LEFT JOIN 
							WEEKLY_REPORT_STATISTIC BB 
		                 			ON AA.[WEEK] = BB.[WEEK] AND AA.[YEAR] = BB.[YEAR] AND AA.CMCUST = BB.CMCUST )
						LEFT JOIN 
							(SELECT * FROM UPLOAD_WEEKLY_EVENTS
			                  		WHERE ([Week] = '+ CAST( @PWEEK  AS NVARCHAR(2))+  ' OR [Week] is null) 
							AND ([Year]= ' + CAST(@PYEAR AS NVARCHAR(4)) +' OR [year] is null)) CC
		                  			ON DCM.PSEUDO_DIST_CODE= CC.CMCUST 
						LEFT JOIN WEEKLY_CLOSED_WEEK DD ON DD.WR_WEEK = '+ CAST(@WEEK AS NVARCHAR(2)) +' AND DD.WR_YEAR=' + CAST(@YEAR AS NVARCHAR(4)) + ' AND DD.WR_REGION= SUBSTRING(CAST(PTRCM.CMCUST AS NVARCHAR(5)),2,1 ) )
						LEFT JOIN WEEKLY_CLOSED_WEEK GG ON GG.WR_WEEK = '+ CAST(@PWEEK AS NVARCHAR(2)) +' AND GG.WR_YEAR=' + CAST(@PYEAR AS NVARCHAR(4)) + ' AND GG.WR_REGION= SUBSTRING(CAST(PTRCM.CMCUST AS NVARCHAR(5)),2,1 )
						LEFT JOIN WEEKLY_REOPEN_WEEK FF ON FF.[WEEK] = '+ CAST(@PWEEK AS NVARCHAR(2)) +' AND FF.[YEAR]=' + CAST(@PYEAR AS NVARCHAR(4)) + ' AND FF.CMCUST=DCM.PSEUDO_DIST_CODE)
						LEFT JOIN WEEKLY_REOPEN_WEEK EE ON EE.[WEEK] = '+ CAST(@WEEK AS NVARCHAR(2)) +' AND EE.[YEAR]=' + CAST(@YEAR AS NVARCHAR(4)) + ' AND EE.CMCUST=DCM.PSEUDO_DIST_CODE
						LEFT JOIN PTRCM_CHANGE_CODE HH ON  HH.TOCODE = PTRCM.CMCUST AND ( HH.[YEAR]*100 + HH.[WEEK]) > ( ' + CAST(@YEAR AS NVARCHAR(4)) + '*100 + '+ CAST(@WEEK AS NVARCHAR(2)) +')


	  			 WHERE DCM.PSEUDO_DIST_CODE = ' + @cus_code + '   ' + @strReport +'  ' +  @strStat +'  ' +  @strDistStat + '  ' +  '  AND HH.TOCODE IS NULL    ' 

		PRINT 'SQL1: ' + @STR
		exec sp_executesql @STR

		END
	ELSE
		BEGIN		
		SET @STR= 'SELECT DISTINCT DCM.PSEUDO_DIST_CODE CMCUST
			        		 , PTRCM.CMCUST CMCUST2
			        		 , AA.ORIGINNAME AS ORIGINNAME
			        		 , AA.UPDATETIME, AA.STATUS, AA.isImport
			        		 , AA.UploadID, BB.APPROVEDBY, BB.APPROVEDTIMe 
						 , ISNULL(CC.STATUS,1) as PREWEEK_STATUS
						 , ISNULL( PTRCM_DIST_STATUS.ACTIVE, 1)  AS ACTIVE
						 , EE.CMCUST AS IS_REOPEN
						 , DD.STATUS AS IS_WEEK_OPEN
						 , FF.CMCUST AS IS_DIST_OPEN_PREWEEK
						 , GG.STATUS AS IS_PREWEEK_OPEN	
					, AA.SENDDATE
			                  FROM ((((( PTRCM INNER JOIN DIST_CODE_MAPPING DCM ON PTRCM.CMCUST = DCM.REAL_DIST_CODE 
											LEFT JOIN PTRCM_DIST_STATUS ON  DCM.PSEUDO_DIST_CODE = PTRCM_DIST_STATUS.CMCUST )
									LEFT JOIN
			                 			(SELECT * FROM UPLOAD_WEEKLY_EVENTS
				                  		WHERE ([Week] = '+ CAST(@WEEK AS NVARCHAR(2)) +' OR [Week] is null)
				                  		AND ([Year]= ' + CAST(@YEAR AS NVARCHAR(4)) + ' OR [year] is null)) AA
			                  			ON DCM.PSEUDO_DIST_CODE = AA.CMCUST )
			                  		LEFT JOIN 
								WEEKLY_REPORT_STATISTIC BB 
			                 			ON AA.[WEEK] = BB.[WEEK] AND AA.[YEAR] = BB.[YEAR] AND AA.CMCUST = BB.CMCUST )
							LEFT JOIN 
								(SELECT * FROM UPLOAD_WEEKLY_EVENTS
				                  		WHERE ([Week] = '+ CAST( @PWEEK  AS NVARCHAR(2))+  ' OR [Week] is null) 
								AND ([Year]= ' + CAST(@PYEAR AS NVARCHAR(4)) +' OR [year] is null)) CC
			                  			ON DCM.PSEUDO_DIST_CODE = CC.CMCUST 
							LEFT JOIN WEEKLY_CLOSED_WEEK DD ON DD.WR_WEEK='+ CAST(@WEEK AS NVARCHAR(2)) +' AND DD.WR_YEAR=' + CAST(@YEAR AS NVARCHAR(4)) + ' AND DD.WR_REGION= SUBSTRING(CAST(PTRCM.CMCUST AS NVARCHAR(5)),2,1 ) )
							LEFT JOIN WEEKLY_CLOSED_WEEK GG ON GG.WR_WEEK='+ CAST(@PWEEK AS NVARCHAR(2)) +' AND GG.WR_YEAR=' + CAST(@PYEAR AS NVARCHAR(4)) + ' AND GG.WR_REGION= SUBSTRING(CAST(PTRCM.CMCUST AS NVARCHAR(5)),2,1 )
							LEFT JOIN WEEKLY_REOPEN_WEEK FF ON FF.[WEEK]='+ CAST(@PWEEK AS NVARCHAR(2)) +' AND FF.[YEAR]=' + CAST(@PYEAR AS NVARCHAR(4)) + ' AND FF.CMCUST=DCM.PSEUDO_DIST_CODE)
							LEFT JOIN WEEKLY_REOPEN_WEEK EE ON EE.[WEEK]='+ CAST(@WEEK AS NVARCHAR(2)) +' AND EE.[YEAR]=' + CAST(@YEAR AS NVARCHAR(4)) + ' AND EE.CMCUST=DCM.PSEUDO_DIST_CODE
							LEFT JOIN PTRCM_CHANGE_CODE HH ON  HH.TOCODE =PTRCM.CMCUST AND (HH.[YEAR]*100 + HH.[WEEK]) > ( ' + CAST(@YEAR AS NVARCHAR(4)) + '*100 + '+ CAST(@WEEK AS NVARCHAR(2)) +')
							
	
		  			 WHERE DCM.PSEUDO_DIST_CODE IN  ' 
	
			PRINT 'SQL2: ' + (@STR + '  ' + @arr_cus_code +  '  '  + @strReport + '  ' + @strStat + '  ' + @strDistStat + '  ' +  '  AND HH.TOCODE IS NULL ORDER BY PTRCM.CMCUST ' )
			exec (@STR + '  ' + @arr_cus_code +  '  '  + @strReport + '  ' + @strStat + '  ' + @strDistStat + '  ' +  '  AND HH.TOCODE IS NULL ORDER BY PTRCM.CMCUST ' )
		
		END

	END
ELSE
	BEGIN

		SET @STR= 'SELECT DISTINCT DCM.PSEUDO_DIST_CODE CMCUST
		        		 , PTRCM.CMCUST CMCUST2
		        		 , AA.ORIGINNAME AS ORIGINNAME
		        		 , AA.UPDATETIME, AA.STATUS, AA.isImport
		        		 , AA.UploadID, BB.APPROVEDBY, BB.APPROVEDTIMe 
					 , ISNULL(CC.STATUS,1) as PREWEEK_STATUS
					 , ISNULL( PTRCM_DIST_STATUS.ACTIVE, 1)  AS ACTIVE
					 , EE.CMCUST AS IS_REOPEN
					 , DD.STATUS AS IS_WEEK_OPEN
					 , FF.CMCUST AS IS_DIST_OPEN_PREWEEK
					 , GG.STATUS AS IS_PREWEEK_OPEN	
				, AA.SENDDATE
		                  FROM ((((( PTRCM INNER JOIN DIST_CODE_MAPPING DCM ON PTRCM.CMCUST = DCM.REAL_DIST_CODE
								LEFT JOIN PTRCM_DIST_STATUS ON  DCM.PSEUDO_DIST_CODE = PTRCM_DIST_STATUS.CMCUST )
						LEFT JOIN
		                 			(SELECT * FROM UPLOAD_WEEKLY_EVENTS
			                  		WHERE ([Week] = '+ CAST(@WEEK AS NVARCHAR(2)) +' OR [Week] is null)
			                  		AND ([Year]= ' + CAST(@YEAR AS NVARCHAR(4)) + ' OR [year] is null)) AA
		                  			ON DCM.PSEUDO_DIST_CODE = AA.CMCUST )
		                  		LEFT JOIN 
							WEEKLY_REPORT_STATISTIC BB 
		                 			ON AA.[WEEK] = BB.[WEEK] AND AA.[YEAR] = BB.[YEAR] AND AA.CMCUST = BB.CMCUST )
						LEFT JOIN 
							(SELECT * FROM UPLOAD_WEEKLY_EVENTS
			                  			WHERE ([Week] = '+ CAST( @PWEEK  AS NVARCHAR(2))+  ' OR [Week] is null) 
							AND ([Year]= ' + CAST(@PYEAR AS NVARCHAR(4)) +' OR [year] is null)) CC
		                  			ON DCM.PSEUDO_DIST_CODE = CC.CMCUST 
						LEFT JOIN WEEKLY_CLOSED_WEEK DD ON DD.WR_WEEK = '+ CAST(@WEEK AS NVARCHAR(2)) +' AND DD.WR_YEAR=' + CAST(@YEAR AS NVARCHAR(4)) + ' AND DD.WR_REGION= SUBSTRING(CAST(PTRCM.CMCUST AS NVARCHAR(5)),2,1 ) )
						LEFT JOIN WEEKLY_CLOSED_WEEK GG ON GG.WR_WEEK = '+ CAST(@PWEEK AS NVARCHAR(2)) +' AND GG.WR_YEAR=' + CAST(@PYEAR AS NVARCHAR(4)) + ' AND GG.WR_REGION= SUBSTRING(CAST(PTRCM.CMCUST AS NVARCHAR(5)),2,1 )
						LEFT JOIN WEEKLY_REOPEN_WEEK FF ON FF.[WEEK] = '+ CAST(@PWEEK AS NVARCHAR(2)) +' AND FF.[YEAR]=' + CAST(@PYEAR AS NVARCHAR(4)) + ' AND FF.CMCUST= DCM.PSEUDO_DIST_CODE)
						LEFT JOIN WEEKLY_REOPEN_WEEK EE ON EE.[WEEK] = '+ CAST(@WEEK AS NVARCHAR(2)) +' AND EE.[YEAR]=' + CAST(@YEAR AS NVARCHAR(4)) + ' AND EE.CMCUST= DCM.PSEUDO_DIST_CODE
						LEFT JOIN PTRCM_CHANGE_CODE HH ON  HH.TOCODE = PTRCM.CMCUST AND (HH.[YEAR]*100 + HH.[WEEK]) > ( ' + CAST(@YEAR AS NVARCHAR(4)) + '*100 + '+ CAST(@WEEK AS NVARCHAR(2)) +')
	  			 WHERE 1<>1 ' +
		                 	' ORDER BY PTRCM.CMCUST '

		PRINT 'SQL3: ' + @STR
		exec sp_executesql @STR
	--	exec @STR

	END

END
GO

GO

--UpdateCustFile.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateCustFile]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[UpdateCustFile]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/*
   CODER : HUYNT4
   CODE DATE : 20/9/2007
   PURPOSE : UPDATE FILE TYPE FOR CUSTOMER
*/

CREATE PROCEDURE  UpdateCustFile @CustCode varchar(50),@FileTypeId int,@OldFileTypeId int
AS
DECLARE @FullName varchar(50)

SELECT *
FROM CUSTOMER_FILE_TYPE
WHERE CUSTOMER_ID LIKE @CustCode AND FILE_TYPE_ID = @OldFileTypeId



IF @@ROWCOUNT > 0 
      BEGIN
                BEGIN TRAN  
                       UPDATE CUSTOMER_FILE_TYPE 
                       SET FILE_TYPE_ID=@FileTypeId 
                       WHERE CUSTOMER_ID LIKE @CustCode AND FILE_TYPE_ID = @OldFileTypeId
                    
                       IF @@ERROR <> 0 
                            BEGIN       
                                 ROLLBACK TRAN
                                 RETURN
                            END
               

                        UPDATE VLACC
                        SET FILE_TYPE_ID = @FileTypeId
                         WHERE ACCNAME LIKE @CustCode

                        IF @@ERROR <> 0 
                            BEGIN
                                    ROLLBACK TRAN
                                    RETURN
                           END
              COMMIT TRAN  
       END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--UpdateNewFileType.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateNewFileType]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[UpdateNewFileType]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/*
    CODER : HUYNT4
    DATE : 21/9/2007
*/
CREATE PROCEDURE UpdateNewFileType @FileType int,@OldFileType int, @FullName varchar(14)
AS




    BEGIN TRAN
  
                        DELETE  
                        FROM CUSTOMER_FILE_TYPE
                        WHERE CUSTOMER_ID LIKE @FullName     
          IF @@ERROR <> 0 
                BEGIN
                        ROLLBACK TRAN  
                        RETURN
               END 
          
          IF @FileType > 0
                BEGIN    
                       INSERT INTO CUSTOMER_FILE_TYPE(FILE_TYPE_ID,CUSTOMER_ID)
                       VALUES(@FileType,@FullName)
                END              
         IF @@ERROR<>0
                BEGIN
                      ROLLBACK TRAN
                      RETURN
                END 
              
   COMMIT TRAN
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--UpdatePseudoCode.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdatePseudoCode]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[UpdatePseudoCode]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/*
  CODER : HUYNT4
  DATE    : 27/9/2007
  PURPOSE : UPDATE PSEUDO CODE FOR DISTRIBUTOR 
*/
CREATE PROCEDURE UpdatePseudoCode @CustCode varchar(5),@PseudoCode varchar(4),@UserAccount varchar(14)
 AS

BEGIN TRAN
      
          INSERT INTO DIST_CODE_MAPPING (REAL_DIST_CODE , PSEUDO_DIST_CODE)
          VALUES(@CustCode,@PseudoCode)

          IF @@ERROR<>0
                   BEGIN
                           ROLLBACK TRAN
                           RETURN
                  END
          
         UPDATE PSEUDO_DIST_CODE_STATUS
          SET STATUS = 1
          WHERE PSEUDO_CODE LIKE RIGHT(@PseudoCode,3)

          IF @@ERROR <> 0 
                  BEGIN
                           ROLLBACK
                           RETURN
                  END
         
         DELETE
         FROM PTRCM_DIST_STATUS
         WHERE CMCUST = @PseudoCode
        
          IF @@ERROR <> 0 
                  BEGIN
                           ROLLBACK
                           RETURN
                  END
         INSERT INTO PTRCM_DIST_STATUS(CMCUST,DMS_FLAG,GEN_TPL,UPDATED_DATE,UPDATED_ACC,ACTIVE)      
        VALUES(@PseudoCode,'0','0',getdate(),@UserAccount,1)
        
          IF @@ERROR <> 0 
                  BEGIN
                           ROLLBACK
                           RETURN
                  END 
       
COMMIT TRAN
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

GO



--View.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[vwExport2ndErrorStock]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vwExport2ndErrorStock]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO
-- =============================================================================
-- Script  : vwExport2ndErrorStock.sql
-- Purpose :  * Select WR data of customer who has 'Loi TD TC' status and doesnot sent to ULV yet
--			  This SP is used to export Loi TD_TC data to ULV
--	     	 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		21-Sep-2007			Modified (INNER JOIN with DIST_CODE_MAPPING to get real dist code)

-- =============================================================================


CREATE  VIEW dbo.vwExport2ndErrorStock
AS
SELECT     CONVERT(varchar, P.CMCUST) + SPACE(13 - LEN(P.CMCUST)) AS CMCUST
	, RTRIM(A.PRCODE) + SPACE(13 - LEN(RTRIM(A.PRCODE))) AS PRCODE
	, CONVERT(varchar, 'W' + (CASE WHEN p.[Week] < 10 THEN ('0' + CONVERT(varchar, p.[Week])) ELSE CONVERT(varchar, p.[Week]) END) 
                      + '_' + CONVERT(varchar, P.[YEAR])) + SPACE(13 - 8) AS [Week]
	, CONVERT(varchar, A.TONDT1) + SPACE(13 - LEN(CONVERT(varchar, A.TONDT1))) AS TONDT1
	, CONVERT(varchar, A.TONDT2) + SPACE(13 - LEN(CONVERT(varchar, A.TONDT2))) AS TONDT2
	, CONVERT(varchar, A.NHANTT) + SPACE(13 - LEN(CONVERT(varchar, A.NHANTT))) AS NHANTT
	, CONVERT(varchar, A.NHANTTO)+ SPACE(13 - LEN(CONVERT(varchar, A.NHANTTO))) AS NHANTTO
	, CONVERT(varchar, A.TONCT1) + SPACE(13 - LEN(CONVERT(varchar, A.TONCT1))) AS TONCT1
	, CONVERT(varchar, A.TONCT2) + SPACE(13 - LEN(CONVERT(varchar, A.TONCT2))) AS TONCT2
	, CONVERT(varchar, A.BANTT)  + SPACE(13 - LEN(CONVERT(varchar, A.BANTT))) AS BANTT
	, CONVERT(varchar, A.BANTTO) + SPACE(13 - LEN(CONVERT(varchar, A.BANTTO))) AS BANTTO
	, CONVERT(varchar, A.NHANTT3)+ SPACE(13 - LEN(CONVERT(varchar, A.NHANTT3))) AS NHANTT3
	, CONVERT(varchar, A.BANTT3) + SPACE(13 - LEN(CONVERT(varchar, A.BANTT3))) AS BANTT3
	, P.[Week] 	AS nWeek
	, P.[Year] 	AS nYear
	, P.STATUS
FROM   (
	SELECT M.* FROM UPLOAD_WEEKLY_EVENTS M
		INNER JOIN DIST_CODE_MAPPING DCM ON DCM.PSEUDO_DIST_CODE = M.CMCUST
		LEFT OUTER JOIN WEEKLY_SENDULV_SRC N
		--ON ('2' + CAST(M.CMCUST AS VARCHAR) = N.CMCUST)
		ON (DCM.REAL_DIST_CODE = N.CMCUST)
			AND (M.[YEAR] = N.WR_YEAR) AND (M.[WEEK] = N.WR_WEEK)
	WHERE (M.STATUS = 3) AND (N.CMCUST IS NULL)
	) AS P 
	INNER JOIN WEEKLY_DATA A ON P.UPLOADID = A.UPLOADID 
	INNER JOIN WEEKLY_DESC B ON A.PRCODE = B.P_ID
WHERE (A.TONDT1 <> 0) OR
	(A.TONDT2 <> 0) OR
             (A.NHANTT <> 0) OR
             (A.NHANTTO <> 0) OR
             (A.TONCT1 <> 0) OR
             (A.TONCT2 <> 0) OR
             (A.BANTT <> 0) OR
             (A.BANTTO <> 0) OR
             (A.NHANTT3 <> 0) OR
             (A.BANTT3 <> 0)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

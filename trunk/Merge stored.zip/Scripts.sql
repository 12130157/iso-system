
--p_fpt_PDAVNM_AllProductByNameDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_AllProductByNameDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_AllProductByNameDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_AllProductByNameDB @SlsPerID varchar(10)    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_AllProductByNameDB.sql
-- Purpose : Get information of all items in warehouse of NPP
--	     Check * for all products which are given promotion
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		01-Jan-2007			Initial
-- TaiNT 		19-Mar-2007			Modified (only get products that SlsPerID sell)
-- TaiNT		18-Apr-2007			Modified (only get products that SlsPerID sell + FreeItem)
-- TaiNT		07-May-2007			Modified (shortname)
-- =============================================================================

/*    
This function return the information about all active products.    
The return recordset is sorted by product name    
The fields return are:    
    
- Product code    
- Product Name    
- ClassID    
- Promotion (= 1 if product in promotion or discount, else = 0)    
- HighSaleVol (= 1 if product in top 20 products that have high sale vol )     
*/                    

SELECT      
   
	ISNULL(INV.InvtID,'') 	as ProductCode,      
	ISNULL(Case When (Len(INV.Descr)> 14 and Len(INV.User2) >0) Then INV.User2 Else INV.Descr End,'') 	as ProductName, 
	ISNULL(INV.priceClassId,'') AS ClassID, --TaiNT -- Need define again--        
	CASE WHEN INV.InvtID In (
										Select	Distinct d.ProdID As InvtID
										From	xtfpt_PromProd d
													Inner Join user_vr_PDAVNM_CurrentDiscount crd 
														On d.ProgID = crd.DiscID
															And d.SeqID = crd.DiscSeq
										Union All
										Select	Distinct d.SubProdID As InvtID
										From	xtfpt_PromSubProd d
													Inner Join user_vr_PDAVNM_CurrentDiscount crd 
														On d.ProgID = crd.DiscID
															And d.SeqID = crd.DiscSeq
							)
	THEN 1
	ELSE 0
	END As Promotion,
	CASE When INV.invtID In (
							Select Top 20 sku.InvtID 
							From	fptTopSKUs sku
							Where	sku.SlsPerID = @SlsPerID
							Order By sku.SlsPerID, sku.SalesVol 
							)
	THEN 	1
	ELSE	0
	END As  HighSaleVol

FROM Inventory INV 
	INNER JOIN INUnit InU ON INV.InvtID = InU.InvtID And InU.MultDiv = 'D'      
	INNER JOIN InventoryADG idg On idg.InvtID = INV.InvtID
	-- TaiNT 19Apr07 Comment
		--Inner Join xtfpt_CatSal cs On cs.SlsPerID = @SlsPerID And idg.ProdLineID = cs.CatID -- theo nganh hang
WHERE INV.Transtatuscode = 'AC' AND InU.CnvFact > 0    
		And (
					Exists(Select cs.CatID From xtfpt_CatSal cs 
						Where cs.SlsPerID = @SlsPerID And idg.ProdLineID = cs.CatID) 
				or  Exists(Select ff.InvtID From xtfpt_PromFree ff 
													Inner Join user_vr_PDAVNM_CurrentDiscount crd 
															On ff.ProgID = crd.DiscID
																And ff.SeqID = crd.DiscSeq Where ff.InvtID = INV.InvtID)
			)   
ORDER BY ProductName     
      

GO

--p_fpt_PDAVNM_AllProductDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_AllProductDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_AllProductDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_AllProductDB @SlsPerID varchar(10)    
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_AllProductDB.sql
-- Purpose : Get information of all items in warehouse of NPP
--	     Check * for all products which are given promotion
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		01-Jan-2007			Created
-- TaiNT 		19-Mar-2007			Modified (only get products that SlsPerID sell)
-- TaiNT		18-Apr-2007			Modified (only get products that SlsPerID sell + FreeItem)
-- TaiNT		07-May-2007			Modified (shortname)
-- =============================================================================

/*    
This function return the information about all active products.    
The return recordset is sorted by product name    
The fields return are:    
    
- Product code    
- Product Name    
- UnitPerCase    
- Unit Price    
- RemainCase    
- RemainUnit    
- Price    
- ClassID    
- Promotion (= 1 if product in promotion or discount, else = 0)    
   
*/                    

SELECT      
   
	ISNULL(INV.InvtID,'') 	as ProductCode,      
	ISNULL(Case When (Len(INV.Descr)> 14 and Len(INV.User2) >0) Then INV.User2 Else INV.Descr End,'') 	as ProductName,       
	ISNULL(InU.CnvFact,0) 	as UnitPerCase,      
	ISNULL(CASE WHEN location.qtyavail > 0 THEN ISNULL(cast(location.qtyavail as int),0) / cast(InU.CnvFact as int) ELSE 0 END,0) AS RemainCases,      
	ISNULL(CASE WHEN location.qtyavail > 0 THEN ISNULL(cast(location.qtyavail as int),0) % cast(InU.CnvFact as int) ELSE location.qtyavail END,0) AS RemainUnits,      
	ISNULL(INV.StkBasePrc,0) as Price,       
	ISNULL(INV.priceClassId,'') AS ClassID,  --TaiNT -- Need define again--       
	CASE WHEN INV.InvtID In (
								Select	Distinct d.ProdID As InvtID
								From	xtfpt_PromProd d
											Inner Join user_vr_PDAVNM_CurrentDiscount crd 
												On d.ProgID = crd.DiscID
													And d.SeqID = crd.DiscSeq
								Union All
								Select	Distinct d.SubProdID As InvtID
								From	xtfpt_PromSubProd d
											Inner Join user_vr_PDAVNM_CurrentDiscount crd 
												On d.ProgID = crd.DiscID
													And d.SeqID = crd.DiscSeq
							 )
	THEN 1
	ELSE 0
	END As Promotion     
		
FROM Inventory INV 
		INNER JOIN INUnit InU ON INV.InvtID = InU.InvtID And InU.MultDiv = 'D'      
		INNER JOIN InventoryADG idg On idg.InvtID = INV.InvtID
		-- TaiNT 19Apr07 Comment
		--Inner Join xtfpt_CatSal cs On cs.SlsPerID = @SlsPerID And idg.ProdLineID = cs.CatID -- theo nganh hang
 	LEFT JOIN 
	(
		Select	invtid, sum(Qty) qtyavail 
		From
		   (Select	Invtid,(QtyOnHand - QtyShipNotInv - QtyAlloc) as Qty 
			From	location 
			Where	siteid not in ('HANGHONG','KHOHONG', 'KHOPHU')    
			Union All      
  			Select	od.Invtid, - (od.Cases * od.UnitPerCase + od.Units) as Qty 
			From	fptOrderDetail od 
						Inner Join fptOrderHeader oh On oh.OrderCode = od.OrderCode
			Where	oh.status = 0  
  			Union All     
			Select	od1.Invtid, - (od1.Cases * od1.UnitPerCase + od1.Units) as Qty 
			From	fptOrderDetail od1 
						Inner Join fptOrderHeader oh1 On oh1.OrderCode = od1.OrderCode
			Where	oh1.status = -1 And oh1.slsperid = @SlsPerID
			Union ALL  
			--------------------------  
     		Select	replace(ISNULL(INV.InvtID,''), ' ', '') InvtID,                                
					ISNULL(cast(Sum((CASE WHEN so.OrderType in ('DP', 'IN') THEN -1 ELSE 1 END)*                      
						 (CASE WHEN d.UnitMultDiv = 'M' then                       
					      (d.LineQty)*d.UnitRate                      
					         WHEN d.UnitMultDiv = 'D' then                       
					      (d.LineQty)/d.UnitRate                      
					     ELSE                      
					      (d.LineQty)                      
					     END))AS int), 0)  As qty                  
            From	xswSalesOrd so                      
		    			INNER join xswSlsOrdDet d on d.cpnyid = so.cpnyid and d.OrderNbr = so.OrderNbr                       
		    			--INNER JOIN xswSlsOrdDsp des on des.OrderNbr = so.OrderNbr and des.DespatchNbr = d.DespatchNbr                       
		    			INNER join Inventory INV on d.InvtID = INV.InvtID                      
		    Where  	So.OrderType in ('DP', 'IN')  AND (so.status ='N')                      
		       		 --AND so.OrderDate <= GetDate()                      
		    		AND so.OrderDate >=  convert(datetime,'01/' + cast(MONTH(getdate()) as varchar) + '/' + cast(Year(getdate()) as varchar),103)                      
		    Group By	INV.InvtID                      
				  
			----------------------------  
			) tmp      
  			Group By Invtid      
 	) location on INV.invtid = location.invtid       
WHERE INV.Transtatuscode = 'AC' AND InU.CnvFact > 0    
		And (
					Exists(Select cs.CatID From xtfpt_CatSal cs 
						Where cs.SlsPerID = @SlsPerID And idg.ProdLineID = cs.CatID) 
				or  Exists(Select ff.InvtID From xtfpt_PromFree ff 
													Inner Join user_vr_PDAVNM_CurrentDiscount crd 
															On ff.ProgID = crd.DiscID
																And ff.SeqID = crd.DiscSeq Where ff.InvtID = INV.InvtID)
			)   
ORDER BY ProductCode      
      

GO

--p_fpt_PDAVNM_CalculateCustomerHistory.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_CalculateCustomerHistory]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_CalculateCustomerHistory]
GO


CREATE  PROCEDURE p_fpt_PDAVNM_CalculateCustomerHistory 
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_CalculateCustomerHistory
-- Purpose : calculate history information of customer  
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		20-Mar-2007			Initial
-- TaiNT 		19-Apr-2007			Modified(only once time each month)
-- =============================================================================

/*    Current Month : March (03/07)
	- Month 1 : the month that is nearest the current month (Feb 02/07)
	- Month 2 : the month that is nearest the month 1 (Jan 01/07)
	- Month 3 : the month that is nearest the month 1 (Dec 12/06)

*/     

 -- SQL Go Here

	create table #orders (
		CpnyID varchar(10) not null,
		CustID varchar(10) not null,
		SlsperID varchar(10) not null,
		OrderDate smalldatetime not null,
		OrderNbr varchar(10) not null,
		Status varchar(1) not null,
		OrderType varchar(2) not null,
		OrdAmt float not null,
		NumType int not null
		primary key clustered (CpnyId,OrderNbr)
	)
	
	create nonclustered index #orders1 on #orders (CustID, SlsperID, OrderType, OrderDate DESC)
	
	create table #Sale3month (
		SlsPerID varchar(10) not null,
		CustID varchar(10) not null,
		SaleM1 float NOT NULL ,
		SaleM2 float NOT NULL ,
		SaleM3 float NOT NULL ,
		AverageSale float NOT NULL
		primary key clustered (SlsPerID,CustID)
	)
	
	DECLARE @CurrentDate smalldatetime
	DECLARE @Today1 smalldatetime
	DECLARE @Today2 smalldatetime
	DECLARE @Today3 smalldatetime
	DECLARE @StartMonth1 smalldatetime
	DECLARE @EndMonth1 smalldatetime
	DECLARE @StartMonth2 smalldatetime
	DECLARE @EndMonth2 smalldatetime
	DECLARE @StartMonth3 smalldatetime
	DECLARE @EndMonth3 smalldatetime
	DECLARE @CpnyID varchar(10)
	DECLARE @ParamDate smalldatetime
		 
	SELECT @CurrentDate = convert(smalldatetime, floor(convert(float, getdate())))

	-- The last date which ran SKUSuggest (MM/DD/YYYY)
	Select @ParamDate = Value From fptParameters Where RTrim(ID) = '001'
	
	If (Month(@CurrentDate) <> Month(@ParamDate))
	Begin
		-- Get the month1
		SELECT @Today1 = DateAdd(month,-1,convert(smalldatetime, floor(convert(float, @CurrentDate))))
		
		-- Get the month2
		SELECT @Today2 = DateAdd(month,-2,convert(smalldatetime, floor(convert(float, @CurrentDate))))
	
		-- Get the month3
		SELECT @Today3 = DateAdd(month,-3,convert(smalldatetime, floor(convert(float, @CurrentDate))))
	
		-- Get the first day in month 1 
		-- Select DateAdd(day,-1,Convert(datetime,'01/' + Cast(MONTH(getdate()) as varchar) + '/' + Cast(Year(getdate()) as varchar),103))
		
		Select @StartMonth1 = Convert(datetime,'01/' + Cast(MONTH(@Today1) as varchar) + '/' + Cast(Year(@Today1) as varchar),103)
		
		-- Get the end day in month 1 
		Select @EndMonth1 = DateAdd(day,-1,Convert(datetime,'01/' + Cast(MONTH(@CurrentDate) as varchar) + '/' + Cast(Year(@CurrentDate) as varchar),103))
	
		-- Get the first day in month 2 ----Ex: '2007-01-01 00:00:00'
		Select @StartMonth2 = Convert(datetime,'01/' + Cast(MONTH(@Today2) as varchar) + '/' + Cast(Year(@Today2) as varchar),103)
	
		-- Get the end day in month 2 
		Select @EndMonth2 = DateAdd(day,-1,@StartMonth1)
	
		-- Get the first day in month 3 ----Ex: '2006-12-01 00:00:00'
		Select @StartMonth3 = Convert(datetime,'01/' + Cast(MONTH(@Today3) as varchar) + '/' + Cast(Year(@Today3) as varchar),103)
	
		-- Get the end day in month 3 
		Select @EndMonth3 = DateAdd(day,-1,@StartMonth2)
		
		SELECT TOP 1 @CpnyID = CpnyID FROM GLSetup
		
		-- Get all orders that Slsperson sold during 3 months 
		INSERT #orders(CpnyId,CustID, SlsPerID, OrderDate, OrderNbr, Status, OrderType, OrdAmt,NumType)
		SELECT	@CpnyID,o.CustID, o.SlsPerID, o.ARDocDate,o.OrderNbr, o.Status, 
				o.OrderType, o.OrdAmt, NumType = Case When o.OrderType In ('SO','IN') Then 1 Else -1 End
		FROM	xswSalesOrd o
					INNER JOIN  xswInvoiceHeader ih On o.ARRefNbr = ih.RefNbr
		WHERE	-- status 'C' which Updated AR&IN
				o.Status = 'C' And (ih.BatNbr <> '' and  ih.INBatNbr <> '')
				AND o.OrderType in ('SO','CO','IN','CM')
	 			AND o.ARDocDate between @StartMonth3 And @EndMonth1
				
			
		Insert Into #Sale3month
		Select	tmp.SlsPerID, tmp.CustID,
				Sum(SaleM1) As SaleM1,
				Sum(SaleM2) As SaleM2,
				Sum(SaleM3) As SaleM3, 
				(Cast(Sum(Total) As Int)/3) As AverageSale
		From
			(
				-- Calculate SaleM1
				Select	m1.SlsPerID, 
						m1.CustID,
						Sum(m1.OrdAmt * m1.NumType) As SaleM1,
						0 As SaleM2, 
						0 As SaleM3,
						Sum(m1.OrdAmt * m1.NumType) As Total
				From	#orders m1
				Where	m1.OrderDate between @StartMonth1 and @EndMonth1
				Group By	m1.SlsPerID, m1.CustID
			
				Union All
			
				-- Calculate SaleM2
				Select	m2.SlsPerID, 
						m2.CustID,
						0 As SaleM1,
						Sum(m2.OrdAmt * m2.NumType) As SaleM2, 
						0 As SaleM3,
						Sum(m2.OrdAmt * m2.NumType) As Total 
				From	#orders m2
				Where	m2.OrderDate between @StartMonth2 and @EndMonth2
				Group By	m2.SlsPerID, m2.CustID
			
				Union All
				
				-- Calculate SaleM3
				Select	m3.SlsPerID, 
						m3.CustID,
						0 As SaleM1,
						0 As SaleM2, 
						Sum(m3.OrdAmt * m3.NumType) As SaleM3,
						Sum(m3.OrdAmt * m3.NumType) As Total 
				From	#orders m3
				Where	m3.OrderDate between @StartMonth3 and @EndMonth3
				Group By	m3.SlsPerID, m3.CustID
	
			) tmp
		Group By	tmp.SlsPerID, tmp.CustID
	
		Delete From fptCustomerHistory
	
		Insert Into fptCustomerHistory
		Select 	SaleM1, SaleM2, SaleM3, AverageSale, 0 As LastestSale1, 0 As LastestSale2,
			   	CustID, SlsPerID
		From	#Sale3month
		
	End
		
GO

--p_fpt_PDAVNM_CalculateHighPercentSKU.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_CalculateHighPercentSKU]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_CalculateHighPercentSKU]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_CalculateHighPercentSKU    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_CalculateHighPercentSKU.sql
-- Purpose : calculate sales volume for each SKUs
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		07-Jan-2007			Initial
-- TaiNT		17-Mar-2007			Modified (Add Parameters)
-- TaiNT 		19-Apr-2007			Modified(only once time each month)
-- =============================================================================

/*
This function calculate % sales value (doanh so) for each SKUs that 
	salesperson sold for customers during 8 weeks (60 days).
Store Proc is excuted when computer start each month
Results are inserted in fptTopSKUs                
*/                
-- SQL Go Here

	create table #orders (
		CustID varchar(10) not null,
		SlsperID varchar(10) not null,
		OrderDate smalldatetime not null,
		OrderNbr varchar(10) not null
		primary key clustered (OrderNbr DESC)
	)
	create nonclustered index #orders1 on #orders (OrderNbr, SlsperID)

	DECLARE @now smalldatetime
 	DECLARE @today smalldatetime
-- 	DECLARE @today_end smalldatetime
	DECLARE @start smalldatetime
	DECLARE @i int
	Declare @NumberOfDays As Int
	DECLARE @ParamDate smalldatetime

	-- Get NumberOfDays from fptParameter
	Select  @NumberOfDays = Value
	From	fptParameters
	Where	ID LIKE '%003%' 


	SET @now = getdate() --Ex: '2007-02-07 14:02:16.183'
 	SET @today = convert(smalldatetime, floor(convert(float, @now)))--Ex: '2007-02-07 00:00:00'
-- 	SET @today_end = dateadd(minute, -1, dateadd(day, 1, @today)) --Ex: '2007-02-07 23:59:00'
	SET @start = dateadd(day, -@NumberOfDays, @today)

	-- The last date which ran SKUSuggest (MM/DD/YYYY)
	Select @ParamDate = Value From fptParameters Where RTrim(ID) = '001'

	If (Month(@now) <> Month(@ParamDate))
	Begin
			-- Get all orders that Slsperson sold and not older than 60 days
			INSERT #orders(CustID, SlsPerID, OrderDate, OrderNbr)
			SELECT	o.CustID, o.SlsperID, o.OrderDate, o.OrderNbr
			FROM	xswSalesOrd o
						INNER JOIN  xswInvoiceHeader ih On o.ARRefNbr = ih.RefNbr
			WHERE	-- status 'C' which Updated AR&IN
					o.Status = 'C' And (ih.BatNbr <> '' and  ih.INBatNbr <> '')
					AND o.OrderType in ('SO','IN')
					AND o.OrderDate > @start
			
			Delete from fptTopSKUs
		
			-- Calculate sales volume for each SKUs 
			Insert  Into fptTopSKUs
			Select	d.SlsPerID, d.InvtID, SUM(d.LineQty * d.SlsPrice) As SalesVol
			From	xswSlsOrdDet d
						Inner Join #Orders o On d.OrderNbr = o.OrderNbr COLLATE database_default
												And d.SlsPerID = o.SlsPerID COLLATE database_default
			Where	d.LineQty <> 0 And d.User5 = 0 -- not freeitem
			Group By d.SlsPerID, d.InvtID 
			Order By d.SlsPerID,SalesVol DESC
	End

	

	





GO

--p_fpt_PDAVNM_CalculateMonthSummary.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_CalculateMonthSummary]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_CalculateMonthSummary]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_CalculateMonthSummary    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_CalculateMonthSummary.sql
-- Purpose : calculate sales volume for each salesperson in current month
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		19-Mar-2007			Initial
-- TaiNT		11-Apr-2007			Modified(Han Thanh Toan)
-- TaiNT		10-May-2007			Modified(Add fields CT_DS,...)
-- =============================================================================

/*
This function calculate  sales value (doanh so) for each salesperson that 
	salesperson will sell for customers during 1 month 
Store Proc is excuted when computer start each month
Results are inserted in fptMonthOrder                
*/                
-- SQL Go Here

	create table #slsperson (
		SlsPerID varchar(10) not null,
		primary key clustered (SlsPerId)
	)

	create table #orders (
		CpnyID varchar(10) not null,
		CustID varchar(10) not null,
		SlsperID varchar(10) not null,
		OrderDate smalldatetime not null,
		OrderNbr varchar(10) not null,
		Status varchar(1) not null,
		OrderType varchar(2) not null,
		OrdAmt float not null,
		NumType int not null
		primary key clustered (CpnyId,OrderNbr)
	)
	
	create nonclustered index #orders1 on #orders (CustID, SlsperID, OrderType, OrderDate DESC)
	
	create table #orderdet (
		SlsperID varchar(10) not null,		
		OrderNbr varchar(10) not null,
		NumType int not null,
		LineQty int not null,
		LineAmt float not null,
		InvtID varchar(30) not null
	)

	create index #orderdet1 on #orderdet(OrderNbr,InvtId)
	

	DECLARE @CurrentDate smalldatetime
	DECLARE @Today smalldatetime
 	DECLARE @StartMonth smalldatetime
	DECLARE @HanThanhToan int
	DECLARE @CpnyID varchar(10)

	SET @CurrentDate = getdate() --Ex: '2007.02.07 14:02:16.183'
	SELECT @Today = convert(smalldatetime, floor(convert(float, @CurrentDate)))
	-- Get the first day in month ----Ex: '2007-02-00 00:00:00'
	Select @StartMonth = Convert(datetime,'01/' + Cast(MONTH(@CurrentDate) as varchar) + '/' + Cast(Year(@CurrentDate) as varchar),103)
	
	SELECT TOP 1 @CpnyID = CpnyID FROM GLSetup

	-- Get Han Thanh Toan
	Select @HanThanhToan = Value From fptParameters Where ID Like '005'

	-- Get salesperson
	Insert Into #slsperson(SlsPerId) 
	Select Distinct p.SlsPerId 
	From	SalesPerson p
-- 				Inner Join Customer c on p.SlsPerID = c.CustID
-- 	Where	c.Status = 'A' and p.User1 <> ''

	-- Get all orders that Slsperson sold during a month 
	INSERT #orders(CpnyId,CustID, SlsPerID, OrderDate, OrderNbr, Status, OrderType, OrdAmt,NumType)
	SELECT	@CpnyID,o.CustID, o.SlsPerID, o.OrderDate, o.OrderNbr, o.Status, 
			o.OrderType, o.OrdAmt, NumType = Case When o.OrderType In ('SO','IN') Then 1 Else -1 End
	FROM	xswSalesOrd o
				INNER JOIN  xswInvoiceHeader ih On o.ARRefNbr = ih.RefNbr
	WHERE	-- status 'C' which Updated AR&IN
			o.Status = 'C' And (ih.BatNbr <> '' and  ih.INBatNbr <> '')
			AND o.OrderType in ('SO','CO','IN','CM')
 			AND o.OrderDate > @StartMonth
			

	Insert	Into	#OrderDet(SlsPerID, OrderNbr, NumType, LineQty, LineAmt, InvtID)
	Select	m.SlsPerID, m.OrderNbr, NumType = Case When m.OrderType In ('SO','IN') Then 1 Else -1 End,  
			Case When d.UnitMultDiv = 'M' Then       
     				(d.LineQty*d.UnitRate) * m.NumType     
        		 When d.UnitMultDiv = 'D' then       
     				(d.LineQty/d.UnitRate) * m.NumType     
    			 ELSE      
     				(d.LineQty * m.NumType)
    		END As LineQty,
			d.LineAmt, -- da tru KM tien roi
			d.InvtID
	From	xswSlsOrdDet d
				Inner Join #orders m On d.SlsPerID = m.SlsPerID COLLATE database_default
												And d.OrderNbr = m.OrderNbr COLLATE database_default
	Where 	d.InvtID <> '' And d.LineQty <> 0 And d.User5 = 0 -- not freeitem

	
	Delete From fptMonthReport
	
	Insert Into fptMonthReport(HoaDon, SKU, DoanhSoThang, No_QH, No_DH, No_TH, TongThu, SlsPerId,
								CT_DSo,CT_SKU,CT_DSoMHTT,DS_MHTT) 
	Select  SUM(HoaDon) as HoaDon, 
			SUM(SKU) as SKU,
			SUM(DoanhSoThang) as DoanhSoThang,
			SUM(No_QH) as No_QH,
			SUM(No_DH) as No_DH,
			SUM(No_TH) as No_TH, 
			SUM(TongThu) as TongThu,
			SlsPerId,
			SUM(CT_DSo) as CT_DSo,
			SUM(CT_SKU) as CT_SKU,
			SUM(CT_DSoMHTT) as CT_DSoMHTT ,
			SUM(DS_MHTT) as DS_MHTT 
	From 
	(
			Select
			 	HoaDon = SUM(so.NumType),
			 	SKU = 0, 
				DoanhSoThang = SUM(so.NumType* so.OrdAmt), 
				No_QH = 0, 
				No_DH = 0, 
				No_TH = 0,
				TongThu = 0,
				so.SlsPerID,
				CT_DSo = 0,
				CT_SKU = 0,
				CT_DSoMHTT = 0,
				DS_MHTT = 0
			From	#orders so  		
						inner join #slsperson sp on so.SlsPerId = sp.SlsPerId
			Group By so.SlsPerId
			
			Union All

			Select 
	 			HoaDon = 0,
	 			SKU = SUM(NumType),   
	 			DoanhSoThang = 0, 
				No_QH = 0, 
				No_DH = 0, 
				No_TH = 0,
				TongThu = 0,
				det.SlsPerID,
				CT_DSo = 0,
				CT_SKU = 0,
				CT_DSoMHTT = 0,
				DS_MHTT = 0
			From #orderdet det 
					Inner Join #slsperson sp on det.SlsPerId = sp.SlsPerId  	
			Group By det.SlsPerId
				
			Union All
			
			Select 
				 HoaDon = 0,
				 SKU =0,
				 DoanhSoThang = 0,
				 No_QH = isnull(        
					 Sum(CASE WHEN (floor(convert(float, @CurrentDate)) - floor(convert(float, d.DocDate))) > c.Terms THEN         
					     	CASE WHEN d.DocType IN ('IN','DM') THEN d.DocBal ELSE -d.DocBal END         
					     ELSE 0 END),0),        
				
				 No_DH = isnull(        
				 	Sum(CASE WHEN (floor(convert(float, @CurrentDate)) - floor(convert(float, d.DocDate))) = c.Terms THEN                 
				        	CASE WHEN d.DocType IN ('IN','DM') THEN d.DocBal ELSE -d.DocBal END         
				      	    ELSE 0 END),0),
				 
				 No_TH = isnull(        
				 	Sum(CASE WHEN (floor(convert(float, @CurrentDate)) - floor(convert(float, d.DocDate))) < c.Terms THEN                 
				        	CASE WHEN d.DocType IN ('IN','DM') THEN d.DocBal ELSE -d.DocBal END         
				      	    ELSE 0 END),0),
				 TongThu = 0,
				 d.SlsPerID,
				 CT_DSo = 0,
				 CT_SKU = 0,
				 CT_DSoMHTT = 0,
				 DS_MHTT = 0
			From
				ARDoc d      
			    	INNER JOIN Customer c ON d.CustID = c.CustID   
					Inner Join #slsperson s on d.SlsPerId = s.SlsPerId           
			Where  d.DocBal <> 0 and d.Rlsed=1 AND d.OpenDoc=1 and d.DocDate<=@Today        
			 				AND d.DocType IN ('IN','DM','CM')   AND c.Status = 'A'  
			Group By d.SlsPerId

			Union All

			SELECT 
				 HoaDon = 0,
				 SKU =0,
				 DoanhSoThang = 0,
				 No_QH = 0, 
				 No_DH = 0, 
				 No_TH = 0,
				 TongThu = sum(isnull(TongThu,0)),
				 SlsPerId = b.SlsPerID,
				 CT_DSo = 0,
				 CT_SKU = 0,
				 CT_DSoMHTT = 0,
				 DS_MHTT = 0
			From 
				( 
					SELECT	d.Slsperid AS SlsperID, adj.AdjAmt AS TongThu 
					FROM 	ArAdjust adj 
								Inner Join ARDoc d on adj.AdjdRefNbr = d.RefNbr
					WHERE 	adj.AdjgDocType = 'PA' 
						 		AND adj.S4Future12 not in ('NS','RA') 
								AND adj.AdjdDocType <> 'NS' 
								AND adj.AdjgDocDate >= @StartMonth
				) As b 
					Inner Join #slsperson s on b.SlsPerId = s.SlsPerId
				Group By b.slsperid
			
			Union All

			Select 
	 			HoaDon = 0,
	 			SKU = 0,   
	 			DoanhSoThang = 0, 
				No_QH = 0, 
				No_DH = 0, 
				No_TH = 0,
				TongThu = 0,
				tg.SlsPerID,
				CT_DSo = tg.TotalSale, -- chi tieu doanh so thang
				CT_SKU = tg.TotalSKU,  -- chi tieu SKU thang
				CT_DSoMHTT = 0,
				DS_MHTT = 0
			From  fptTargetSale tg
					Inner Join #slsperson sp on tg.SlsPerId = sp.SlsPerId  	
-- 			Group By tg.SlsPerId
	
			Union All

			Select 
	 			HoaDon = 0,
	 			SKU = 0,   
	 			DoanhSoThang = 0, 
				No_QH = 0, 
				No_DH = 0, 
				No_TH = 0,
				TongThu = 0,
				tg.SlsPerID,
				CT_DSo = 0, 
				CT_SKU = 0,  
				CT_DSoMHTT = tg.TotalStrategic,  -- chi tieu doanh so MHTT thang
				DS_MHTT = ISNULL(cr.TotalStrategic,0) -- thuc dat doanh so MHTT thang
			From  fptTargetStrategic tg
					Left Join fptCurrentStrategic cr On tg.SlsPerID = cr.SlsPerID
					Inner Join #slsperson sp on tg.SlsPerId = sp.SlsPerId  	
-- 			Group By tg.SlsPerId
 
	) As T2 
	Group By SlsPerId


GO

--p_fpt_PDAVNM_CalculateSalesPlan.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_CalculateSalesPlan]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_CalculateSalesPlan]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_CalculateSalesPlan    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_CalculateSalesPlan.sql
-- Purpose : calculate sales volume for each salesperson in current week
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		09-Mar-2007			Initial

-- =============================================================================

/*
This function calculate  sales value (doanh so) for each salesperson that 
	salesperson will sell for customers during 1 month 
Store Proc is excuted when computer start each month
Results are inserted in fptSalesPlan                
*/                
-- SQL Go Here

	create table #orders (
		CustID varchar(10) not null,
		SlsperID varchar(10) not null,
		OrderDate smalldatetime not null,
		OrderNbr varchar(10) not null
		primary key clustered (OrderNbr DESC)
	)
	create nonclustered index #orders1 on #orders (OrderNbr, SlsperID)
	
	/* TaiNT comment 10May07 ++ use table fptTargetSale
	create table #TargetSale (
		SlsperID varchar(10) not null,
		TotalSKU int not null,
		TotalSale float not null
		primary key clustered (SlsPerID DESC)
	)
	
	create table #CurrentSale (
		SlsperID varchar(10) not null,
		TotalSKU int not null,
		TotalSale float not null
		primary key clustered (SlsPerID DESC)
	)
	*/

	DECLARE @CurrentDate smalldatetime
 	DECLARE @StartMonth smalldatetime
	DECLARE @CountDaysOfMonth As Int
	DECLARE @CountRemainDaysOfMonth As Int
	

	SET @CurrentDate = getdate() --Ex: '2007.02.07 14:02:16.183'

	-- Get the first day in month ----Ex: '2007-02-00 00:00:00'
	Select @StartMonth = Convert(datetime,'01/' + Cast(MONTH(@CurrentDate) as varchar) + '/' + Cast(Year(@CurrentDate) as varchar),103)
	-- Get the number of days in month -- Ex : 28
	Select @CountDaysOfMonth = Datediff(d,@StartMonth,dateadd(month, 1, @StartMonth))
	-- Get the number of remaining days in month --Ex: 28 - 7 + 1 = 22
	Select @CountRemainDaysOfMonth = @CountDaysOfMonth 	- Day(@CurrentDate) + 1

	-- Get all orders that Slsperson sold during current weeks ( ko tinh tra hang)
	INSERT #orders(CustID, SlsPerID, OrderDate, OrderNbr)
	SELECT	o.CustID, o.SlsperID, o.OrderDate, o.OrderNbr
	FROM	xswSalesOrd o
				INNER JOIN  xswInvoiceHeader ih On o.ARRefNbr = ih.RefNbr
	WHERE	-- status 'C' which Updated AR&IN
			o.Status = 'C' And (ih.BatNbr <> '' and  ih.INBatNbr <> '')
			AND o.OrderType in ('SO','IN')
			AND o.OrderDate > @StartMonth

	/*--------- Calculate Sale Target for each salesperson ---------*/
	Delete From fptTargetSale
	Delete From fptCurrentSale
	Delete From fptTargetStrategic
	Delete From fptCurrentStrategic

	-- Calculate sales volume that salesperson sold in current month
	Insert Into	fptCurrentSale
	Select SlsPerID, ISNULL(SUM(TotalSKU),0) As TotalSKU, ISNULL(SUM(TotalSale),0) As TotalSale
	From(
		Select	d.SlsPerID, 0 As TotalSKU, ISNULL(SUM(d.LineQty * d.SlsPrice),0) As TotalSale
		From	xswSlsOrdDet d
					Inner Join #Orders o On d.OrderNbr = o.OrderNbr COLLATE database_default
											And d.SlsPerID = o.SlsPerID COLLATE database_default
		Where	d.LineQty <> 0 And d.User5 = 0 -- not freeitem
		Group By d.SlsPerID
 
		Union All

		Select	d.SlsPerID, ISNULL(Count(*),0) As TotalSKU, 0 As TotalSale
		From	xswSlsOrdDet d
					Inner Join #Orders o On d.OrderNbr = o.OrderNbr COLLATE database_default
											And d.SlsPerID = o.SlsPerID COLLATE database_default
		Where	d.LineQty <> 0 And d.User5 = 0 -- not freeitem
		Group By d.SlsPerID,d.InvtID 
		) Tmp
	Group By Tmp.SlsPerID

	-- Calculate sales target that salesperson have to sell in current month
	Insert Into	fptTargetSale
	Select SlsPerID, ISNULL(SUM(TotalSKU),0) As TotalSKU, ISNULL(SUM(TotalSale),0) As TotalSale
	From(
		Select pl.User6 As SlsPerID, 0 As TotalSKU, ISNULL(SUM(pl.Amount * ISNULL(inv.StkBasePrc,0)),0) As TotalSale
		From	xtfpt_SalesPlan pl
					Inner Join Inventory inv On pl.InvtID = inv.InvtID 
											And inv.TranStatusCode ='AC'
		Where	(convert(varchar(10),pl.User7,102) <= convert(varchar(10),@CurrentDate,102)
						And convert(varchar(10),pl.User8,102) >= convert(varchar(10),@CurrentDate,102))

		Group By pl.User6
 
		Union All

		Select	pl.User6 As SlsPerID, ISNULL(Count(*),0) As TotalSKU, 0 As TotalSale
		From	xtfpt_SalesPlan pl
		Where	pl.Amount <> 0 
				And	(convert(varchar(10),pl.User7,102) <= convert(varchar(10),@CurrentDate,102)
						And convert(varchar(10),pl.User8,102) >= convert(varchar(10),@CurrentDate,102))

		Group By pl.User6, pl.InvtID 
		) Tmp1
	Group By Tmp1.SlsPerID
	
	-- Calculate Current sales of Strategic
	Insert Into	fptCurrentStrategic
	Select	d.SlsPerID,  ISNULL(SUM(d.LineQty * d.SlsPrice),0) As TotalStrategic
	From	xswSlsOrdDet d
				Inner Join #Orders o On d.OrderNbr = o.OrderNbr COLLATE database_default
										And d.SlsPerID = o.SlsPerID COLLATE database_default
				Inner Join xtfpt_ProdMaintain p On d.InvtID = p.InvtID 
				Inner Join XTFPT_SalPerObj sls On d.SlsPerID = sls.SalPerID And p.ProgID = sls.ProgID
				Inner Join xtfpt_ConcenProgH h On (h.ProgID = p.ProgID --And h.Active = 1 van tinh cac don hang trc khi inactive
													And o.OrderDate between h.StartDate And h.EndDate)
	Where	d.LineQty <> 0 And d.User5 = 0 -- not freeitem
				And @StartMonth <= h.EndDate And h.StartDate <= dateadd(month, 1, @StartMonth) 
	Group By d.SlsPerID  

	-- Calculate Target sales of Strategic
	
	Insert Into	fptTargetStrategic
	Select	sls.SalPerID As SlsPerID,  ISNULL(SUM(sls.Objective),0) As TotalStrategic
	From	XTFPT_SalPerObj sls
				Inner Join xtfpt_ConcenProgH h On (h.ProgID = sls.ProgID And h.Active = 1)
	Where	@StartMonth <= h.EndDate And h.StartDate <= dateadd(month, 1, @StartMonth) 
	Group By sls.SalPerID  

		Delete from fptSalesPlan

		-- Calculate sales target that salesperson have to sell during the remaining days
				
		Insert Into fptSalesPlan
		Select SlsPerID,Round(SUM(TargetSKU),0) As TargetSKU, Round(SUM(TargetSale),0) As TargetSale, Round(SUM(TargetStrategic),0) As TargetStrategic
		From
			(
			Select tg.SlsPerID, 
				   (tg.TotalSKU - ISNULL(cr.TotalSKU,0))/@CountRemainDaysOfMonth As TargetSKU,
					TargetSale = Case When (tg.TotalSale > ISNULL(cr.TotalSale,0)) 
											Then (tg.TotalSale - ISNULL(cr.TotalSale,0))/@CountRemainDaysOfMonth
									  Else tg.TotalSale 
								 End,
					0 As TargetStrategic
			From fptTargetSale tg
					Left Join 	fptCurrentSale cr On tg.SlsPerID = cr.SlsPerID
	
			Union All

			Select tg.SlsPerID, 
				   0 As TargetSKU,
				   0 As TargetSale,
				   TargetStrategic = Case When (tg.TotalStrategic > ISNULL(cr.TotalStrategic,0)) 
												Then (tg.TotalStrategic - ISNULL(cr.TotalStrategic,0))/@CountRemainDaysOfMonth
									  Else tg.TotalStrategic 
								 	 End
			From fptTargetStrategic tg
					Left Join 	fptCurrentStrategic cr On tg.SlsPerID = cr.SlsPerID
			)Tmp1
		Group By	SlsPerID	

GO

--p_fpt_PDAVNM_CalculateSKUSuggest.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_CalculateSKUSuggest]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_CalculateSKUSuggest]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_CalculateSKUSuggest     
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_CalculateSKUSuggest.sql
-- Purpose : calculate SKUSuggest each days
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		07-Jan-2007			Initial
-- TaiNT		17-Mar-2007			Modified (Add Parameters)
-- TaiNT		28-Apr-2007			Modified (Replace OrderDate to ARDocDate)
-- TaiNT 		04-May-2007			Modified (fix bug effective date of xtfpt_PJP)
-- =============================================================================

/*
This function calculate SKUSuggest for all customers when computer start each days
Results are inserted in fptSKUSuggest
                
*/                
-- SQL Go Here

	create table #cust (
		CustID varchar(15) not null,
		SlsperID varchar(10) not null
		primary key clustered (CustID, SlsperID)
	)

	create table #top8orders (
		CpnyID varchar(10) not null,
		OrderNbr varchar(10) not null
		primary key clustered (CpnyID, OrderNbr)
	)

	create table #top2orders (
		CpnyID varchar(10) not null,
		OrderNbr varchar(10) not null
		primary key clustered (CpnyID, OrderNbr)
	)

	create table #orders (
		CustID varchar(15) not null,
		SlsperID varchar(10) not null,
		OrderDate smalldatetime not null,
		OrderNbr varchar(10) not null,
		OrdAmt	 float not null,
		primary key clustered (OrderNbr DESC)
	)
	create nonclustered index #orders1 on #orders (CustID, SlsperID, OrderDate DESC)

	DECLARE @now smalldatetime
	DECLARE @today smalldatetime
	DECLARE @today_end smalldatetime
	DECLARE @start smalldatetime
	DECLARE @i int
	DECLARE @CpnyID varchar(10)
	Declare @DateMask	As int
	Declare @NumberOfDays As Int

	-- Get NumberOfDays from fptParameter
	Select  @NumberOfDays = Value
	From	fptParameters
	Where	ID LIKE '%002%' 

	SET @now = getdate() --Ex: '2007-02-07 14:02:16.183'
	SET @today = convert(smalldatetime, floor(convert(float, @now)))--Ex: '2007-02-07 00:00:00'
	SET @today_end = dateadd(minute, -1, dateadd(day, 1, @today)) --Ex: '2007-02-07 23:59:00'
	SET @start = dateadd(day, -@NumberOfDays, @today)
	SELECT TOP 1 @CpnyID = CpnyID FROM GLSetup
		
	-- Set default salesroute follow day in week	
	-- Set @@DateFirst = 1 -- set default start day in week is Sunday
	Select @DateMask=  DATEPART(dw, @now) 
-- 				When 1 Then  -- Sunday
-- 				When 2 Then  -- Monday
-- 				When 3 Then  -- Tuesday
-- 				When 4 Then  -- Wednesday
-- 				When 5 Then  -- Thursday
-- 				When 6 Then  -- Friday
-- 				When 7 Then  -- Saturday
-- 				End

	Select	tmp.CustID, tmp.SlsPerID, tmp.DateMask
	Into	#xpjp
	From
	(
		Select 	CustID, SlsPerID, DateMask = 1
		From	xtfpt_pjp
		Where	Active = 1 And Sunday = 1 
					And @today between StartDate And EndDate
		Union All
		Select 	CustID, SlsPerID, DateMask = 2
		From	xtfpt_pjp
		Where	Active = 1 And Monday = 1 
					And @today between StartDate And EndDate
		Union All
		Select 	CustID, SlsPerID, DateMask = 3
		From	xtfpt_pjp
		Where	Active = 1 And Tuesday = 1 
					And @today between StartDate And EndDate
		Union All
		Select 	CustID, SlsPerID, DateMask = 4
		From	xtfpt_pjp
		Where	Active = 1 And Wednesday = 1 
					And @today between StartDate And EndDate
		Union All
		Select 	CustID, SlsPerID, DateMask = 5
		From	xtfpt_pjp
		Where	Active = 1 And Thursday = 1 
					And @today between StartDate And EndDate
		Union All
		Select 	CustID, SlsPerID, DateMask = 6
		From	xtfpt_pjp
		Where	Active = 1 And Friday = 1 
					And @today between StartDate And EndDate
		Union All
		Select 	CustID, SlsPerID, DateMask = 7
		From	xtfpt_pjp
		Where	Active = 1 And Saturday = 1 
					And @today between StartDate And EndDate
	)tmp

	-- Get list customers that today saleperson must visit
	INSERT 	#cust (CustID, SlsperID)
	SELECT 	distinct pjp.CustID, pjp.SlsperID
	FROM 	#xpjp pjp
	WHERE 	pjp.DateMask = @DateMask

	

	-- generate list of orders not older than 90 days
	INSERT #orders(CustID, SlsPerID, OrderDate, OrderNbr, OrdAmt)
	SELECT	o.CustID, o.SlsperID, o.ARDocDate, o.OrderNbr, o.OrdAmt
	FROM	xswSalesOrd o
				INNER JOIN	#cust c on o.SlsperID = c.SlsperID COLLATE database_default -- fix bug "collation conflict"
									 AND o.CustID = c.CustID COLLATE database_default -- fix bug "collation conflict"
				INNER JOIN  xswInvoiceHeader ih On o.ARRefNbr = ih.RefNbr
	WHERE	-- status 'C' which Updated AR&IN
	 		o.Status = 'C' And (ih.BatNbr <> '' and  ih.INBatNbr <> '')
			AND o.OrderType in ('SO','IN')
			AND o.ARDocDate > @start
	
	-- now choose 8 top orders
	set @i = 0
	while @i < 8 begin
		insert into #top8orders (CpnyID, OrderNbr)
		select 	@CpnyID, x.OrderNbr
		from (
			select OrderNbr = (select top 1 o.OrderNbr 
							   from #orders o 
							   where o.SlsperID = c.SlsperID COLLATE database_default
										AND o.CustID = c.CustID COLLATE database_default
	                                 and not exists (select * from #top8orders t 
													 where t.OrderNbr = o.OrderNbr) 
							   order by o.OrderDate desc, o.OrderNbr desc)
			from #cust c
		) x
		where not x.OrderNbr is null

		set @i = @i + 1
	end

	-- Fill data into fptTopOrders in order to calculate CustomerHistory
	set @i = 0
	while @i < 2 begin
		insert into #top2orders (CpnyID, OrderNbr)
		select 	@CpnyID, x.OrderNbr
		from (
			select OrderNbr = (select top 1 o.OrderNbr 
							   from #orders o 
							   where o.SlsperID = c.SlsperID COLLATE database_default
										AND o.CustID = c.CustID COLLATE database_default
	                                 and not exists (select * from #top2orders t 
													 where t.OrderNbr = o.OrderNbr) 
							   order by o.OrderDate desc, o.OrderNbr desc)
			from #cust c
		) x
		where not x.OrderNbr is null

		set @i = @i + 1
	end	

	Delete From fptTopOrders

	Insert Into	fptTopOrders
	Select	t.CpnyID, t.OrderNbr, o.OrderDate, o.OrdAmt, o.CustID, o.SlsPerID
	From	#orders o
				Inner Join #top2orders t On o.OrderNbr = t.OrderNbr COLLATE database_default

	DELETE FROM fptSKUSuggest

	-- generate results
	INSERT INTO 	fptSKUSuggest
	SELECT	@today,  d.SlsperID, d.CustID, d.InvtID,Round(AVG(d.LineQty),0) As Qty
	FROM	xswSlsOrdDet d
			INNER JOIN	#top8orders AS Ord ON ord.OrderNbr = d.OrderNbr COLLATE database_default -- fix bug "collation conflict"
												and ord.CpnyID = d.CpnyID COLLATE database_default -- fix bug "collation conflict"
	WHERE	d.LineQty <> 0 And d.User5 = 0 -- not freeitem
	GROUP BY	d.InvtID, d.SlsperID, d.CustID





GO

--p_fpt_PDAVNM_CatDisplayEvaluationDB.sql

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_CatDisplayEvaluationDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_CatDisplayEvaluationDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_CatDisplayEvaluationDB @SlsPerID varchar(10)    
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_CatDisplayEvaluationDB.sql
-- Purpose : Upload category that salesperson sell
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		09-Jan-2007			Initial
-- TaiNT 		16-Apr-2007			Modified(limit descr field not than 20)
-- =============================================================================

/*    
The fields return are:    

CategoryID
Descr
  
*/

	Select  t.CatID, Left(t.Descr,20) As Descr
	From	XTFPT_CatSal t
	Where	t.SlsPerID = @SlsPerID
			


	
	 
GO

--p_fpt_PDAVNM_CustomerByNameDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_CustomerByNameDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_CustomerByNameDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_CustomerByNameDB @SlsPerID varchar(10)    
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_CustomerByNameDB.sql
-- Purpose : Get information of all customer  
--	     Sort by Name
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		01-Jan-2007			Initial
-- TaiNT		06-Mar-2007			Modified( 'D','B','G')
-- TaiNT        30-Mar-2007			Modified(add customers for NVGH)
-- TaiNT        12-Apr-2007			Modified(add case Van-Sales: don hang chua import SOL)
-- TaiNT		18-Apr-2007			Modified (fix bug @CurrentDate)
-- TaiNT 		04-May-2007			Modified (fix bug effective date of xtfpt_PJP)
-- =============================================================================

/*    
This function return the information about all active customer.    
The return recordset is sorted by cust name    
The fields return are:    
    
- CustID    
- Cust Name    
- Route  	
*/        


SET NOCOUNT ON    
	Declare @Current_Date AS DateTime
	Declare @DateMask	As int
	Declare @Role As varchar(1)
	--Select @Current_date = GetDate()
	SELECT @Current_date = convert(smalldatetime, floor(convert(float, getdate())))

	-- Get role of slsperid
	Select	@Role = User5 
	From	SalesPerson 
	Where	SlsPerID = @SlsPerID

	Create table #Cust (CustID varchar(15))

	-- Set default salesroute follow day in week	
	-- Set @@DateFirst = 1 -- set default start day in week is Sunday
	Select @DateMask=  DATEPART(dw, @Current_date) 
-- 				When 1 Then  -- Sunday
-- 				When 2 Then  -- Monday
-- 				When 3 Then  -- Tuesday
-- 				When 4 Then  -- Wednesday
-- 				When 5 Then  -- Thursday
-- 				When 6 Then  -- Friday
-- 				When 7 Then  -- Saturday
-- 				End
	Select	tmp.CustID, tmp.DateMask
	Into	#xpjp
	From
	(
		Select 	CustID, DateMask = 1
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Sunday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 2
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Monday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 3
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Tuesday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 4
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Wednesday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 5
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Thursday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 6
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Friday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 7
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Saturday = 1 
					And @Current_date between StartDate And EndDate
	)tmp

	-- Calculate CurrentDebt & MoneyReceive
/****** Debt in ARDoc (IN, DM, CM) ***********/    
	SELECT d.CustID As CustID,  
	      Debt = (CASE WHEN d.DocType IN ('IN','DM') THEN d.DocBal ELSE -d.DocBal END)   
	INTO #DebtTmp  
	FROM  ARDoc d
		-- doi chieu cac cong no cua NVGH 
			Left Join xswSalesOrd so On (d.OrdNbr = so.ARRefNbr And so.User5 = @SlsPerID)        
	WHERE d.DocBal <> 0 AND d.Rlsed=1 AND d.OpenDoc=1 AND d.DocDate<=@Current_date   
		AND d.DocType IN ('IN','DM','CM')  
		And (d.SlsPerID = @SlsPerID or so.User5 = @SlsPerID) -- NVBH or NVGH
	
	/******** Payment not import to Solomon or imported but not release **************/
	INSERT INTO #DebtTmp  
		Select Custid, (-Amount) As Debt 
		From fptPayment p
		Where (Status in ('N', 'O') Or exists (select refnbr from ardoc where Rlsed = 0 and refnbr = Paycode ))  
			--And exists (SELECT SlsperID from salesperson s where p.SlsPerID = s.SlsPerID and (s.SlsperID = @SlsPerID or user2 = @SlsPerID))   
				AND (p.SlsPerID = @SlsPerID Or p.DeliverID = @SlsPerID) -- NVBH or NVGH
	
	/********* Orders in PDA which have been finished but haven't imported to Solomon *********/
	/* -- TaiNT ko xet truong hop nay , can xem lai
	INSERT INTO #DebtTmp  
		SELECT Custid,   
			   Debt = (BeforeDiscount - OrderDiscount - Discount_Amo)  
		FROM fptOrderHeader oh   
		WHERE status = 3 AND oh.SlsPerID = @SlsPerID  
		 --and not exists (SELECT refnbr from ardoc where Rlsed = 1 and refnbr = oh.OrderCode)  
		 --and exists (SELECT SlsperID from salesperson s where oh.SlsPerID = s.SlsPerID and (s.SlsperID = @SlsPerID or user2 = @SlsPerID))   
	 */
	/********* invoices which have imported into Solomon but not Update AR&IN ***********/
	INSERT INTO #DebtTmp  
		Select so.CustID,    
			DocBal = (Case    
						When so.OrderType in ('SO','IN') Then 1  
						--When so.OrderType in ('CO','CM') Then -1  
						End) * (oh.BeforeDiscount - oh.OrderDiscount - oh.Discount_Amo)
		From xswSalesOrd so  
			Inner Join xswInvoiceHeader ih On so.ARRefNbr = ih.RefNbr
			Inner Join fptOrderHeader oh On (so.ARRefNbr = oh.OrderCode And oh.Status = 3)
		Where -- status 'C' but not Update AR&IN
			so.status = 'C' And (ih.DocType != 'NA' and ih.BatNbr = '' or ih.SWFuture3 != 'NA' and ih.INBatNbr = '') and ih.SWFuture1 != 'V'
			And so.OrderType in ('SO','IN')  
			And (so.SlsPerID = @SlsPerID or so.User5 = @SlsPerID) -- NVBH or NVGH

	/********* invoices which have imported into Solomon but not Update AR&IN ***********/
	INSERT INTO #DebtTmp  
		Select so.CustID,    
			DocBal = (Case    
						--When so.OrderType in ('SO','IN') Then 1  
						When so.OrderType in ('CO','CM') Then -1  
						End) * (so.OrdAmt)
		From xswSalesOrd so  
			Inner Join xswInvoiceHeader ih On so.ARRefNbr = ih.RefNbr
		Where -- status 'C' but not Update AR&IN
			so.status = 'C' And (ih.DocType != 'NA' and ih.BatNbr = '' or ih.SWFuture3 != 'NA' and ih.INBatNbr = '') and ih.SWFuture1 != 'V'
			And so.OrderType in ('CO','CM')  
			And (so.SlsPerID = @SlsPerID or so.User5 = @SlsPerID) -- NVBH or NVGH
	
	/********* invoices which have imported into Solomon and Update AR&IN but not release cong no ***********/
	INSERT INTO #DebtTmp  
		Select oh.CustID,    
			DocBal =  (oh.BeforeDiscount - oh.OrderDiscount - oh.Discount_Amo) 
		From	fptOrderHeader oh 
		Where	oh.Status = 3 And Exists(Select RefNbr From ARDoc Where Rlsed = 0 And RefNbr = oh.OrderCode)
					And (oh.SlsPerID = @SlsPerID Or oh.User3 = @SlsPerID ) -- NVBH or NVGH 

	/********* Van-Sales invoices which have not imported into Solomon or imported but status = 'N'***********/
	INSERT INTO #DebtTmp  
		Select oh.CustID,    
			DocBal =  (oh.BeforeDiscount - oh.OrderDiscount - oh.Discount_Amo) 
		From	fptOrderHeader oh 
		Where	oh.OrderType = 0 -- ban hang
				And oh.Status = 3 And Not Exists(Select ARRefNbr From xswSalesOrd Where ARRefNbr = oh.OrderCode And Status = 'C')
					And (oh.SlsPerID = @SlsPerID  ) -- NVBH  

	-- Get Customers that delivery man have to collect money
	If	(@Role = 'G')
	Begin 
		
		Insert Into #Cust
		Select distinct CustID
		From (
				-- Cac KH co don dang giao
				Select 	CustID
				From	fptOrderHeader 
				Where	Status = 2 And User3 = @SlsPerID
				/************ TaiNT comment 04May07 ***********************
				Union All -- Cac KH co NVGH/NVTT fai phu trach
				Select  CustID
				From	Customer
				Where 	Status = 'A' And (User2 = @SlsPerID Or User1 = @SlsPerID) -- NV Thu tien/NVGH
				**************************************************/
				Union All -- Cac KH co cong no ma NVGH fai phu trach
				Select  CustID
				From	#DebtTmp
			 ) temp1
	End

SET NOCOUNT OFF

If	(@Role = 'D' or @Role = 'B')
	Begin	
		SELECT DISTINCT 
			ISNULL(pjp.CustID,'') as CustomerCode,   
			ISNULL(  CASE WHEN CHARINDEX('~', cu.Name) > 0  THEN CONVERT(CHAR(30), LTRIM(RTRIM(SUBSTRING(cu.Name, CHARINDEX('~', cu.Name) + 1, 30)))   
			                          + SPACE(1) + LTRIM(SUBSTRING(cu.Name, 1, CHARINDEX('~', cu.Name) - 1)))   
			     	 ELSE cu.Name   
					 END,'') as CustomerName, 
			(@DateMask - 1) As Route  
		FROM #xpjp pjp   
			INNER JOIN Customer cu ON pjp.CustID = cu.CustID  
	
		WHERE  cu.status = 'A' And pjp.DateMask = @DateMask
		ORDER BY CustomerName	
	End
Else -- Giao hang ( chi lay nhung KH co don hang can giao)
	Begin
		SELECT DISTINCT 
			ISNULL(oh.CustID,'') as CustomerCode,   
			ISNULL(  CASE WHEN CHARINDEX('~', cu.Name) > 0  THEN CONVERT(CHAR(30), LTRIM(RTRIM(SUBSTRING(cu.Name, CHARINDEX('~', cu.Name) + 1, 30)))   
			                          + SPACE(1) + LTRIM(SUBSTRING(cu.Name, 1, CHARINDEX('~', cu.Name) - 1)))   
			     	 ELSE cu.Name   
					 END,'') as CustomerName, 
			(@DateMask - 1) As Route  
		From #Cust oh
			Inner Join Customer cu On (oh.CustID = cu.CustID )
		ORDER BY CustomerName	
	End	

	

GO

--p_fpt_PDAVNM_CustomerDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_CustomerDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_CustomerDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_CustomerDB @SlsPerID varchar(10)    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_CustomerDB.sql
-- Purpose : Get information of customer 
--	     Sort by CustID
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		01-Jan-2007			Initial
-- TaiNT		06-Mar-2007			Modified( 'D','B','G')
-- TaiNT        08-Mar-2007			Modified(add calculate CurrentDebt,MoneyReceive)
-- TaiNT        30-Mar-2007			Modified(add customers for NVGH)
-- TaiNT        10-Apr-2007			Modified(add User1 = HanThanhToan)
-- TaiNT        12-Apr-2007			Modified(add case Van-Sales: don hang chua import SOL)
-- TaiNT        18-Apr-2007			Modified(add Trung Bay field)
-- TaiNT		18-Apr-2007			Modified (fix bug @CurrentDate)
-- TaiNT 		04-May-2007			Modified (fix bug effective date of xtfpt_PJP)
-- =============================================================================
/*    
This function return the information about all customer.    
The return recordset is sorted by custID     
The fields return are:    
    
MoneyReceive= Tong cac payment da xac nhan va da import trong ngay 
					+ tong cac payment chua xac nhan (ke ca cac ngay truoc)

*/        


SET NOCOUNT ON    
	Declare @Current_Date AS DateTime
	Declare @DateMask	As int
	Declare @Role As varchar(1)

	--Select @Current_date = GetDate()
	SELECT @Current_date = convert(smalldatetime, floor(convert(float, getdate())))
	
	-- Get role of slsperid
	Select	@Role = User5 
	From	SalesPerson 
	Where	SlsPerID = @SlsPerID

	Create table #Cust (CustID varchar(15))

	-- Set default salesroute follow day in week	
	-- Set @@DateFirst = 1 -- set default start day in week is Sunday
	Select @DateMask=  DATEPART(dw, @Current_date) 
-- 				When 1 Then 64 -- Sunday
-- 				When 2 Then 32 -- Monday
-- 				When 3 Then 16 -- Tuesday
-- 				When 4 Then 8 -- Wednesday
-- 				When 5 Then 4 -- Thursday
-- 				When 6 Then 2 -- Friday
-- 				When 7 Then 1 -- Saturday
-- 				End
	Select	tmp.CustID, tmp.DateMask
	Into	#xpjp
	From
	(
		Select 	CustID, DateMask = 1
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Sunday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 2
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Monday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 3
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Tuesday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 4
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Wednesday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 5
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Thursday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 6
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Friday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 7
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Saturday = 1 
					And @Current_date between StartDate And EndDate
	)tmp

	-- Calculate CurrentDebt & MoneyReceive
/****** Debt in ARDoc (IN, DM, CM) ***********/    
	SELECT d.CustID As CustID,  
	      Debt = (CASE WHEN d.DocType IN ('IN','DM') THEN d.DocBal ELSE -d.DocBal END)   
	INTO #DebtTmp  
	FROM  ARDoc d
		-- doi chieu cac cong no cua NVGH 
			Left Join xswSalesOrd so On (d.OrdNbr = so.ARRefNbr And so.User5 = @SlsPerID)        
	WHERE d.DocBal <> 0 AND d.Rlsed=1 AND d.OpenDoc=1 AND d.DocDate<=@Current_date   
		AND d.DocType IN ('IN','DM','CM')  
		And (d.SlsPerID = @SlsPerID or so.User5 = @SlsPerID) -- NVBH or NVGH
	
	/******** Payment not import to Solomon or imported but not release **************/
	INSERT INTO #DebtTmp  
		Select Custid, (-Amount) As Debt 
		From fptPayment p
		Where (Status in ('N', 'O') Or exists (select refnbr from ardoc where Rlsed = 0 and refnbr = Paycode ))  
			--And exists (SELECT SlsperID from salesperson s where p.SlsPerID = s.SlsPerID and (s.SlsperID = @SlsPerID or user2 = @SlsPerID))   
				AND (p.SlsPerID = @SlsPerID Or p.DeliverID = @SlsPerID) -- NVBH or NVGH
	
	/********* Orders in PDA which have been finished but haven't imported to Solomon *********/
	/* -- TaiNT ko xet truong hop nay , can xem lai
	INSERT INTO #DebtTmp  
		SELECT Custid,   
			   Debt = (BeforeDiscount - OrderDiscount - Discount_Amo)  
		FROM fptOrderHeader oh   
		WHERE status = 3 AND oh.SlsPerID = @SlsPerID  
		 --and not exists (SELECT refnbr from ardoc where Rlsed = 1 and refnbr = oh.OrderCode)  
		 --and exists (SELECT SlsperID from salesperson s where oh.SlsPerID = s.SlsPerID and (s.SlsperID = @SlsPerID or user2 = @SlsPerID))   
	 */
	/********* invoices which have imported into Solomon but not Update AR&IN ***********/
	INSERT INTO #DebtTmp  
		Select so.CustID,    
			DocBal = (Case    
						When so.OrderType in ('SO','IN') Then 1  
						--When so.OrderType in ('CO','CM') Then -1  
						End) * (oh.BeforeDiscount - oh.OrderDiscount - oh.Discount_Amo)
		From xswSalesOrd so  
			Inner Join xswInvoiceHeader ih On so.ARRefNbr = ih.RefNbr
			Inner Join fptOrderHeader oh On (so.ARRefNbr = oh.OrderCode And oh.Status = 3)
		Where -- status 'C' but not Update AR&IN
			so.status = 'C' And (ih.DocType != 'NA' and ih.BatNbr = '' or ih.SWFuture3 != 'NA' and ih.INBatNbr = '') and ih.SWFuture1 != 'V'
			And so.OrderType in ('SO','IN')  
			And (so.SlsPerID = @SlsPerID or so.User5 = @SlsPerID) -- NVBH or NVGH

	/********* invoices which have imported into Solomon but not Update AR&IN ***********/
	INSERT INTO #DebtTmp  
		Select so.CustID,    
			DocBal = (Case    
						--When so.OrderType in ('SO','IN') Then 1  
						When so.OrderType in ('CO','CM') Then -1  
						End) * (so.OrdAmt)
		From xswSalesOrd so  
			Inner Join xswInvoiceHeader ih On so.ARRefNbr = ih.RefNbr
		Where -- status 'C' but not Update AR&IN
			so.status = 'C' And (ih.DocType != 'NA' and ih.BatNbr = '' or ih.SWFuture3 != 'NA' and ih.INBatNbr = '') and ih.SWFuture1 != 'V'
			And so.OrderType in ('CO','CM')  
			And (so.SlsPerID = @SlsPerID or so.User5 = @SlsPerID) -- NVBH or NVGH
	
	/********* invoices which have imported into Solomon and Update AR&IN but not release cong no ***********/
	INSERT INTO #DebtTmp  
		Select oh.CustID,    
			DocBal =  (oh.BeforeDiscount - oh.OrderDiscount - oh.Discount_Amo) 
		From	fptOrderHeader oh 
		Where	oh.Status = 3 And Exists(Select RefNbr From ARDoc Where Rlsed = 0 And RefNbr = oh.OrderCode)
					And (oh.SlsPerID = @SlsPerID Or oh.User3 = @SlsPerID ) -- NVBH or NVGH 

	/********* Van-Sales invoices which have not imported into Solomon or imported but status = 'N'***********/
	INSERT INTO #DebtTmp  
		Select oh.CustID,    
			DocBal =  (oh.BeforeDiscount - oh.OrderDiscount - oh.Discount_Amo) 
		From	fptOrderHeader oh 
		Where	oh.OrderType = 0 -- ban hang
				And oh.Status = 3 And Not Exists(Select ARRefNbr From xswSalesOrd Where ARRefNbr = oh.OrderCode And Status = 'C')
					And (oh.SlsPerID = @SlsPerID  ) -- NVBH  
			
	-- Get Customers that delivery man have to deliver goods
	If	(@Role = 'G')
	Begin 
		Insert Into #Cust
		Select distinct CustID
		From (
				-- Cac KH co don dang giao
				Select 	CustID
				From	fptOrderHeader 
				Where	Status = 2 And User3 = @SlsPerID
				/************ TaiNT comment 04May07 ***********************
				Union All -- Cac KH co NVGH/NVTT fai phu trach
				Select  CustID
				From	Customer
				Where 	Status = 'A' And (User2 = @SlsPerID Or User1 = @SlsPerID) -- NV Thu tien/NVGH
				**************************************************/
				Union All -- Cac KH co cong no ma NVGH fai phu trach
				Select  CustID
				From	#DebtTmp
			 ) temp1
	End
SET NOCOUNT OFF

If	(@Role = 'D' or @Role = 'B')
	Begin
		SELECT DISTINCT 
			ISNULL(pjp.CustID,'') as CustomerCode,   
			ISNULL(  CASE WHEN CHARINDEX('~', cu.Name) > 0  THEN CONVERT(CHAR(30), LTRIM(RTRIM(SUBSTRING(cu.Name, CHARINDEX('~', cu.Name) + 1, 30)))   
			                          + SPACE(1) + LTRIM(SUBSTRING(cu.Name, 1, CHARINDEX('~', cu.Name) - 1)))   
			     	 ELSE cu.Name   
					 END,'') as CustomerName, 
			ISNULL(cu.Addr1,'') as Address,  
			ISNULL(cu.BillCity,'') as Province, 
			ISNULL(cu.BillPhone,'') as Phone,
			ISNULL(cu.crlmt,0) as DebtLimit,  
			ISNULL(cu.S4Future12,'') as RelValue, --loyalty chi so quan he
			SalesTarget = 0, -- chi tieu doanh so
			CurrentSales = 0, -- thuc dat doanh so
		    SalesCode = 'A', -- Ma Doanh so 
			GroupCode = 'B', -- Nhom 
			ISNULL(cu.User5,'') as ShopType , -- Loai cua hang
			ISNULL(cu.S4Future11,'') as Rate, -- Trung Bay
			ISNULL(cu.User6,'') as PositionCode, -- Vi tri
			ISNULL(tmp1.Debt,0) AS CurrentDebt,  
			ISNULL(tmp2.Payment,0) as MoneyReceive,
			0 As Visit,
			0 as Pay,  
			RTrim(cu.PriceClassID) As PriceClassID,
			User1 = cu.terms, -- han thanh toan
			User2 = 0,
			User3 = Case When @Role = 'D' Then ISNULL(cu.User1,'') Else @SlsPerID End, -- NVGH
		    User4 = '',
			(@DateMask - 1) As Route  
		FROM #xpjp pjp   
			INNER JOIN Customer cu ON pjp.CustID = cu.CustID  And cu.Status = 'A'
			LEFT JOIN (select CustID, Sum(Debt) Debt From #DebtTmp Group by CustID) tmp1 on pjp.CustID = tmp1.CustID
			LEFT JOIN  
			(  
				Select CustID, Sum(Amount) Payment 
				From (   
					Select CustID, Amount   
					From fptPayment f  
					Where (f.SlsPerID = @SlsPerID or f.DeliverID = @SlsPerID)
							and (Status = 'O')  
				    
				  	Union all
				  
					Select CustID, Amount   
					From fptPayment f  
					Where convert(varchar(10),PayDate,103) = convert(varchar(10),@Current_date,103)   
						and f.SlsPerID = @SlsPerID
						and (Status = 'N' or 
								exists(select refnbr from ardoc where refnbr = PayCode)) -- trang thai da import vao SOL 
				   
					) as T  
			 	Group by CustID  
			) as tmp2 on pjp.CustID = tmp2.CustID  
		WHERE  cu.status = 'A' And pjp.DateMask = @DateMask
		ORDER BY CustomerCode  
	End
Else -- Giao hang ( chi lay nhung KH co don hang can giao)
	Begin
		SELECT DISTINCT 
			ISNULL(oh.CustID,'') as CustomerCode,   
			ISNULL(  CASE WHEN CHARINDEX('~', cu.Name) > 0  THEN CONVERT(CHAR(30), LTRIM(RTRIM(SUBSTRING(cu.Name, CHARINDEX('~', cu.Name) + 1, 30)))   
			                          + SPACE(1) + LTRIM(SUBSTRING(cu.Name, 1, CHARINDEX('~', cu.Name) - 1)))   
			     	 ELSE cu.Name   
					 END,'') as CustomerName, 
			ISNULL(cu.Addr1,'') as Address,  
			ISNULL(cu.BillCity,'') as Province, 
			ISNULL(cu.BillPhone,'') as Phone,
			ISNULL(cu.crlmt,0) as DebtLimit,  
			ISNULL(cu.S4Future12,'') as RelValue, --loyalty chi so quan he
			SalesTarget = 0, -- chi tieu doanh so
			CurrentSales = 0, -- thuc dat doanh so
		    SalesCode = 'A', -- Ma Doanh so 
			GroupCode = 'B', -- Nhom 
			ISNULL(cu.User5,'') as ShopType , -- Loai cua hang
			ISNULL(cu.S4Future11,'') as Rate, -- Trung Bay
			ISNULL(cu.User6,'') as PositionCode, -- Vi tri
			ISNULL(tmp1.Debt,0) AS CurrentDebt,  
			ISNULL(tmp2.Payment,0) as MoneyReceive,
			0 As Visit,
			0 as Pay,  
			RTrim(cu.PriceClassID) As PriceClassID,
			User1 = cu.terms, -- han thanh toan,
			User2 = 0,
			User3 = ISNULL(cu.User1,''), -- NVGH
		    User4 = '',
			(@DateMask - 1) As Route  
		From #Cust oh
			Inner Join Customer cu On (oh.CustID = cu.CustID)
			LEFT JOIN (select CustID, Sum(Debt) Debt From #DebtTmp Group by CustID) tmp1 on oh.CustID = tmp1.CustID
			LEFT JOIN  
			(  
				Select CustID, Sum(Amount) Payment 
				From (   
					Select CustID, Amount   
					From fptPayment f  
					Where (f.SlsPerID = @SlsPerID or f.DeliverID = @SlsPerID)
							and (Status = 'O')  
				    
				  	Union all
				  
					Select CustID, Amount   
					From fptPayment f  
					Where convert(varchar(10),PayDate,103) = convert(varchar(10),@Current_date,103)   
						and (f.SlsPerID = @SlsPerID or f.DeliverID = @SlsPerID)
						and (Status = 'N' or 
								exists(select refnbr from ardoc where refnbr = PayCode)) -- trang thai I da import vao SOL 
				   
					) as T  
			 	Group by CustID  
			) as tmp2 on oh.CustID = tmp2.CustID  
		ORDER BY CustomerCode 
	End
				

	
GO

--p_fpt_PDAVNM_CustomerHistoryDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_CustomerHistoryDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_CustomerHistoryDB]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


CREATE  PROCEDURE p_fpt_PDAVNM_CustomerHistoryDB @SlsPerID varchar(10)    
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_CustomerHistoryDB
-- Purpose : Upload history information of customer  
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		1-Mar-2007			Initial

-- =============================================================================

/*    
The fields return are:    
SaleM1
SaleM2
SaleM3
AverageSale
LastestSale1
LastestSale2
User1
User2
CustomerCode
User3
User4
*/     
SELECT SaleM1,  SaleM2,  SaleM3,  AverageSale,0 AS  LastestSale1, 0 AS  LastestSale2, 0 AS User1, 0 AS User2,
CustID,'' AS User3, '' AS User4
FROM fptCustomerHistory
WHERE SlsPerID = @SlsPerID
ORDER BY CustID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_CustomerStockDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_CustomerStockDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_CustomerStockDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_CustomerStockDB @SlsPerID varchar(10)    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_CustomerStockDB.sql
-- Purpose : Get information of all items in warehouse of retailer that 
--										salesman counting
--	     
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		08-Jan-2007			Initial

-- =============================================================================
/*    
This function return the information about all products exist in retailer's stock that 
salesperson counting 

The fields return are:    
 
CustomerCode
ProductCode
Cases
Units
Checked
User1
User2
User3
User4

*/                    

Select CustID As CustomerCode, InvtID As ProductCode, 
	   Cases,
	   Units, 
	   Checked,
	   User1,
	   User2,
	   User3,
	   User4
From   fptCustomerStock 
Where  SlsPerID = @SlsPerID 
		And DateDiff(Day,OrderDate,getDate()) = 0 -- only get results today
Order By CustID, InvtID

GO

--p_fpt_PDAVNM_CustomerVisitDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_CustomerVisitDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_CustomerVisitDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_CustomerVisitDB @SlsPerID varchar(10)    
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_CustomerVisitDB
-- Purpose : Upload visit time information of customer  
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		09-Jan-2007			Initial

-- =============================================================================

/*    
The fields return are:    
    
[CreateDate] datetime NULL,
[SlsPerID] [varchar] (50)    NULL ,
[CustomerCode] [varchar] (50)   NULL ,
[StartTime] [varchar] (17)   NULL ,
[EndTime] [varchar] (17)   NULL 

*/     

	Select	RTrim(SlsPerID) As SlsPerID, RTrim(CustomerCode) As CustomerCode, StartTime, EndTime
	From 	fptCustomerVisit
	Where	SlsPerID = @SlsPerID
			And Datediff(day,CreateDate,getdate()) = 0
GO

--p_fpt_PDAVNM_CustSalesGroupDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_CustSalesGroupDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_CustSalesGroupDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_CustSalesGroupDB @SlsPerID varchar(10)    
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_CustSalesGroupDB.sql
-- Purpose : Upload information that figure out customer belongs cust group
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		09-Mar-2007			Initial
-- TaiNT		18-Apr-2007			Modified(remove xtfpt_CatSal)
-- TaiNT		25-Apr-2007			Modified(fix bug duplicate records)
-- TaiNT 		04-May-2007			Modified (fix bug effective date of xtfpt_PJP)
-- =============================================================================

/*    
The fields return are:    
    
CustID
GroupID -- Nhom doanh so
Descr
LevelID -- Muc doanh so
User1
User2
User3
User4

*/            

SET NOCOUNT ON    
	Declare @Current_Date AS DateTime
	Declare @DateMask	As int

	--Select @Current_date = GetDate()
	SELECT @Current_date = convert(smalldatetime, floor(convert(float, getdate())))
	
	

	-- Set default salesroute follow day in week	
	-- Set @@DateFirst = 1 -- set default start day in week is Sunday
	Select @DateMask=  DATEPART(dw, @Current_date) 
-- 				When 1 Then 64 -- Sunday
-- 				When 2 Then 32 -- Monday
-- 				When 3 Then 16 -- Tuesday
-- 				When 4 Then 8 -- Wednesday
-- 				When 5 Then 4 -- Thursday
-- 				When 6 Then 2 -- Friday
-- 				When 7 Then 1 -- Saturday
-- 				End
	Select	tmp.CustID, tmp.DateMask, tmp.SlsPerID, tmp.StartDate, tmp.EndDate
	Into	#xpjp
	From
	(
		Select 	CustID, DateMask = 1, SlsPerID, StartDate, EndDate
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Sunday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 2, SlsPerID, StartDate, EndDate
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Monday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 3, SlsPerID, StartDate, EndDate
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Tuesday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 4, SlsPerID, StartDate, EndDate
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Wednesday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 5, SlsPerID, StartDate, EndDate
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Thursday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 6, SlsPerID, StartDate, EndDate
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Friday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 7, SlsPerID, StartDate, EndDate
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Saturday = 1 
					And @Current_date between StartDate And EndDate
	)tmp
        
SET NOCOUNT OFF

Select distinct g.CustID,g.Descr,g.GroupID,g.LevelID,
	   User1 = 0, User2 = 0, User3 = '', User4 = ''
From xtfpt_CustGroup g
	Inner Join #xpjp p On p.CustID = g.CustID And p.DateMask = @DateMask
	--Inner Join xtfpt_CatSal s On s.SlsPerID = p.SlsPerID And s.CatID = g.GroupID
Where p.SlsPerID = @SlsPerID And (convert(varchar(10),p.StartDate,102) <= convert(varchar(10),getdate(),102)
		And convert(varchar(10),p.EndDate,102) >= convert(varchar(10),getdate(),102))
Order By 	g.CustID




GO

--p_fpt_PDAVNM_DailyReportDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DailyReportDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DailyReportDB]
GO


CREATE   PROCEDURE p_fpt_PDAVNM_DailyReportDB @SlsPerID varchar(10)    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DailyReportDB.sql
-- Purpose : Upload daily information of salesperson
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		02-Jan-2007			Initial
-- TaiNT		12-Mar-2007			Modified 
-- TaiNT 		17-Mar-2007			Modified (Add parameters )
-- TaiNT		18-Apr-2007			Modified (fix bug @CurrentDate)
-- TaiNT 		04-May-2007			Modified (fix bug effective date of xtfpt_PJP)
-- ThanhNQ		05-May-2007			Modified (add Average Sales, Average SKU, SucceedOrder fields)
-- =============================================================================

/*    
The fields return are:    
    
AttributeCode
AttributeName
TargetValue
CurrentValue


*/                    
SET NOCOUNT ON    
	Declare @Current_Date AS DateTime
	Declare @DateMask	As int
	Declare @TargetPercent	As Float
	

	-- Get current date
	-- Select @CurrentDate = getdate() 
	SELECT @Current_Date = convert(smalldatetime, floor(convert(float, getdate())))

	-- Get TargetPercent from fptParameter
	Select  @TargetPercent = Value
	From	fptParameters
	Where	ID LIKE '%004%' 
		
	-- Set default salesroute follow day in week	
	-- Set @@DateFirst = 1 -- set default start day in week is Sunday
	Select @DateMask=  DATEPART(dw, @Current_date) 
-- 				When 1 Then 64 -- Sunday
-- 				When 2 Then 32 -- Monday
-- 				When 3 Then 16 -- Tuesday
-- 				When 4 Then 8 -- Wednesday
-- 				When 5 Then 4 -- Thursday
-- 				When 6 Then 2 -- Friday
-- 				When 7 Then 1 -- Saturday
-- 				End
	Select	tmp.CustID, tmp.DateMask
	Into	#xpjp
	From
	(
		Select 	CustID, DateMask = 1
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Sunday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 2
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Monday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 3
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Tuesday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 4
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Wednesday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 5
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Thursday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 6
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Friday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 7
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Saturday = 1 
					And @Current_date between StartDate And EndDate
	)tmp
SET NOCOUNT OFF

Select * From
(
	Select AttributeCode,AttributeName, SUM(TargetValue) As TargetValue, SUM(CurrentValue) As CurrentValue From
	(
		Select  '01'  As AttributeCode, 'DSo ($)' As AttributeName, ISNULL(TargetSale,0) As TargetValue, 0 As CurrentValue
		From	fptSalesPlan
		Where	SlsPerID = @SlsPerID
		Union All
		Select  '01'  As AttributeCode, 'DSo ($)' As AttributeName, 0 As TargetValue, 
				isnull(SUM(BeforeDiscount),0) As CurrentValue
		From	fptOrderHeader
		Where 	SlsPerID=@SlsPerID and Status in (0,-1)     -- Open,Import SOL,don hang bi xoa
	)Tmp1
	Group By AttributeCode,AttributeName
	
	Union All

	Select AttributeCode,AttributeName, SUM(TargetValue) As TargetValue, SUM(CurrentValue) As CurrentValue From
	(
		Select  '02'  As AttributeCode, 'SKU' As AttributeName, ISNULL(TargetSKU,0) As TargetValue, 0 As CurrentValue
		From	fptSalesPlan
		Where	SlsPerID = @SlsPerID
		Union All
		Select  '02'  As AttributeCode, 'SKU' As AttributeName, 0 As TargetValue, 
				Isnull(SUM(Case When d.FreeItem=1 Then 0 Else 1 End), 0) As CurrentValue
		From 	fptOrderDetail d    
					Inner Join fptOrderHeader h On h.OrderCode = d.OrderCode    
		Where 	h.SlsPerID=@SlsPerID and h.Status in (0,-1) and d.FreeItem=0   
	)Tmp2
	Group By AttributeCode,AttributeName

	Union All

-- 	Select AttributeCode,AttributeName, SUM(TargetValue) As TargetValue, SUM(CurrentValue) As CurrentValue From
-- 	(
		Select  '03'  As AttributeCode, 'Ghe Tham' As AttributeName, ISNULL(Count(*),0) As TargetValue, 0 As CurrentValue
		From	#xpjp
		Where	DateMask = @DateMask
		
-- 	)Tmp3
-- 	Group By AttributeCode,AttributeName

	Union All

 	Select AttributeCode,AttributeName, SUM(TargetValue) As TargetValue, SUM(CurrentValue) As CurrentValue From
	(
		Select  '04'  As AttributeCode, 'Dat Hang' As AttributeName, Round(@TargetPercent * ISNULL(Count(*),0),0) As TargetValue, 0 As CurrentValue
		From	#xpjp
		Where	DateMask = @DateMask
		Union All
		Select  '04'  As AttributeCode, 'Dat Hang' As AttributeName, 0 As TargetValue, 
				Isnull(SUM(Case When h.TotalSKU>0 Then 1 Else 0 End), 0) As CurrentValue
		From 	fptOrderHeader h 
		Where 	h.SlsPerID=@SlsPerID and h.Status in (0,-1) 
	)Tmp4
	Group By AttributeCode,AttributeName

	Union All

	Select AttributeCode,AttributeName, SUM(TargetValue) As TargetValue, SUM(CurrentValue) As CurrentValue From
	(
		Select  '05'  As AttributeCode, 'MHTT ($)' As AttributeName, ISNULL(TargetStrategic,0) As TargetValue, 0 As CurrentValue
		From	fptSalesPlan
		Where	SlsPerID = @SlsPerID
		Union All
		Select  '05'  As AttributeCode, 'MHTT ($)' As AttributeName, 0 As TargetValue, 
				Isnull(SUM((d.Cases * d.UnitPerCase + d.Units)*d.UnitPrice), 0) As CurrentValue
		From 	fptOrderDetail d    
					Inner Join fptOrderHeader h On h.OrderCode = d.OrderCode  
					Inner Join xtfpt_ProdMaintain p On d.InvtID = p.InvtID 
					Inner Join xtfpt_ConcenProgH h1 On (h1.ProgID = p.ProgID And h1.Active = 1
													And h.OrderDate between h1.StartDate And h1.EndDate)
		Where 	h.SlsPerID=@SlsPerID and h.Status in (0,-1) and d.FreeItem=0   
	)Tmp5
	Group By AttributeCode,AttributeName

	Union All

-- 	Select AttributeCode,AttributeName, SUM(TargetValue) As TargetValue, SUM(CurrentValue) As CurrentValue From
-- 	(
		Select  '06'  As AttributeCode, 'Cham TB' As AttributeName, Isnull(Count(*), 0) As TargetValue, 
				0 As CurrentValue
		From
		(
			Select  distinct c.CustID
			From	xtfpt_DisplayH h
						Inner Join XTFPT_CustDis c On h.MaCTTB = c.MaCTTB
			Where	c.SlsPerID = @SlsPerID
						And @Current_Date between h.FromDate And h.ToDate
		)t1
		
-- 	)Tmp7
-- 	Group By AttributeCode,AttributeName

	Union All

	Select AttributeCode,AttributeName, SUM(TargetValue) As TargetValue, SUM(CurrentValue) As CurrentValue From
	(
		Select  '07'  As AttributeCode, 'Bao Phu TT' As AttributeName, Round(@TargetPercent * ISNULL(Count(*),0),0) As TargetValue, 0 As CurrentValue
		From	#xpjp
		Where	DateMask = @DateMask
		Union All
		Select  '07'  As AttributeCode, 'Bao Phu TT' As AttributeName, 0 As TargetValue, 
				Isnull(Count(*), 0) As CurrentValue
		From
		(
			Select  distinct h.CustID
			From 	fptOrderDetail d    
						Inner Join fptOrderHeader h On h.OrderCode = d.OrderCode  
						Inner Join xtfpt_ProdMaintain p On d.InvtID = p.InvtID 
						Inner Join xtfpt_ConcenProgH h1 On (h1.ProgID = p.ProgID And h1.Active = 1
														And h.OrderDate between h1.StartDate And h1.EndDate)
			Where 	h.SlsPerID=@SlsPerID and h.Status in (0,-1) and d.FreeItem=0   
		)t2
	)Tmp7
	Group By AttributeCode,AttributeName

	Union All

	Select  '08'  As AttributeCode, 'BQ DSo($)' As AttributeName, 0 As TargetValue, 
			0 As CurrentValue
	
	Union All

	Select  '09'  As AttributeCode, 'BQ SKU' As AttributeName, 0 As TargetValue, 
			0 As CurrentValue

	Union All

	Select  '10'  As AttributeCode, 'TLe Ban(%)' As AttributeName, 0 As TargetValue, 
			0 As CurrentValue
)TMP
Order By tmp.AttributeCode

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_DebtDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DebtDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DebtDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_DebtDB @SlsPerID varchar(10)    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DebtDB.sql
-- Purpose : Get information debt of customer 
--	     	 Sort by DocDate
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		01-Mar-2007			Initial
-- TaiNT		02-Mar-2007			Modified (Add NVBH,NVGH)
-- TaiNT 		08-Mar-2007			Modified (Add SlsPerID and remove 1 case)
-- TaiNT 		12-Mar-2007			Modified (Add NVThu Tien)
-- TaiNT		13-Mar-2007			Modified (don ban hang da ket thuc tren Palm nhung chua cap nhat AR&IN)
-- TaiNT		28-Mar-2007			Modified (Remove NVThu Tien, NVTT = NVGH)
-- TaiNT		05-Apr-2007			Modified ()
-- TaiNT		12-Apr-2007			Modified (VanSales)
-- =============================================================================
/*
This function return the debt in each order of customer 
who is managed by given salesman.
The recordset are sort by Customer code, OrderCode, OrderDate
The fields return are:

- CustomerCode 
- OrderCode 
- OrderDate 
- Debt
- SlsPerID 
- User1
- User2
- User3
- User4
*/
	Select CustomerCode, RefNbr As OrderCode, DocDate As OrderDate, DocBal As Debt,
			SlsPerID,
			User1 = 0,
			User2 = 0,
			User3 = '',
		    User4 = ''
 
	From
	(
		-- debt on SOL from ARDOC
		Select 	ad.CustID As CustomerCode, 
				ad.OrdNbr As RefNbr,
				ad.DocDate As DocDate,
				ad.SlsPerID As SlsPerID,
				DocBal = (Case When ad.DocType In ('IN','DM') 
						Then ad.DocBal 
						Else -ad.DocBal 
						End) - 
							(select isnull(sum(Amount),0) 
							from fptPayment 
							where custid = ad.custid and ordercode = ISNULL(ad.RefNbr,'')
									and Status in ('O','N')
							)
				
		From	ARDoc ad
					Inner Join Customer c On ad.CustID = c.CustID And c.Status = 'A'
					-- doi chieu cac cong no cua NVGH 
					Left Join xswSalesOrd so On (ad.OrdNbr = so.ARRefNbr And so.User5 = @SlsPerID)
		Where 	ad.Rlsed = 1 And ad.OpenDoc = 1 And ad.DocBal <> 0
					And ad.DocDate < getdate()
					And ad.DocType In ('IN','DM','CM')
					And (ad.SlsPerID = @SlsPerID or so.User5 = @SlsPerID ) -- NVBH or NVGH 
	
		Union All
		
		-- Cac don dat hang da ket thuc hoa don tren Palm nhung chua cap nhat AR & IN
		Select 	so.CustID As CustomerCode, 
				ISNULL(so.ARRefNbr,'') As RefNbr,
				so.OrderDate As DocDate,
				so.SlsPerID As SlsPerID,
				DocBal = (Case When so.OrderType In ('IN','SO') 
					 Then (oh.BeforeDiscount - oh.OrderDiscount - oh.Discount_Amo) 
					 Else -so.OrdAmt 
					 End ) - 
						(select isnull(sum(Amount),0) 
							from fptPayment 
							where custid = so.custid and ordercode = ISNULL(so.ARRefNbr,''))
		From	xswSalesOrd so
					Inner Join xswInvoiceHeader ih On so.ARRefNbr = ih.RefNbr
					Inner Join fptOrderHeader oh On (so.ARRefNbr = oh.OrderCode And oh.Status = 3)
					Inner Join Customer c On so.CustID = c.CustID And c.Status = 'A'
		Where	-- status 'C' but not Update AR&IN
		 		so.status = 'C' 
				And (ih.DocType != 'NA' and ih.BatNbr = '' or ih.SWFuture3 != 'NA' and ih.INBatNbr = '') 
				And ih.SWFuture1 != 'V'
				And so.OrderType In ('IN','SO')/*,'CM','CO'*/
				And (so.SlsPerID = @SlsPerID Or so.User5 = @SlsPerID ) -- NVBH or NVGH 
		
		Union All
		
		-- Cac don dat hang da ket thuc hoa don tren Palm va cap nhat ke toan thu vao kho nhung chua release cong no
		Select 	oh.CustID As CustomerCode, 
				ISNULL(oh.OrderCode,'') As RefNbr,
				oh.OrderDate As DocDate,
				oh.SlsPerID As SlsPerID,
				DocBal = (oh.BeforeDiscount - oh.OrderDiscount - oh.Discount_Amo) 
						 - 
						(select isnull(sum(Amount),0) 
							from fptPayment 
							where custid = oh.custid and ordercode = oh.OrderCode)
		From	fptOrderHeader oh 
					Inner Join Customer c On oh.CustID = c.CustID And c.Status = 'A'
		Where	oh.Status = 3 And Exists(Select RefNbr From ARDoc Where Rlsed = 0 And RefNbr = oh.OrderCode)
				And (oh.SlsPerID = @SlsPerID Or oh.User3 = @SlsPerID ) -- NVBH or NVGH 

		Union All
		
		-- Cac don ban hang da ket thuc hoa don tren Palm (chua import SOL hoac dang o trang thai sol 'N')
		Select 	oh.CustID As CustomerCode, 
				ISNULL(oh.OrderCode,'') As RefNbr,
				oh.OrderDate As DocDate,
				oh.SlsPerID As SlsPerID,
				DocBal = (oh.BeforeDiscount - oh.OrderDiscount - oh.Discount_Amo) 
						 - 
						(select isnull(sum(Amount),0) 
							from fptPayment 
							where custid = oh.custid and ordercode = oh.OrderCode)
		From	fptOrderHeader oh 
		Where	oh.OrderType = 0 -- ban hang
				And oh.Status = 3 And Not Exists(Select ARRefNbr From xswSalesOrd Where ARRefNbr = oh.OrderCode And Status = 'C')
					And (oh.SlsPerID = @SlsPerID  ) -- NVBH  		

	) tmp
	Order By  CustomerCode,OrderCode,OrderDate 
	
GO

--p_fpt_PDAVNM_DeliverDailyReportDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DeliverDailyReportDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DeliverDailyReportDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_DeliverDailyReportDB @SlsPerID varchar(10)    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DeliverDailyReportDB.sql
-- Purpose : Upload daily information of delivery man
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		02-Jan-2007			Initial
-- ThanhNQ		22-Mar-2007			Modified 
-- TaiNT		31-Mar-2007			Modified ( calculate values of attribute)
-- TaiNT		10-Apr-2007			Modified ( get 'han thanh toan' each customer)
-- =============================================================================

/*    
The fields return are:    
    
Orders
SKU
DailySales
OutTimeDebt
OnTimeDebt
Cash 
TotalMoney
DailyTotalDebt


*/   

	Declare @HanThanhToan int    
	Declare @now smalldatetime    
	Declare @today smalldatetime    

	Set @HanThanhToan = (Select Value From fptParameters where ID='005')        
	Set @now = getdate()    
	Set @today = convert(smalldatetime, floor(convert(float, @now))) 


	Select  ISNULL(SUM(Orders),0) As Orders,
			ISNULL(SUM(SKU),0) As SKU,
			ISNULL(SUM(DailySales),0) As DailySales,
			ISNULL(SUM(OutTimeDebt),0) As OutTimeDebt,
			ISNULL(SUM(OnTimeDebt),0) As OnTimeDebt,
			ISNULL(SUM(Cash),0) As Cash,
			ISNULL(SUM(TotalMoney),0) As TotalMoney,
			ISNULL(SUM(DailyTotalDebt),0) As DailyTotalDebt
	From
	(
		-- So Hoa Don  va tong so SKU va doanh so trong ngay
		Select	Count(*) As Orders, 
				Sum(TotalSKU) As SKU,
				Sum(BeforeDiscount - OrderDiscount - Discount_Amo) As DailySales,
				0 As OutTimeDebt,
				0 As OnTimeDebt,
				0 As Cash, 
				0 As TotalMoney,
				0 As DailyTotalDebt
		From	fptOrderHeader
		Where 	Status = 3 And OrderDate = @today
					And (SlsPerID = @SlsPerID or User3 = @SlsPerID) -- NVBH or NVGH

		Union All

		-- Thu No qua han  va Thu No dung han 
		Select	0 As Orders, 
				0 As SKU,
				0 As DailySales,
				OutTimeDebt = ISNULL(SUM((Case When DateDiff(day,Pay.DocDate, Pay.PayDate) > Pay.Terms Then 1 Else 0 End)* Pay.Amount),0),
				OnTimeDebt = ISNULL(SUM((Case When DateDiff(day,Pay.DocDate, Pay.PayDate) <= Pay.Terms Then 1 Else 0 End)* Pay.Amount),0),
				0 As Cash, 
				0 As TotalMoney,
				0 As DailyTotalDebt
		From
			(		
					-- payment cho nhung don hang Palm da import vao solomon
				Select p.PayDate,p.Amount,ar.DocDate,p.PayCode, p.OrderCode, cu.Terms  
				From	fptPayment p
							Inner Join Ardoc ar on p.OrderCode = ar.Refnbr    
							Inner Join xswSalesOrd so On so.ARRefNbr = ar.RefNbr 
							Inner Join Customer cu On p.CustID = cu.CustID  
				Where 	p.PayDate = @today
							And (p.SlsPerID = @SlsPerID or p.DeliverID = @SlsPerID) -- NVBH or NVGH
							And p.CashPay = 1 -- tra tien cho cong no cu
							And cu.Status = 'A'
				Union -- union distinct

				Select p.PayDate,p.Amount,h.OrderDate,p.PayCode, p.OrderCode, cu.Terms  
				From	fptPayment p
							Inner join fptOrderHeader h on p.OrderCode = h.OrderCode
							Inner Join Customer cu On p.CustID = cu.CustID
				Where 	p.PayDate = @today
							And (p.SlsPerID = @SlsPerID or p.DeliverID = @SlsPerID) -- NVBH or NVGH
							And p.CashPay = 1 -- tra tien cho cong no cu
							And cu.Status = 'A'
			) As Pay
		Union All

		/**** Tien mat: Don tra no trong ngay ****/
		Select	0 As Orders, 
				0 As SKU,
				0 As DailySales,
				0 As OutTimeDebt,
				0 As OnTimeDebt,
				p.Amount As Cash, 
				0 As TotalMoney,
				0 As DailyTotalDebt
		From fptPayment p
				Inner join fptOrderHeader h on p.OrderCode = h.OrderCode
		Where 	p.PayDate = @today
							And (p.SlsPerID = @SlsPerID or p.DeliverID = @SlsPerID) -- NVBH or NVGH
							And p.CashPay = 2 -- tra tien cho cac don giao trong ngay

		/**** TotalMoney = Cash + OutTimeDebt + OnTimeDebt ******/
		/**** DailyTotalDebt = DailySales - Cash ******/
	) As Tmp
	

GO

--p_fpt_PDAVNM_DiscBreakDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DiscBreakDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DiscBreakDB]
GO

Create Proc p_fpt_PDAVNM_DiscBreakDB @SlsPerID varchar(10)  
AS  

-- =============================================================================
-- Script  : p_fpt_PDAVNM_DiscBreakDB.sql
-- Purpose : Get information of all breaks (han muc)
--						of current sequence 
--         		
-- =============================================================================
-- User			     Date				Comments
-- =============================================================================
-- TaiNT		     10-Feb-2007		Created
-- =============================================================================

/*
	Return : all information for DiscBreakDB.pdb
DiscID
DiscSeq
LineNbr
BreakVal
DiscPer
DiscAmt
User1
User2

*/
		
	-- Begin - Return -------------------------------------------------------------
	Select	Distinct d.ProgID As DiscID, d.SeqID As DiscSeq, 
					 Cast(d.LineRef As Int) As LineNbr, 
					 d.BreakVal, d.DiscPer, d.DiscAmt,
					 0 As User1, 0 As User2
	From	xtfpt_PromBreak d
				Inner Join user_vr_PDAVNM_CurrentDiscount crd On d.ProgID = crd.DiscID
												And d.SeqID = crd.DiscSeq
	ORDER BY	DiscID, DiscSeq, LineNbr
	-- End - Return -------------------------------------------------------------


GO

--p_fpt_PDAVNM_DiscBundleDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DiscBundleDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DiscBundleDB]
GO

Create Proc p_fpt_PDAVNM_DiscBundleDB @SlsPerID varchar(10)  
AS  

-- =============================================================================
-- Script  : p_fpt_PDAVNM_DiscBundleDB.sql
-- Purpose : Get information of all bundle schema 
--         		
-- =============================================================================
-- User			     Date				Comments
-- =============================================================================
-- TaiNT		     10-Feb-2007		Created
-- TaiNT 			 05-Apr-2007		Modified (Product Group)
-- =============================================================================

/*
	Return : all information for DiscBundleDB.pdb
DiscID
DiscSeq
InvtID
BundleAmt
BundleQty
User1
User2


*/
		
	-- Begin - Return -------------------------------------------------------------
	Select DiscID, DiscSeq, InvtID, BundleAmt, BundleQty, User1, User2
	From 
		(
			Select	Distinct d.ProgID As DiscID, d.SeqID As DiscSeq, 
					 d.ProdID As InvtID, 0 As BundleAmt, d.Qty As BundleQty,
					 0 As User1, 0 As User2
			From	xtfpt_PromProd d
						Inner Join user_vr_PDAVNM_CurrentDiscount crd On d.ProgID = crd.DiscID
														And d.SeqID = crd.DiscSeq
						Inner Join xtfpt_PromProg g On (d.ProgID = g.ProgID And g.[Level] = 'G')

			Union All
			
			Select	Distinct d.ProgID As DiscID, d.SeqID As DiscSeq, 
							 d.ProdID As InvtID, 0 As BundleAmt, 0 As BundleQty,
							 0 As User1, 0 As User2
			From	xtfpt_PromProd d
						Inner Join user_vr_PDAVNM_CurrentDiscount crd On d.ProgID = crd.DiscID
														And d.SeqID = crd.DiscSeq
						Inner Join xtfpt_PromSeq s On (d.ProgID = s.ProgID 
														And d.SeqID = s.SeqID
														And s.S4Future10 = 1)

			Union All
			
			Select	Distinct d.ProgID As DiscID, d.SeqID As DiscSeq, 
							 d.SubProdID As InvtID, 0 As BundleAmt, 0 As BundleQty,
							 0 As User1, 0 As User2
			From	xtfpt_PromSubProd d
						Inner Join user_vr_PDAVNM_CurrentDiscount crd On d.ProgID = crd.DiscID
														And d.SeqID = crd.DiscSeq
						
		) As Tmp
	ORDER BY	DiscID, DiscSeq, InvtID
	-- End - Return -------------------------------------------------------------


GO

--p_fpt_PDAVNM_DiscCustDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DiscCustDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DiscCustDB]
GO

Create Proc p_fpt_PDAVNM_DiscCustDB @SlsPerID varchar(10)  
AS  

-- =============================================================================
-- Script  : p_fpt_PDAVNM_DiscCustDB.sql
-- Purpose : Get information of all customers in sequence
--         		
-- =============================================================================
-- User			     Date				Comments
-- =============================================================================
-- TaiNT		     10-Feb-2007		Created
-- TaiNT		     19-Apr-2007		Modified (Add condition KH si ,le)
-- TaiNT 			 04-May-2007		Modified (fix bug effective date of xtfpt_PJP)
-- =============================================================================

/*
	Return : all information for DiscCustDB.pdb
DiscID
DiscSeq
CustID
User1
User2


*/

	SET NOCOUNT ON    
	Declare @Current_Date AS DateTime
	Declare @DateMask	As int
	Declare @Role As varchar(1)

	--Select @Current_date = GetDate()
	SELECT @Current_date = convert(smalldatetime, floor(convert(float, getdate())))
	
	-- Get role of slsperid
-- 	Select	@Role = User5 
-- 	From	SalesPerson 
-- 	Where	SlsPerID = @SlsPerID

	-- Set default salesroute follow day in week	
	-- Set @@DateFirst = 1 -- set default start day in week is Sunday
	Select @DateMask=  DATEPART(dw, @Current_date) 
-- 				When 1 Then 64 -- Sunday
-- 				When 2 Then 32 -- Monday
-- 				When 3 Then 16 -- Tuesday
-- 				When 4 Then 8 -- Wednesday
-- 				When 5 Then 4 -- Thursday
-- 				When 6 Then 2 -- Friday
-- 				When 7 Then 1 -- Saturday
-- 				End
	Select	tmp.CustID, tmp.DateMask
	Into	#xpjp
	From
	(
		Select 	CustID, DateMask = 1
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Sunday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 2
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Monday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 3
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Tuesday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 4
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Wednesday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 5
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Thursday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 6
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Friday = 1 
					And @Current_date between StartDate And EndDate
		Union All
		Select 	CustID, DateMask = 7
		From	xtfpt_pjp
		Where	SlsPerID = @SlsPerID And Active = 1 And Saturday = 1 
					And @Current_date between StartDate And EndDate
	)tmp
		
	-- Begin - Return -------------------------------------------------------------
	Select	Distinct d.ProgID As DiscID, d.SeqID As DiscSeq, d.CustID As CustID, 
					 0 As User1, 0 As User2
	From	xtfpt_PromCust d
				Inner Join user_vr_PDAVNM_CurrentDiscount crd On d.ProgID = crd.DiscID
												And d.SeqID = crd.DiscSeq
				Inner Join #xpjp pjp On pjp.CustID = d.CustID COLLATE database_default
											And pjp.DateMask = @DateMask -- TaiNT 19Apr07 KH Si,le
	ORDER BY	DiscID, DiscSeq, CustID
	-- End - Return -------------------------------------------------------------


GO

--p_fpt_PDAVNM_DiscFreeItemDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DiscFreeItemDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DiscFreeItemDB]
GO

Create Proc p_fpt_PDAVNM_DiscFreeItemDB @SlsPerID varchar(10)  
AS  

-- =============================================================================
-- Script  : p_fpt_PDAVNM_DiscFreeItemDB.sql
-- Purpose : Get information of all sell products in sequence
--         		
-- =============================================================================
-- User			     Date				Comments
-- =============================================================================
-- TaiNT		     10-Feb-2007		Created
-- =============================================================================

/*
	Return : all information for DiscFreeItemDB.pdb
DiscID
DiscSeq
LineNbr
FreeItemID
Qty
User1
User2


*/
		
	
	-- Begin - Return -------------------------------------------------------------
	Select	Distinct d.ProgID As DiscID, d.SeqID As DiscSeq, 
					 Cast(d.LineRef As Int) As LineNbr, 
					 d.InvtID As FreeItemID, d.Qty,
					 0 As User1, 0 As User2
	From	xtfpt_PromFree d
				Inner Join user_vr_PDAVNM_CurrentDiscount crd On d.ProgID = crd.DiscID
												And d.SeqID = crd.DiscSeq
	ORDER BY	DiscID, DiscSeq, LineNbr, FreeItemID
	-- End - Return -------------------------------------------------------------

GO

--p_fpt_PDAVNM_DiscItemDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DiscItemDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DiscItemDB]
GO

Create Proc p_fpt_PDAVNM_DiscItemDB @SlsPerID varchar(10)  
AS  

-- =============================================================================
-- Script  : p_fpt_PDAVNM_DiscItemDB.sql
-- Purpose : Get information of all sell products in sequence
--         		
-- =============================================================================
-- User			     Date				Comments
-- =============================================================================
-- TaiNT		     10-Feb-2007		Created
-- TaiNT 			 06-Apr-2007		Modified(except for Product Group)
-- =============================================================================

/*
	Return : all information for DiscItemDB.pdb
DiscID
DiscSeq
InvtID
User1
User2

*/
		
	-- Begin - Return -------------------------------------------------------------
	Select	Distinct d.ProgID As DiscID, d.SeqID As DiscSeq, d.ProdID As InvtID, 
					 0 As User1, 0 As User2
	From	xtfpt_PromProd d
				Inner Join user_vr_PDAVNM_CurrentDiscount crd On d.ProgID = crd.DiscID
												And d.SeqID = crd.DiscSeq
				Inner Join xtfpt_PromProg g On (d.ProgID = g.ProgID 
													And g.[Level] = 'L')
				Inner Join xtfpt_PromSeq s On (d.ProgID = s.ProgID 
													And d.SeqID = s.SeqID
													And s.S4Future10 = 0)
	ORDER BY	DiscID, DiscSeq, InvtID
	-- End - Return -------------------------------------------------------------


GO

--p_fpt_PDAVNM_DiscountDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DiscountDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DiscountDB]
GO

Create Proc p_fpt_PDAVNM_DiscountDB @SlsPerID varchar(10)  
AS  

-- =============================================================================
-- Script  : p_fpt_PDAVNM_DiscountDB.sql
-- Purpose : Get information of all current discounts 
--         		
-- =============================================================================
-- User			     Date				Comments
-- =============================================================================
-- TaiNT		     09-Feb-2007		Created
-- TaiNT		     05-Apr-2007		Modified (Product Group)
-- =============================================================================

/*
	Return : all information for DiscountDB.pdb
*/
		
	-- Begin - Return -------------------------------------------------------------
	Select	Distinct d.ProgID As DiscID, 
		Case When s.S4Future10 = 1 Then 'G' Else d.[Level] End As DiscType,
		d.Descr, d.Type As DiscClass,
		0 As User1, 0 As User2
	From	xtfpt_PromProg d
				Inner Join xtfpt_PromSeq s On d.ProgID = s.ProgID
				Inner Join user_vr_PDAVNM_CurrentDiscount crd On d.ProgID = crd.DiscID
	ORDER BY	d.ProgID
	-- End - Return -------------------------------------------------------------


GO

--p_fpt_PDAVNM_DiscSeqDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DiscSeqDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DiscSeqDB]
GO

Create Proc p_fpt_PDAVNM_DiscSeqDB @SlsPerID varchar(10)  
AS  

-- =============================================================================
-- Script  : p_fpt_PDAVNM_DiscSeqDB.sql
-- Purpose : Get information of all current sequence of discount 
--         		
-- =============================================================================
-- User			     Date				Comments
-- =============================================================================
-- TaiNT		     09-Feb-2007		Created
-- =============================================================================

/*
	Return : all information for DiscSeqDB.pdb
*/
		
	-- Begin - Return -------------------------------------------------------------
	Select	Distinct d.ProgID As DiscID, d.SeqID As DiscSeq, d.Descr, 
					 d.Method, d.BreakBy, d.FromDate As StartDate, d.ToDate As EndDate,
					 d.Prorate As Prograte, d.AllCust, d.ExceptProd, d.S4Future09 As ChooseFreeItem,
					 S4Future10 As User1, -- CTKM ProductGroup (0,1)
					 0 As User2
	From	xtfpt_PromSeq d
				Inner Join user_vr_PDAVNM_CurrentDiscount crd On d.ProgID = crd.DiscID
												And d.SeqID = crd.DiscSeq
	ORDER BY	d.ProgID, d.SeqID
	-- End - Return -------------------------------------------------------------

GO

--p_fpt_PDAVNM_DisplayProductDB.sql

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DisplayProductDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DisplayProductDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_DisplayProductDB @SlsPerID varchar(10)    
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_DisplayProductDB.sql
-- Purpose : Upload display products information 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		13-Feb-2007			Initial
-- TaiNT		18-Apr-2007			Modified (fix bug @CurrentDate)
-- TaiNT		08-May-2007			Modified (add 2 field BrandGroup, AndOr)
-- =============================================================================

/*    
The fields return are:    

ProgramCode
ProductCode
Quantity
  
*/

	
               
	Declare @CurrentDate As Datetime

	-- Get current date
	--Select @CurrentDate = getdate() 
	SELECT @CurrentDate = convert(smalldatetime, floor(convert(float, getdate())))

	Select Distinct h.MaCTTB As ProgramCode, d.InvtID As ProductCode, 
	   	   d.Objective As Quantity, 
		   Case When ISNULL(d.User3,0)<= 0 Then 1 Else d.User3 End As BrandGroup, 
		   Case When ISNULL(d.User10,0)<= 0 Then 0 Else d.User10 End  As AndOr,
		   0 As User1,
		   0 As User2
	From xtfpt_DisplayD d
		Inner Join xtfpt_Displayh h On h.MaCTTB = d.MaCTTB
		Inner Join xtfpt_CustDis c On h.MaCTTB = c.MaCTTB And c.SlsPerID = @SlsPerID
	Where	@CurrentDate between h.FromDate And h.ToDate
	Order By	ProgramCode, BrandGroup, ProductCode


	
	
	 
GO

--p_fpt_PDAVNM_DisplayProgramDB.sql

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DisplayProgramDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DisplayProgramDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_DisplayProgramDB @SlsPerID varchar(10)    
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_DisplayProgramDB.sql
-- Purpose : Upload display program information 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		13-Feb-2007			Initial
-- TaiNT		19-Apr-2007			Modified ( Update CurrentDate)
-- =============================================================================

/*    
The fields return are:    

CustomerCode
ProgramCode
TargetSales
Description
  
*/

	
               
	Declare @CurrentDate As Datetime

	-- Get current date
	--Select @CurrentDate = getdate() 
	SELECT @CurrentDate = convert(smalldatetime, floor(convert(float, getdate())))

	Select c.CustID As CustomerCode, c.MaCTTB As ProgramCode, 
	   	   c.ObjAmount As TargetSales, h.Descr As [Description],c.ObjPart As Quantity
	From xtfpt_DisplayH h
		Inner Join XTFPT_CustDis c On h.MaCTTB = c.MaCTTB
	Where	c.SlsPerID = @SlsPerID
			And @CurrentDate between h.FromDate And h.ToDate
	Order By CustomerCode, ProgramCode

	
	
	 
GO

--p_fpt_PDAVNM_DownloadCatDisplayDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DownloadCatDisplayDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DownloadCatDisplayDB]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE    procedure p_fpt_PDAVNM_DownloadCatDisplayDB
@CustomerCode varchar(50),
@Category varchar(30),
@DisplayResult int,
@EvaluateDate datetime,
@SlsPerId varchar(80)
AS
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DownloadCustomerVisitDB.sql
-- Purpose : Insert CatDisplay into table
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		26-Feb-2007			Initial
-- TaiNT		20-Apr-2007			Modified (add EvaluateDate field)
-- ThanhNQ		04-May-2007			Modified (Delete duplicate record before insert)
-- =============================================================================
DELETE FROM fptCatDisplay 
WHERE 	SlsPerId = @SlsPerId
AND		CustID = @CustomerCode
AND 	Category = @Category
AND		CreateDate =@EvaluateDate
--Day(CreateDate) = Day(@EvaluateDate) AND Month(CreateDate) = Month(@EvaluateDate) AND Year(CreateDate) = Year(@EvaluateDate)


INSERT INTO fptCatDisplay         	 VALUES(@SlsPerId,
						@CustomerCode,
						@Category,
						@EvaluateDate,
						@DisplayResult)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_DownloadCustomerStockDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DownloadCustomerStockDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DownloadCustomerStockDB]
GO

CREATE   procedure p_fpt_PDAVNM_DownloadCustomerStockDB
@SlsPerId varchar(80),
@CustID varchar(50),
@InvtID varchar(50),
@CreatedDate datetime,
@Cases int,
@Units int,
@Checked char(1),
@User1 int,
@User2 int,
@User3 varchar(50),
@User4 varchar(50)

AS
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DownloadCustomerStockDB.sql
-- Purpose : Insert CustomerStock into table
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		26-Feb-2007			Initial
-- TaiNT		20-Apr-2007			Modified (add CreatedDate field)
-- ThanhNQ		04-May-2007			Modified (Delete duplicate record before insert)
-- =============================================================================
DELETE 	FROM fptCustomerStock 
		WHERE 	SlsPerId = @SlsPerId
		AND		CustID = @CustID
		AND 	InvtID = @InvtID
		AND		OrderDate =@CreatedDate

INSERT INTO fptCustomerStock          VALUES(@SlsPerId,
						@CustID,
						@InvtID ,
						@CreatedDate,
						@Cases ,
						@Units ,
						@Checked ,
						@User1 ,
						@User2 ,
						@User3 ,
						@User4 )



GO

--p_fpt_PDAVNM_DownloadCustomerVisitDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DownloadCustomerVisitDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DownloadCustomerVisitDB]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO






CREATE     procedure p_fpt_PDAVNM_DownloadCustomerVisitDB
@CreatedDate datetime,
@SlsPerId varchar(80),
@CustomerCode varchar(50),
@StartTime varchar(17),
@EndTime varchar(17),
@StartDateTime datetime,
@EndDateTime datetime
AS
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DownloadCustomerVisitDB.sql
-- Purpose : Insert CustomerVisit  into table
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		26-Feb-2007			Initial
-- TaiNT		20-Apr-2007			Modified (add CreatedDate field)
-- ThanhNQ		02-May-2007			Modified (Add StartDateTime,EnddateTime fields)
-- =============================================================================

INSERT INTO fptCustomerVisit          VALUES(@CreatedDate,
						@SlsPerId,
						@CustomerCode ,
						@StartTime,
						@EndTime,
						@StartDateTime,
						@EndDateTime)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_DownloadDisplayResultDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DownloadDisplayResultDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DownloadDisplayResultDB]
GO

CREATE    procedure p_fpt_PDAVNM_DownloadDisplayResultDB
@CustomerCode varchar(50),
@ProgramCode varchar(50),
@ProductCode varchar(50),
@Quantity int,
@CreatedDate datetime,
@SlsPerId varchar(80)
AS
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DownloadDisplayResultDB.sql
-- Purpose : Insert DisplayResult  into table
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		26-Feb-2007			Initial
-- TaiNT		20-Apr-2007			Modified (add CreatedDate field)
-- ThanhNQ		04-May-2007			Modified (Delete duplicate records before insert)
-- =============================================================================

DELETE 	FROM fptDisplayResult 
		WHERE 	SlsPerId = @SlsPerId
		AND		CustID = @CustomerCode
		AND		InvtID = @ProductCode
		AND 	ProgramCode = @ProgramCode
		AND		CreateDate =@CreatedDate

INSERT INTO fptDisplayResult         	 VALUES(@CustomerCode,
						@ProgramCode,
						@ProductCode,
						@Quantity,			
						@CreatedDate,
						@SlsPerId)


GO

--p_fpt_PDAVNM_DownloadIncentivePaymentDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DownloadIncentivePaymentDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DownloadIncentivePaymentDB]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO




CREATE    procedure p_fpt_PDAVNM_DownloadIncentivePaymentDB
@SlsPerId varchar(80),
@CustID varchar(50),
@ProgramCode varchar(50),
@Amount int,
@CreatedDate datetime,
@User1 int,
@User2 int,
@User3 varchar(50),
@User4 varchar(50)
AS
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DownloadCustomerVisitDB.sql
-- Purpose : Insert CatDisplay into table
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		26-Feb-2007			Initial
-- TaiNT		20-Apr-2007			Modified (add EvaluateDate field)
-- =============================================================================

INSERT INTO fptIncentivePayment	        	VALUES(@SlsPerId,
						@CustID,
						@ProgramCode,
						@Amount,
						@CreatedDate,
						'0',
						@User1,
						@User2,
						@User3,
						@User4)



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_DownloadOrderDetailDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DownloadOrderDetailDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DownloadOrderDetailDB]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE procedure p_fpt_PDAVNM_DownloadOrderDetailDB
@OrderCode varchar(50),
@ProductCode varchar(50),
@PromotionTitleID varchar(50),
@FreeItem char(1),
@BudgetID varchar(50),
@Cases int,
@Units int,
@UnitPerCase int,
@UnitPrice int,
@Discount int,
@AutoOrManual char(10),
@User1 int,
@User2 int,
@User3 varchar(50),
@User4 varchar(50),
@SlsPerId varchar(80)
AS
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DownloadOrderDetailDB.sql
-- Purpose : Insert order detail into table
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		23-Feb-2007			Initial

-- =============================================================================

INSERT INTO fptOrderDetail          VALUES(@OrderCode,
					@ProductCode,
 					@PromotionTitleID,
					@FreeItem,
					@BudgetID,
					@Cases,
					@Units,
					@UnitPerCase,
					@UnitPrice,
					@Discount,
					@AutoOrManual,
					@User1,
					@User2,
					@User3,
					@User4)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_DownloadOrderDiscountDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DownloadOrderDiscountDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DownloadOrderDiscountDB]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE procedure p_fpt_PDAVNM_DownloadOrderDiscountDB
@OrderCode varchar(50),
@DiscID varchar(50),
@DiscSeq varchar(50),
@DisctblAmt int,
@DisctblQty int,
@DiscAmt int,
@FreeItemQty int,
@DiscType char(10),
@BreakBy char(10),
@DiscFor char(10),
@DItem varchar(50),
@FreeItemID varchar(50),
@User1 int,
@User2 int,
@User3 varchar(50),
@User4 varchar(50)
AS
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DownloadOrderDiscountDB.sql
-- Purpose : Insert order discountl into table
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		23-Feb-2007			Initial

-- =============================================================================

INSERT INTO fptOrderDiscount          VALUES(@OrderCode,
					@DiscID,
 					@DiscSeq,
					@DisctblAmt,
					@DisctblQty,
					@DiscAmt,
					@FreeItemQty,
					@DiscType,
					@BreakBy,
					@DiscFor,
					@DItem,
					@FreeItemID,
					@User1,
					@User2,
					@User3,
					@User4)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_DownloadOrderHeaderDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DownloadOrderHeaderDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DownloadOrderHeaderDB]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


CREATE procedure p_fpt_PDAVNM_DownloadOrderHeaderDB
@OrderCode varchar(50),
@CustID varchar(50),
@OrderDate datetime,
@TotalSKU int,
@TotalCase int,
@TotalUnit int,
@BeforeDiscount int,
@OrderDiscount int,
@Discount_Amo int,
@Discount_Qua int,
@OrderType char(10),
@Status char(10),
@CreatedTime varchar(18),
@LUpdatedTime varchar(18),
@CreatedTStamp int,
@LUpdatedTStamp int,
@bCompleted char(10),
@CompletedTime varchar(18),
@User1 int,
@User2 int,
@User3 varchar(50),
@User4 varchar(50),
@SlsPerId varchar(80)
AS 
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DownloadOrderHeaderDB.sql
-- Purpose : Insert order header into table
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		23-Feb-2007			Initial

-- =============================================================================

INSERT INTO fptOrderHeader       VALUES(@OrderCode,
					@CustID,
					@OrderDate,
					@TotalSKU,
					@TotalCase,
					@TotalUnit,
					@BeforeDiscount,
					@OrderDiscount,
					@Discount_Amo,
					@Discount_Qua,
					@OrderType,
					@Status,
					@CreatedTime,
					@LUpdatedTime,
					@CreatedTStamp,
					@LUpdatedTStamp,
					@bCompleted,
					@CompletedTime,
					@User1,
					@User2,
					@User3,
					@User4,
					@SlsPerId)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_DownloadPaymentDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DownloadPaymentDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DownloadPaymentDB]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO




CREATE    procedure p_fpt_PDAVNM_DownloadPaymentDB
@CustomerCode varchar(50),
@OrderCode varchar(50),
@PayDate datetime,
@Amount int,
@Type char(1),
@Status char(1),
@CreatedTime varchar(18),
@LUpdatedTime varchar(18),
@CreatedTStamp int,
@LUpdatedTStamp int,
@CashPay 	int,
@User1		int,
@User2		int,
@PayCode varchar(50),
@SlsPerId varchar(10),
@DeliverId varchar(10),
@User3 varchar(50),
@User4 varchar(50)



AS
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DownloadPaymentDB.sql
-- Purpose : Insert Payment into table
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		26-Feb-2007			Initial

-- =============================================================================

INSERT INTO fptPayment          VALUES(@CustomerCode,
						@OrderCode,
						@PayDate ,
						@Amount,
						@Type ,
						@Status ,
						@CreatedTime ,
						@LUpdatedTime ,
						@CreatedTStamp ,
						@LUpdatedTStamp,
						@CashPay,
						@User1,
						@User2,
						@PayCode,
						@SlsPerId,
						@DeliverId,
						@User3,
						@User4)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_DownloadSystemDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DownloadSystemDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DownloadSystemDB]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE procedure p_fpt_PDAVNM_DownloadSystemDB
@LastSyncTime datetime,
@SyncTimeStamp int,
@DefSlsRouteID int,
@StartCode int,
@CurrentRole char,
@CurrentUser varchar(50),
@UserCode varchar(50) ,
@User1 int,
@User2 int,
@User3 varchar(50),
@User4 varchar(50),
@SlsPerId varchar(80)
AS
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DownloadSystemDB.sql
-- Purpose : Insert system  into table
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		26-Feb-2007			Initial

-- =============================================================================

INSERT INTO fpt_PDAVNM_SystemDB          VALUES(    @UserCode ,
							@CurrentUser,
							@CurrentRole ,
							@LastSyncTime ,
							@SyncTimeStamp ,
							@DefSlsRouteID ,
							@StartCode ,
							@User1 ,
							@User2 ,
							@User3 ,
							@User4)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_DownloadToolDisplayDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_DownloadToolDisplayDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_DownloadToolDisplayDB]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO


CREATE     procedure p_fpt_PDAVNM_DownloadToolDisplayDB
@EvaluateDate	datetime,
@SlsPerId varchar(80),
@CustomerCode varchar(50),
@ProgramCode varchar(30),
@Quantity int,
@DisplayResult char(1)

AS
-- =============================================================================
-- Script  : p_fpt_PDAVNM_DownloadToolDisplayDB.sql
-- Purpose : Insert toolDisplay  into table
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		26-Feb-2007			Initial
-- ThanhNQ		04-May-2007			Modified (Delete duplicate record before insert)
-- =============================================================================

DELETE 	FROM fptPOSMDisplay 
		WHERE 	SlsPerId = @SlsPerId
		AND		CustID = @CustomerCode
		AND 	POSMCode = @ProgramCode
		AND		CreateDate =@EvaluateDate

INSERT INTO fptPOSMDisplay         	 VALUES(@SlsPerId,
						@CustomerCode,
						@ProgramCode,
						@Quantity,
						@EvaluateDate,
						@DisplayResult)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_InsertParameters.sql
-- =============================================================================
-- Script  : p_fpt_PDAVNM_InsertParameters.sql
-- Purpose : Insert parameters value
-- Used ID: 
--		001: The last date which ran SKUSuggest (MM/DD/YYYY)
--		002: Number of days which we get order detail history to calculate SKUSuggest
--		003: Number of days which we get order detail history to calculate HighSKU
--		004: The Number of % for calculate target Dat Hang
--		005: Over Due Date (for Debt on PDA)
--		         		
-- =============================================================================
-- User			          Ref     Date				Comments
-- =============================================================================
-- TaiNT		          1.0     17-Mar-2007		Created
-- =============================================================================


/* Check parameter of ID = 001 and Insert parameter 001 */

If Not Exists(
	Select	* From fptParameters 
	Where	ID LIKE '%001%'  )
Begin
	Insert Into fptParameters
	Values('001','The last date which ran SKUSuggest (MM/DD/YYYY)','03/17/2007')
End

/* Check parameter of ID = 002 and Insert parameter 002 */

If Not Exists(
	Select	* From fptParameters 
	Where	ID LIKE '%002%'  )
Begin
	Insert Into fptParameters
	Values('002','Number of days which we get order detail history to calculate SKUSuggest','250')
End

/* Check parameter of ID = 003 and Insert parameter 003 */

If Not Exists(
	Select	* From fptParameters 
	Where	ID LIKE '%003%'  )
Begin
	Insert Into fptParameters
	Values('003','Number of days which we get order detail history to calculate HighSKU','250')
End

/* Check parameter of ID = 004 and Insert parameter 004 */

If Not Exists(
	Select	* From fptParameters 
	Where	ID LIKE '%004%'  )
Begin
	Insert Into fptParameters
	Values('004','The Number of % for calculate target Dat Hang','0.8')
End

/* Check parameter of ID = 005 and Insert parameter 005 */

If Not Exists(
	Select	* From fptParameters 
	Where	ID LIKE '%005%'  )
Begin
	Insert Into fptParameters
	Values('005','Over Due Date (for Debt on PDA)','7')	
End


GO

--p_fpt_PDAVNM_ManualPromotionDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_ManualPromotionDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_ManualPromotionDB]
GO

Create Proc p_fpt_PDAVNM_ManualPromotionDB @SlsPerID varchar(10)  
AS  
-- =============================================================================
-- Script  : p_fpt_PDAVNM_ManualPromotionDB.sql
-- Purpose : Create procedure p_fpt_PDAVNM_ManualPromotionDB 
--         		and upload manual promotion 
-- =============================================================================
-- User			          Ref     Date				Comments
-- =============================================================================
-- TaiNT		          1.0     11-Apr-2007		Created
-- =============================================================================

/*
Budget	Discount Quantity
BreakBy	KM theo loai nao
User1	
DiscID	Ma KM
Descr	Mo ta 
User2	String		

*/
	Declare @CurrentDate As Datetime

	-- Get current date
	--Select @CurrentDate = getdate() 
	SELECT @CurrentDate = convert(smalldatetime, floor(convert(float, getdate())))


	--Returned query
	Select	Tmp.DiscID, Tmp.Descr As Descr, 0 As Budget, 'A' As BreakBy,
			0 As User1, '' As User2
	From
		(
			Select distinct ProID As DiscID, Descr
			From	xtfpt_Promotion
			Where 	ActiveFlg = 1
			Union All
			Select distinct MaCTTB As DiscID, Descr
			From	xtfpt_DisplayH
			Where 	@CurrentDate between FromDate And ToDate

		) As Tmp
	Order By	Tmp.DiscID





GO

--p_fpt_PDAVNM_MonthlyReportDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_MonthlyReportDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_MonthlyReportDB]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



CREATE   PROCEDURE p_fpt_PDAVNM_MonthlyReportDB @SlsPerID varchar(10)    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_MonthlyReportDB.sql
-- Purpose : Upload daily information of salesperson
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		28-Mar-2007			Initial
-- =============================================================================

/*    
The fields return are:    

*/  
Select * From
(
	Select AttributeCode,AttributeName, SUM(TargetValue) As TargetValue, SUM(CurrentValue) As CurrentValue From
	(
		Select  '01'  As AttributeCode, 'DSo ($)' As AttributeName, ISNULL(CT_DSo,0) As TargetValue, ISNULL(DoanhSoThang,0) As CurrentValue
		From	fptMonthReport
		Where	SlsPerID = @SlsPerID
	)Tmp1
	Group By AttributeCode,AttributeName
	
	Union All

	Select AttributeCode,AttributeName, SUM(TargetValue) As TargetValue, SUM(CurrentValue) As CurrentValue From
	(
		Select  '02'  As AttributeCode, 'SKU' As AttributeName, ISNULL(CT_SKU,0) As TargetValue, ISNULL(SKU,0) As CurrentValue
		From	fptMonthReport
		Where	SlsPerID = @SlsPerID
		
	)Tmp2
	Group By AttributeCode,AttributeName

	Union All

 	Select AttributeCode,AttributeName, SUM(TargetValue) As TargetValue, SUM(CurrentValue) As CurrentValue From
 	(
		Select  '03'  As AttributeCode, 'HoaDon' As AttributeName, 0 As TargetValue, ISNULL(HoaDon,0) As CurrentValue
		From	fptMonthReport
		Where	SlsPerID = @SlsPerID
		
 	)Tmp3
	Group By AttributeCode,AttributeName

	Union All

 	Select AttributeCode,AttributeName, SUM(TargetValue) As TargetValue, SUM(CurrentValue) As CurrentValue From
 	(
		Select  '04'  As AttributeCode, 'MHTT($)' As AttributeName, ISNULL(CT_DSoMHTT,0) As TargetValue, ISNULL(DS_MHTT,0) As CurrentValue
		From	fptMonthReport
		Where	SlsPerID = @SlsPerID
		
 	)Tmp4
	Group By AttributeCode,AttributeName

	Union All

 	Select AttributeCode,AttributeName, SUM(TargetValue) As TargetValue, SUM(CurrentValue) As CurrentValue From
 	(
		Select  '05'  As AttributeCode, 'LPPC' As AttributeName, 0 As TargetValue, 
				Case When HoaDon > 0 Then SKU/HoaDon Else 0 End As CurrentValue
		From	fptMonthReport
		Where	SlsPerID = @SlsPerID
		
 	)Tmp5
	Group By AttributeCode,AttributeName


)TMP
Order By tmp.AttributeCode


GO

--p_fpt_PDAVNM_OPSetupDocumentDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_OPSetupDocumentDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_OPSetupDocumentDB]
GO

Create Proc p_fpt_PDAVNM_OPSetupDocumentDB @SlsPerID varchar(10)  
AS  

-- =============================================================================
-- Script  : p_fpt_PDAVNM_OPSetupDocumentDB.sql
-- Purpose : Get information of OPSetup by Document Discount
--         		
-- =============================================================================
-- User			     Date				Comments
-- =============================================================================
-- TaiNT		     10-Feb-2007		Created
-- =============================================================================

/*
	Return : all information for OPSetupDocumentDB.pdb
OPLine
ChkDependence
DiscID1
DiscID2
DiscID3
DiscID4
DiscID5
DiscID6
DiscID7
User1
User2

*/
	SET NOCOUNT ON -- BEGIN CALCULATE IN STORE	
	
	Select  IDENTITY(int, 1,1) AS OPLine,
			AddPer As ChkDependence,
			ProgID As DiscID1, ProgID01 As DiscID2, ProgID02 As DiscID3,
			ProgID03 As DiscID4, ProgID04 As DiscID5, ProgID05 As DiscID6,
			ProgID06 As DiscID7
	Into	#OPSetupDocument
	From 	xtfpt_PromDoc

	SET NOCOUNT OFF -- END CALCULATE IN STORE	

	-- Begin - Return -------------------------------------------------------------
	Select	Distinct Cast (OPLine As varchar(3)) As OPLine, ChkDependence, 
					 DiscID1, DiscID2, DiscID3, DiscID4,
					 DiscID5, DiscID6, DiscID7,		
					 0 As User1, 0 As User2
	From	#OPSetupDocument 
	ORDER BY	OPLine
	-- End - Return -------------------------------------------------------------


GO

--p_fpt_PDAVNM_OPSetupGroupDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_OPSetupGroupDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_OPSetupGroupDB]
GO

Create Proc p_fpt_PDAVNM_OPSetupGroupDB @SlsPerID varchar(10)  
AS  

-- =============================================================================
-- Script  : p_fpt_PDAVNM_OPSetupGroupDB.sql
-- Purpose : Get information of OPSetup by Group Discount
--         		
-- =============================================================================
-- User			     Date				Comments
-- =============================================================================
-- TaiNT		     10-Feb-2007		Created
-- TaiNT		     06-Apr-2007		Modified (using fptPromGroup instead of xtfpt_PromGroup)
-- =============================================================================

/*
	Return : all information for OPSetupGroupDB.pdb
OPLine
ChkDependence
DiscID1
DiscID2
DiscID3
DiscID4
DiscID5
DiscID6
DiscID7
User1
User2

*/
	SET NOCOUNT ON -- BEGIN CALCULATE IN STORE	
	
	Select  IDENTITY(int, 1,1) AS OPLine,
			AddPer As ChkDependence,
			ProgID As DiscID1, ProgID01 As DiscID2, ProgID02 As DiscID3,
			ProgID03 As DiscID4, ProgID04 As DiscID5, ProgID05 As DiscID6,
			ProgID06 As DiscID7
	Into	#OPSetupGroup
	From 	fptPromGroup

	SET NOCOUNT OFF -- END CALCULATE IN STORE	

	-- Begin - Return -------------------------------------------------------------
	Select	Distinct Cast (OPLine As varchar(3)) As OPLine, ChkDependence, 
					 DiscID1, DiscID2, DiscID3, DiscID4,
					 DiscID5, DiscID6, DiscID7,		
					 0 As User1, 0 As User2
	From	#OPSetupGroup 
	ORDER BY	OPLine
	-- End - Return -------------------------------------------------------------


GO

--p_fpt_PDAVNM_OPSetupLineDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_OPSetupLineDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_OPSetupLineDB]
GO

Create Proc p_fpt_PDAVNM_OPSetupLineDB @SlsPerID varchar(10)  
AS  

-- =============================================================================
-- Script  : p_fpt_PDAVNM_OPSetupLineDB.sql
-- Purpose : Get information of OPSetup by Line Discount
--         		
-- =============================================================================
-- User			     Date				Comments
-- =============================================================================
-- TaiNT		     10-Feb-2007		Created
-- TaiNT		     06-Apr-2007		Modified (using fptPromLine instead of xtfpt_PromLine)
-- =============================================================================

/*
	Return : all information for OPSetupLineDB.pdb
OPLine
ChkDependence
DiscID1
DiscID2
DiscID3
DiscID4
DiscID5
DiscID6
DiscID7
User1
User2

*/
	SET NOCOUNT ON -- BEGIN CALCULATE IN STORE	
	
	Select  IDENTITY(int, 1,1) AS OPLine,
			AddPer As ChkDependence,
			ProgID As DiscID1, ProgID01 As DiscID2, ProgID02 As DiscID3,
			ProgID03 As DiscID4, ProgID04 As DiscID5, ProgID05 As DiscID6,
			ProgID06 As DiscID7
	Into	#OPSetupLine
	From 	fptPromLine

	SET NOCOUNT OFF -- END CALCULATE IN STORE	

	-- Begin - Return -------------------------------------------------------------
	Select	Distinct Cast (OPLine As varchar(3)) As OPLine, ChkDependence, 
					 DiscID1, DiscID2, DiscID3, DiscID4,
					 DiscID5, DiscID6, DiscID7,		
					 0 As User1, 0 As User2
	From	#OPSetupLine 
	ORDER BY	OPLine
	-- End - Return -------------------------------------------------------------


GO

--p_fpt_PDAVNM_OrderDetailDB.sql

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_OrderDetailDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_OrderDetailDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_OrderDetailDB  @SlsPerID varchar(10)
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_OrderDetailDB.sql
-- Purpose : Upload order detail 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		23-Feb-2007			Initial
-- TaiNT		12-Apr-2007			Modified (VanSales)
-- =============================================================================


-- SQL Go Here

	Select	d.OrderCode, d.InvtID, d.PromotionTitleID, d.FreeItem,
			d.BudgetID, d.Cases, d.Units, d.UnitPerCase, d.UnitPrice,
			d.Discount, d.AutoOrManual, 
			(d.Cases * d.UnitPerCase + d.Units) As User1, d.User2, d.User3, d.User4
	From 	fptOrderDetail d
				Inner Join fptOrderHeader h On (d.OrderCode = h.OrderCode 
												And (
														(h.Status = -1 And h.SlsPerID = @SlsPerID) 
													 or (h.Status = 2 And h.User3 = @SlsPerID)
													 or (h.Status = 0 And h.OrderType = 0 And h.SlsPerID = @SlsPerID)-- VanSales
													 ) 
												And (h.TotalCase > 0 Or h.TotalUnit > 0))
	ORDER BY d.OrderCode, d.InvtID, d.FreeItem, d.PromotionTitleID

GO

--p_fpt_PDAVNM_OrderDiscountDB.sql

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_OrderDiscountDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_OrderDiscountDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_OrderDiscountDB  @SlsPerID varchar(10)
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_OrderDiscountDB.sql
-- Purpose : Upload order discount 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		23-Feb-2007			Initial
-- TaiNT		12-Apr-2007			Modified(add VanSales)
-- =============================================================================


-- SQL Go Here

	Select	d.OrderCode, d.DiscID, d.DiscSeq, d.DisctblAmt, d.DisctblQty,
			d.DiscAmt, d.FreeItemQty, d.DiscType, d.BreakBy, d.DiscFor,
			d.DItem,d.FreeItemID, d.User1, d.User2, d.User3, d.User4
	From 	fptOrderDiscount d
				Inner Join fptOrderHeader h On (d.OrderCode = h.OrderCode 
												And (
														(h.Status = -1 And h.SlsPerID = @SlsPerID) 
													 or (h.Status = 2 And h.User3 = @SlsPerID)
													 or (h.Status = 0 And h.OrderType = 0 And h.SlsPerID = @SlsPerID)-- VanSales
													 ) 
												And (h.TotalCase > 0 Or h.TotalUnit > 0))
	Order By d.OrderCode, d.DiscID, d.DiscSeq, d.DItem, d.FreeItemID


GO

--p_fpt_PDAVNM_OrderHeaderDB.sql

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_OrderHeaderDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_OrderHeaderDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_OrderHeaderDB  @SlsPerID varchar(10)
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_OrderHeaderDB.sql
-- Purpose : Upload order header 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		23-Feb-2007			Initial
-- TaiNT		12-Apr-2007			Modified(add VanSales)
-- =============================================================================


-- SQL Go Here

	Select	h.OrderCode, h.CustID, h.SlsPerID, h.OrderDate,
			h.TotalSKU, h.TotalCase, h.TotalUnit, h.BeforeDiscount, h.OrderDiscount,
			h.Discount_Amo, h.Discount_Qua, h.OrderType, 
			Case h.Status When -1 Then 0 Else h.Status End AS Status,
			h.CreatedTime, h.LUpdatedTime, h.CreatedTStamp,
			h.LUpdatedTStamp, h.bCompleted, h.CompletedTime,
			h.User1, h.User2, h.User3, h.User4
	From 	fptOrderHeader h
	Where	((h.Status = -1 And h.SlsPerID = @SlsPerID) 
				or (h.Status = 2 And h.User3 = @SlsPerID)
				or (h.Status = 0 And h.OrderType = 0 And h.SlsPerID = @SlsPerID)) -- VanSales
				And (h.TotalCase > 0 Or h.TotalUnit > 0)
	Order By h.OrderCode
GO

--p_fpt_PDAVNM_PaymentDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_PaymentDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_PaymentDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_PaymentDB @SlsPerID varchar(10)    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_PaymentDB.sql
-- Purpose : Get information payment of customer 
--	     	 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		02-Mar-2007			Initial
-- TaiNT		02-Apr-2007			Modified(add field CashPay)
-- TaiNT		12-Apr-2007			Modified(payment trong ngay)
-- =============================================================================

	/*    
This function return the payment information of the order     
which have balance > 0.    
The recordset are sort by Customer code, OrderCode, PayDate    
The fields return are:    
    
- CustomerCode     
- OrderCode     
- PayCode     
- PayDate     
- Amount     
    
Reference report: CTTT.rpt    
Reference view: user_vr_CTTT    
    
*/    
Select CustID, SoHD AS OrderCode,SoCT AS PayCode, NgayHD AS PayDate, 
		SoTien AS Amount, Type, Status, CreatedTime, LUpdatedTime, CreatedTStamp,
		LUpdatedTStamp, SlsPerID,DeliverID,CashPay,User1 = 0, User2 = 0, User3 = ' ', User4 =' '
From
(    
	Select Isnull(AR1.CustID,'') CustID,     
	   Isnull(AR2.RefNBr,'') SoHD,    
	   Isnull(AR1.RefNbr,'') SoCT,    
	   Isnull(AR2.DocDate,Getdate()) NgayHD ,    
	   Isnull(Ad.AdjAmt,0)  SoTien,    
	   0 AS Type,    
	   'I' as Status,  
	   '1900-01-01 +00:00'  AS CreatedTime,  
	   '1900-01-01 +00:00'  As LUpdatedTime,
	   0 As CreatedTStamp,
	   0 As LUpdatedTStamp,
	   AR1.SlsPerID, ISNULL(so.User5,AR1.SlsPerID) As DeliverID,
	   CashPay = 0
	From ARDoc AR1
		-- doi chieu cac cong no cua NVGH 
		Left Join xswSalesOrd so On (ar1.OrdNbr = so.ARRefNbr And so.User5 = @SlsPerID)     
		Inner join ARAdjust Ad On Ad.AdjgRefNbr=AR1.RefNbr     
			And Ad.CustID=AR1.CustID     
			And AR1.Doctype = AD.ADJGDoctype     
			And ad.S4Future12 not in ('RA', 'NS')    
			And ad.AdjdDocType <> 'NS'      
	       Inner Join ARDoc AR2 On AR2.DocType in ('DM','IN','CS')     
			And Ad.AdjdRefNbr=AR2.RefNbr     
			And Ad.CustID = AR2.CustID     
	Where AR2.DocBal > 0 And AR1.Rlsed=1 And AR1.DocDate<=GetDate()    
			And AR1.DocType in ('PA','CM')     
			And (AR1.SlsPerID = @SlsPerID or so.User5 = @SlsPerID) -- NVBH or NVGH
	Union All
	-- Payment da xac nhan trong ngay + payment chua xac nhan (ke ca ngay trc)
	Select custid, ordercode, paycode, paydate, amount,   
	   	CASE Status WHEN 'O' THEN Type ELSE 0 END, 
		Status, CreatedTime, LUpdatedTime, CreatedTStamp,LUpdatedTStamp,fp.SlsPerID,fp.DeliverID,
		fp.CashPay
	From fptPayment fp    
	Where Status = 'O' 
			-- chi lay nhung payment da xac nhan va chua release trong ngay
			Or (convert(varchar(10),PayDate,103) = convert(varchar(10),GetDate(),103)  
				 And (Status = 'N' or exists (select refnbr from ardoc where Rlsed = 0 and refnbr = fp.PayCode)))    
			And (fp.SlsPerID = @SlsPerID or fp.DeliverID = @SlsPerID) -- NVBH or NVGH

) As Tmp
Order by CustID,SoHD,NgayHD     
GO

--p_fpt_PDAVNM_ProductByNameDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_ProductByNameDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_ProductByNameDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_ProductByNameDB  @SlsPerID varchar(10)
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_ProductByNameDB.sql
-- Purpose : Show all products that sort by name in salesman 's stock
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		02-Mar-2007			Initial
-- TaiNT		12-Mar-2007			Modified(subtract product vansales h.Status In (0,3))
-- TaiNT		07-May-2007			Modified (shortname)
-- =============================================================================


-- SQL Go Here

	SET NOCOUNT ON
	
	Create Table #MonthOrders (
		CpnyID varchar(10) not null,
		CustID varchar(10) not null,
		SlsperID varchar(10) not null,
		OrderDate smalldatetime not null,
		OrderNbr varchar(10) not null,
		Status varchar(1) not null,
		OrderType varchar(2) not null,
		NumType int not null
		primary key clustered (CpnyId,OrderNbr)
	)
	
	Create nonclustered index #monthorders1 on #MonthOrders (CustID, SlsperID, OrderType, OrderDate DESC)
	
	Create Table #OrderDet (
		SlsperID varchar(10) not null,		
		OrderNbr varchar(10) not null,
		Status varchar(1) not null,
		InvtID varchar(30) not null,
		LineQty float
	)

	Create Index #orderdet1 on #OrderDet(OrderNbr,InvtID)
	
	Declare @StartDate As Datetime
	
	-- Set default day is the first day in month
	Select @StartDate = Convert(datetime,'01/' + Cast(MONTH(getdate()) as varchar) + '/' + Cast(Year(getdate()) as varchar),103)
	
	-- Get orders from the begin of current month, insert into temp tables
	Insert	Into	#MonthOrders
	Select	CpnyID, CustID, SlsPerID, OrderDate, OrderNbr, Status, OrderType,
			NumType = Case When OrderType In ('DP','CO','IN') Then 1 Else -1 End
	From	xswSalesOrd 
	Where	(OrderType In ('DP','GO') 
				or (OrderType In ('SO','IN','CO','CM') And User1 like 'P%')) -- don tu Palm import vao
				And OrderDate >= @StartDate
				And (SlsPerID = @SlsPerID Or User5 = @SlsPerID) -- NVBH or NVGH
	
	
	Insert	Into	#OrderDet
	Select	m.SlsPerID, m.OrderNbr, m.Status As Status, d.InvtID, 
			Case When d.UnitMultDiv = 'M' Then       
     				(d.LineQty*d.UnitRate) * m.NumType     
        		 When d.UnitMultDiv = 'D' then       
     				(d.LineQty/d.UnitRate) * m.NumType     
    			 ELSE      
     				(d.LineQty * m.NumType)
    		END As LineQty
	From	xswSlsOrdDet d
				Inner Join #MonthOrders m On d.SlsPerID = m.SlsPerID 
												And d.OrderNbr = m.OrderNbr
	Where 	d.InvtID <> '' 
-- 				And d.SlsPerID = @SlsPerID

	SET NOCOUNT OFF
	/******************* Return Results *********************/	

	SELECT 	Tmp1.InvtID As ProductCode,    
     		ISNULL(Case When (Len(INV.Descr)> 14 and Len(INV.User2) >0) Then INV.User2 Else INV.Descr End,'') 	as ProductName, 
     -- Check * for all products which are given promotion   
			CASE WHEN INV.InvtID In (
										Select	Distinct d.ProdID As InvtID
										From	xtfpt_PromProd d
													Inner Join user_vr_PDAVNM_CurrentDiscount crd 
														On d.ProgID = crd.DiscID
															And d.SeqID = crd.DiscSeq
										Union All
										Select	Distinct d.SubProdID As InvtID
										From	xtfpt_PromSubProd d
													Inner Join user_vr_PDAVNM_CurrentDiscount crd 
														On d.ProgID = crd.DiscID
															And d.SeqID = crd.DiscSeq
									 )
			THEN 1
			ELSE 0
			END As Promotion     

     -- --- End ---  
	From (
			Select Tmp.InvtID, Sum(Tmp.Qty) As Qty
			From (
					/*      
					     
					   + K1 : Ton kho NV trong Solomon      
					   - K2 : Cac don dat hang da giao nhung chua nhap vao SL (status = 3)   
					   - K3 : Cac don ban hang da giao nhung chua nhap vao SL (status = 0,3)    			   			        
					   			   			        
		            */      
		
				-- (+) K1 Ton Kho NV
				Select  InvtID, Sum(LineQty) As Qty
				From	#OrderDet
				Where	Status = 'C'
				Group By	InvtID 
				
				Union All 
			
				-- (-) K2: Cac don da giao nhung chua nhap vao SOL (status = 3)   
				Select  InvtID, -Sum(d.Cases*d.UnitPerCase + d.Units) As Qty
				From	fptOrderDetail d
							Inner Join fptOrderHeader h On d.OrderCode = h.OrderCode
				Where	h.Status = 3 And OrderType = 2 -- don dat hang
							And h.OrderDate >= @StartDate
							And (h.SlsPerID = @SlsPerID Or h.User3 = @SlsPerID) -- NVBH or NVGH
				Group By	d.InvtID 
				
				Union All 
			
				-- (-) K3: Cac don ban hang da giao nhung chua trang thai 'C' (status = 0,3)   
				Select  InvtID, -Sum(d.Cases*d.UnitPerCase + d.Units) As Qty
				From	fptOrderDetail d
							Inner Join fptOrderHeader h On d.OrderCode = h.OrderCode
							Left Join xswInvoiceHeader ih On h.OrderCode = ih.RefNbr
				Where	h.Status In (0,3) And OrderType = 0 -- don ban hang
							And ih.RefNbr Is Null
							And h.OrderDate >= @StartDate
							And (h.SlsPerID = @SlsPerID ) -- NVBH 
				Group By	d.InvtID 

				) Tmp
			Group By Tmp.InvtID 
			Having	 Sum(Tmp.Qty) > 0
	)Tmp1	
		Inner Join Inventory inv On inv.InvtID = Tmp1.InvtID
		Inner Join INUnit InU ON Tmp1.InvtID = InU.InvtID And InU.MultDiv = 'D'      
	Order By 	ProductName
GO

--p_fpt_PDAVNM_ProductDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_ProductDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_ProductDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_ProductDB  @SlsPerID varchar(10)
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_ProductDB.sql
-- Purpose : Show all products in salesman 's stock
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		02-Mar-2007			Initial
-- TaiNT		12-Mar-2007			Modified(subtract product vansales h.Status In (0,3))
-- TaiNT		07-May-2007			Modified (shortname)
-- =============================================================================


-- SQL Go Here

	SET NOCOUNT ON
	
	Create Table #MonthOrders (
		CpnyID varchar(10) not null,
		CustID varchar(10) not null,
		SlsperID varchar(10) not null,
		OrderDate smalldatetime not null,
		OrderNbr varchar(10) not null,
		Status varchar(1) not null,
		OrderType varchar(2) not null,
		NumType int not null
		primary key clustered (CpnyId,OrderNbr)
	)
	
	Create nonclustered index #monthorders1 on #MonthOrders (CustID, SlsperID, OrderType, OrderDate DESC)
	
	Create Table #OrderDet (
		SlsperID varchar(10) not null,		
		OrderNbr varchar(10) not null,
		Status varchar(1) not null,
		InvtID varchar(30) not null,
		LineQty float
	)

	Create Index #orderdet1 on #OrderDet(OrderNbr,InvtID)
	
	Declare @StartDate As Datetime
	
	-- Set default day is the first day in month
	Select @StartDate = Convert(datetime,'01/' + Cast(MONTH(getdate()) as varchar) + '/' + Cast(Year(getdate()) as varchar),103)
	
	-- Get orders on Palm from the begin of current month, insert into temp tables
	Insert	Into	#MonthOrders
	Select	CpnyID, CustID, SlsPerID, OrderDate, OrderNbr, Status, OrderType,
			NumType = Case When OrderType In ('DP','CO','IN') Then 1 Else -1 End
	From	xswSalesOrd 
	Where	(OrderType In ('DP','GO') 
				or (OrderType In ('SO','IN','CO','CM') And User1 like 'P%')) -- don tu Palm import vao
				And OrderDate >= @StartDate
				And (SlsPerID = @SlsPerID Or User5 = @SlsPerID) -- NVBH or NVGH

	Insert	Into	#OrderDet
	Select	m.SlsPerID, m.OrderNbr, m.Status As Status, d.InvtID, 
			Case When d.UnitMultDiv = 'M' Then       
     				(d.LineQty*d.UnitRate) * m.NumType     
        		 When d.UnitMultDiv = 'D' then       
     				(d.LineQty/d.UnitRate) * m.NumType     
    			 ELSE      
     				(d.LineQty * m.NumType)
    		END As LineQty
	From	xswSlsOrdDet d
				Inner Join #MonthOrders m On d.SlsPerID = m.SlsPerID 
												And d.OrderNbr = m.OrderNbr
	Where 	d.InvtID <> '' 
-- 				And d.SlsPerID = @SlsPerID

	SET NOCOUNT OFF
	/******************* Return Results *********************/	

	SELECT 	Tmp1.InvtID As ProductCode,    
     		ISNULL(Case When (Len(INV.Descr)> 14 and Len(INV.User2) >0) Then INV.User2 Else INV.Descr End,'') 	as ProductName, 
     		ISNULL(InU.CnvFact,0) As UnitPerCase,    
     		ISNULL(cast(Tmp1.Qty / InU.CnvFact As Int) ,0) As FirstCases,    
 			ISNULL(cast(Tmp1.Qty As Int) % cast(InU.CnvFact As Int) ,0) As FirstUnits,    
    	    0 AS SellCases,    
     		0 AS SellUnits,    
     		ISNULL(cast(Tmp1.Qty / InU.CnvFact As Int) ,0) As RemainCases,    
     		ISNULL(cast(Tmp1.Qty As Int) % cast(InU.CnvFact As Int) ,0) As RemainUnits,    
     		ISNULL(inv.StkBasePrc,0) As Price,     
     		ISNULL(inv.priceClassId,'') As ClassID , --TaiNT -- Need define again--      
        
     -- Check * for all products which are given promotion   
			CASE WHEN INV.InvtID In (
										Select	Distinct d.ProdID As InvtID
										From	xtfpt_PromProd d
													Inner Join user_vr_PDAVNM_CurrentDiscount crd 
														On d.ProgID = crd.DiscID
															And d.SeqID = crd.DiscSeq
										Union All
										Select	Distinct d.SubProdID As InvtID
										From	xtfpt_PromSubProd d
													Inner Join user_vr_PDAVNM_CurrentDiscount crd 
														On d.ProgID = crd.DiscID
															And d.SeqID = crd.DiscSeq
									 )
			THEN 1
			ELSE 0
			END As Promotion     

     -- --- End ---  
	From (
			Select Tmp.InvtID, Sum(Tmp.Qty) As Qty
			From (
					/*      
					     
					   + K1 : Ton kho NV trong Solomon      
					   - K2 : Cac don dat hang da giao nhung chua nhap vao SL (status = 3)   
					   - K3 : Cac don ban hang da giao nhung chua nhap vao SL (status = 0,3)    			   			        
		            */      
		
				-- (+) K1 Ton Kho NV
				Select  InvtID, Sum(LineQty) As Qty
				From	#OrderDet
				Where	Status = 'C'
				Group By	InvtID 
				
				Union All 
			
				-- (-) K2: Cac don dat hang da giao nhung chua nhap vao SOL (status = 3)   
				Select  InvtID, -Sum(d.Cases*d.UnitPerCase + d.Units) As Qty
				From	fptOrderDetail d
							Inner Join fptOrderHeader h On d.OrderCode = h.OrderCode
				Where	h.Status = 3 And OrderType = 2 -- don dat hang
							And h.OrderDate >= @StartDate
							And (h.SlsPerID = @SlsPerID Or h.User3 = @SlsPerID) -- NVBH or NVGH
				Group By	d.InvtID 
				
				Union All 
			
				-- (-) K3: Cac don ban hang da giao nhung chua trang thai 'C' (status = 0,3)   
				Select  InvtID, -Sum(d.Cases*d.UnitPerCase + d.Units) As Qty
				From	fptOrderDetail d
							Inner Join fptOrderHeader h On d.OrderCode = h.OrderCode
							Left Join xswInvoiceHeader ih On h.OrderCode = ih.RefNbr
				Where	h.Status In (0,3) And OrderType = 0 -- don ban hang
							And ih.RefNbr Is Null
							And h.OrderDate >= @StartDate
							And (h.SlsPerID = @SlsPerID ) -- NVBH 
				Group By	d.InvtID 
				
				) Tmp
			Group By Tmp.InvtID 
			Having	 Sum(Tmp.Qty) > 0
	)Tmp1	
		Inner Join Inventory inv On inv.InvtID = Tmp1.InvtID
		Inner Join INUnit InU ON Tmp1.InvtID = InU.InvtID And InU.MultDiv = 'D'      
	Order By 	Tmp1.InvtID
GO

--p_fpt_PDAVNM_RejectOrder.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_RejectOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_RejectOrder]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_RejectOrder  @SlsPerID varchar(10)
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_RejectOrder.sql
-- Purpose : Reject orders that lack of products --> orders return Palm
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		23-Feb-2007			Initial
-- TaiNT		02-Mar-2007			Modified ('TaiNT 02Mar07') K2,K3 only for 'NVBH' 
-- =============================================================================


-- SQL Go Here
	SET NOCOUNT ON
	
	Create Table #MonthOrders (
		CpnyID varchar(10) not null,
		CustID varchar(10) not null,
		SlsperID varchar(10) not null,
		OrderDate smalldatetime not null,
		OrderNbr varchar(10) not null,
		Status varchar(1) not null,
		OrderType varchar(2) not null,
		NumType int not null
		primary key clustered (CpnyId,OrderNbr)
	)
	
	Create nonclustered index #monthorders1 on #MonthOrders (CustID, SlsperID, OrderType, OrderDate DESC)
	
	Create Table #OrderDet (
		SlsperID varchar(10) not null,		
		OrderNbr varchar(10) not null,
		Status varchar(1) not null,
		InvtID varchar(30) not null,
		LineQty float
	)

	Create Index #orderdet1 on #OrderDet(OrderNbr,InvtID)
	
	Declare @StartDate As Datetime
	
	-- Set default day is the first day in month
	Select @StartDate = Convert(datetime,'01/' + Cast(MONTH(getdate()) as varchar) + '/' + Cast(Year(getdate()) as varchar),103)
	
	-- Get orders from the begin of current month, insert into temp tables
	Insert	Into	#MonthOrders
	Select	CpnyID, CustID, SlsPerID, OrderDate, OrderNbr, Status, OrderType,
			NumType = Case When OrderType In ('DP','CO') Then 1 Else -1 End
	From	xswSalesOrd 
	Where	OrderType In ('DP','GO','SO','CO')
				And OrderDate >= @StartDate
				And SlsPerID = @SlsPerID

	Insert	Into	#OrderDet
	Select	m.SlsPerID, m.OrderNbr, m.Status As Status, d.InvtID, 
			Case When d.UnitMultDiv = 'M' Then       
     				(d.LineQty*d.UnitRate) * m.NumType     
        		 When d.UnitMultDiv = 'D' then       
     				(d.LineQty/d.UnitRate) * m.NumType     
    			 ELSE      
     				(d.LineQty * m.NumType)
    		END As LineQty
	From	xswSlsOrdDet d
				Inner Join #MonthOrders m On d.SlsPerID = m.SlsPerID 
												And d.OrderNbr = m.OrderNbr
	Where 	d.InvtID <> '' 
				And d.SlsPerID = @SlsPerID

	SET NOCOUNT OFF
	/******************* Return Results *********************/	

		Update foh 
		Set foh.Status = -1                
		From fptOrderHeader foh                 
 			 Inner Join fptOrderDetail fod on fod.OrderCode = foh.OrderCode and foh.SlsPerID = @SlsPerID and foh.Status in (0,-1) and foh.OrderType <> 0                
   			 Inner Join                 
    		(                 
				Select InvtID, IsNull(Sum(Qty), 0) As QtyAvail
				From (
						/*      
						   + TonKhoChinh SOL  
						   + K1 : Ton kho NV trong Solomon      
						   - K2 : Cac don NP da giao nhung chua nhap vao SL (status = 3)   
						   - K3 : Cac don NP dang giao (status =2)     
						   			        
			            */      
					
				    Select	InvtID, (QtyOnHand - QtyShipNotInv - QtyAlloc) as Qty 
					From	Location 
					Where 	SiteID in ('KHOCHINH')                
				    Union All                 
				    Select fod.InvtID, - (fod.Cases * fod.UnitPerCase + fod.Units) as Qty 
					From fptOrderDetail fod
						Inner Join fptOrderHeader foh on fod.OrderCode = foh.OrderCode and foh.status = 0
				    Union All                 
				    Select fod.InvtID, - (fod.Cases * fod.UnitPerCase + fod.Units) as Qty 
					From fptOrderDetail fod 
						 	Inner Join fptOrderHeader foh on fod.OrderCode = foh.OrderCode and foh.status = -1 And foh.Slsperid = @SlsPerID                
				           
					Union All
		
					-- Cac don hang trang thai Open tren SOL
					-- cac hang tra ve ko dc tinh vao ton kho neu chua cap nhat hoa don
					Select inv.InvtID,                                  
		    			   ISNULL(cast(Sum((CASE WHEN so.OrderType in ('DP', 'IN') 
												 THEN -1 ELSE 1 END)*                        
											     (CASE WHEN d.UnitMultDiv = 'M' then                         
											      		(d.LineQty)*d.UnitRate                        
											           WHEN d.UnitMultDiv = 'D' then                         
											      		(d.LineQty)/d.UnitRate                        
											     	   ELSE                        
											      		(d.LineQty)                        
											     END))AS int), 0)  As Qty                    
		       		From xswSalesOrd so                        
		     			Inner join xswSlsOrdDet d on d.cpnyid = so.cpnyid and d.OrderNbr = so.OrderNbr                         
		     			Inner join Inventory INV on d.InvtID = INV.InvtID                        
		       		Where  So.OrderType in ('DP', 'IN')                         
		        			And (so.status IN ('N'))                        
		       				And so.OrderDate >=  @StartDate
						    And inv.InvtID <> ''	
		       		Group by INV.InvtID   
		                     
					Union All
		
					-- (+) K1 Ton Kho NV
					Select  InvtID, 
							Sum(LineQty) As Qty
					From	#OrderDet
					Where	Status = 'C'
					Group By	InvtID 
					
					Union All 
				
					-- (-) K2: Cac don da giao nhung chua nhap vao SOL (status = 3)   
					Select  InvtID, 
							-Sum(d.Cases*d.UnitPerCase + d.Units) As Qty
					From	fptOrderDetail d
								Inner Join fptOrderHeader h On d.OrderCode = h.OrderCode
					Where	h.Status = 3
								And h.OrderDate >= @StartDate
								And h.SlsPerID In	( Select SlsPerID 
													  From SalesPerson 
													  Where  SlsPerID = @SlsPerID 
															 And User5 = 'B' --NVBH 
													)
					Group By	d.InvtID 
				
					Union All 
				
					-- (-) K3: Cac don dang giao(status = 2)   
					Select  InvtID, 
							-Sum(d.Cases*d.UnitPerCase + d.Units) As Qty
					From	fptOrderDetail d
								Inner Join fptOrderHeader h On d.OrderCode = h.OrderCode
					Where	h.Status = 2
								And h.OrderDate >= @StartDate
								And h.SlsPerID In	( Select SlsPerID 
													  From SalesPerson 
													  Where  SlsPerID = @SlsPerID 
															 And User5 = 'B' --NVBH 
													)
					Group By	d.InvtID 
				) Tmp
				Group By Tmp.InvtID 
				Having Sum(Tmp.Qty) < 0 
			) Tmp1   On fod.InvtID = Tmp1.InvtID
GO

--p_fpt_PDAVNM_RouteDB.sql

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_RouteDB]') 
		and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_RouteDB]
GO

Create Proc p_fpt_PDAVNM_RouteDB @SlsPerID varchar(10)  
AS  
-- =============================================================================
-- Script  : p_fpt_PDAVNM_RouteDB.sql
-- Purpose : Create procedure p_fpt_PDAVNM_RouteDB 
--         		and upload RouteDB 
-- =============================================================================
-- User			          Ref     Date				Comments
-- =============================================================================
-- TaiNT		          1.0     29-Dec-2006		Created
-- =============================================================================

/*
	- define the list static route	
*/

	--Returned query
	Select  'THU_001' As RouteCode, 'Chu Nhat' As RouteName, 0 As NumOfVisited,
			0 As User1,0 As User2,'' As User3,'' As User4 
	Union All
	Select  'THU_002' As RouteCode, 'Thu Hai' As RouteName, 0 As NumOfVisited,
			0 As User1,0 As User2,'' As User3,'' As User4 
	Union All
	Select  'THU_003' As RouteCode, 'Thu Ba' As RouteName, 0 As NumOfVisited,
			0 As User1,0 As User2,'' As User3,'' As User4 
	Union All
	Select  'THU_004' As RouteCode, 'Thu Tu' As RouteName, 0 As NumOfVisited,
			0 As User1,0 As User2,'' As User3,'' As User4 
	Union All
	Select  'THU_005' As RouteCode, 'Thu Nam' As RouteName, 0 As NumOfVisited,
			0 As User1,0 As User2,'' As User3,'' As User4 
	Union All
	Select  'THU_006' As RouteCode, 'Thu Sau' As RouteName, 0 As NumOfVisited,
			0 As User1,0 As User2,'' As User3,'' As User4 
	Union All
	Select  'THU_007' As RouteCode, 'Thu Bay' As RouteName, 0 As NumOfVisited,
			0 As User1,0 As User2,'' As User3,'' As User4 
	

GO

--p_fpt_PDAVNM_SKUSuggestDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_SKUSuggestDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_SKUSuggestDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_SKUSuggestDB @SlsPerID varchar(10)    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_SKUSuggestDB.sql
-- Purpose : Upload SKUs in recent orders of customer
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		02-Jan-2007			Initial

-- =============================================================================
/*
This function return the history information of the order.
The recordset is sorted by CustomerCode, ProductCode
The fields return are:

- CustomerCode 
- ProductCode 
- HistoryQuantity
- FromStock -- mark products that transfer 'kiem hang ton' to SKUSuggest
- User1                
- User2
- User3
- User4

*/                
-- SQL Go Here

Select 	sku.CustID As CustomerCode, 
	   	sku.InvtID As ProductCode, 
	   	sku.Qty As HistoryQuantity,
		0 As FromStock,
		0 As User1,
		0 As User2,
		' ' As User3,
		' ' AS User4
From 	fptSKUSuggest sku
Where	sku.SlsPerID = @SlsPerID 
Order By sku.custid, sku.InvtID
GO

--p_fpt_PDAVNM_StrategicProductDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_StrategicProductDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_StrategicProductDB]
GO


CREATE  PROCEDURE p_fpt_PDAVNM_StrategicProductDB @SlsPerID varchar(10)    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_StrategicProductDB.sql
-- Purpose : Upload strategic product information in Strategic Program
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		08-Jan-2007			Initial
-- TaiNT		18-Apr-2007			Modified (fix bug @CurrentDate)
-- =============================================================================

/*    
The fields return are:    
    
StrategicCode
StrategicName
BreakBy
Target
Current
Remain
User1
User2
User3
User4

*/     

SET NOCOUNT ON 
               
	Declare @CurrentDate As Datetime

	-- Get current date
	-- Select @CurrentDate = getdate() 
	SELECT @CurrentDate = convert(smalldatetime, floor(convert(float, getdate())))

	Select h.ProgID As StrategicCode,
		   IDENTITY(int, 0,1) AS StrategicID
	Into   #StrategicProg
	From   xtfpt_ConcenProgH h
			Inner Join XTFPT_SalPerObj sls 
						On h.ProgID = sls.ProgID And sls.SalPerID = @SlsPerID
	Where  h.Active = 1 
			And @CurrentDate between h.StartDate And h.EndDate

SET NOCOUNT OFF 

	-- Get Results
	Select	s.StrategicCode, p.InvtID As ProductCode,
-- 			ISNULL(sp.Amount,0) As Cases,
-- 			ISNULL(sp.Units,0) As Units,
			ISNULL((cast(ISNULL(sp.Amount,0) as int) / cast(InU.CnvFact as int)),0) As Cases,
			ISNULL((cast(ISNULL(sp.Amount,0) as int) % cast(InU.CnvFact as int)),0) As Units,
			0 As User1,
			0 As User2,
			' ' As User3,
			' ' As User4,
			s.StrategicID
	From   #StrategicProg	s	
				Inner Join xtfpt_ProdMaintain p On s.StrategicCode = p.ProgID COLLATE database_default	
				Inner Join Inventory inv On inv.InvtID = p.InvtID 
				INNER JOIN INUnit InU ON inv.InvtID = InU.InvtID And InU.MultDiv = 'D'      
				Left Join xtfpt_SalesPlan sp On (sp.InvtID = p.InvtID And ISNULL(sp.User6,'') = @SlsPerID) --COLLATE database_default
	Where	@CurrentDate between sp.User7 And sp.User8
	Order by ProductCode
	



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_StrategicProgramDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_StrategicProgramDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_StrategicProgramDB]
GO



CREATE  PROCEDURE p_fpt_PDAVNM_StrategicProgramDB @SlsPerID varchar(10)    
AS    
-- =============================================================================
-- Script  : p_fpt_PDAVNM_StrategicProgramDB.sql
-- Purpose : Upload strategic program information 
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		08-Jan-2007			Initial
-- TaiNT		18-Apr-2007			Modified (fix bug @CurrentDate)
-- =============================================================================

/*    
The fields return are:    
    
StrategicCode
StrategicName
BreakBy
Target
Current
Remain
User1
User2
User3
User4

*/     

SET NOCOUNT ON 
               
	Declare @CurrentDate As Datetime

	-- Get current date
	-- Select @CurrentDate = getdate() 
	SELECT @CurrentDate = convert(smalldatetime, floor(convert(float, getdate())))

	Select h.ProgID As StrategicCode,
		   h.Descr As StrategicName,
		   h.IssueType As BreakBy,
		   h.User3 As Target,
		   0 As [Current],
		   h.User3 As Remain,
		   0 As User1,
		   0 As User2,
		   ' ' As User3,
		   ' ' As User4,
		   IDENTITY(int, 0,1) AS StrategicID
	Into   #StrategicProg
	From   xtfpt_ConcenProgH h
			Inner Join XTFPT_SalPerObj sls 
						On h.ProgID = sls.ProgID And sls.SalPerID = @SlsPerID
	Where  h.Active = 1 
			And @CurrentDate between h.StartDate And h.EndDate
			

SET NOCOUNT OFF 

	-- Results
	Select s.StrategicCode, s.StrategicName, s.BreakBy, s.Target,s.[Current], s.Remain,
			 s.StrategicID as User1, s.User2, s.User3, s.User4, s.StrategicID
	From   #StrategicProg s
	Order by s.StrategicCode
-- 		   	Inner Join XTFPT_SalPerObj sls 
-- 						On s.StrategicCode = sls.ProgID And sls.SalPerID = @SlsPerID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_SystemDB.sql

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_SystemDB]') 
		and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_SystemDB]
GO

Create Proc p_fpt_PDAVNM_SystemDB @SlsPerID varchar(10)  
AS  
-- =============================================================================
-- Script  : p_fpt_PDAVNM_SystemDB.sql
-- Purpose : Create procedure p_fpt_PDAVNM_SystemDB 
--         		and upload SystemDateDB
-- =============================================================================
-- User			          Ref     Date				Comments
-- =============================================================================
-- TaiNT		          1.0     29-Dec-2006		Created
-- =============================================================================

/*
	- Get the last time stamp of current date	
	- Return Fields: 
		+ Current_Date
		+ LastTime: Last update time on PDA
		+ LastStamp: Last Time stamp on PDA
*/
SET NOCOUNT ON
	Declare @Count AS Int
	Declare @Current_Date AS DateTime
	Declare @Current_Date_0h As DateTime
	Declare @Current_Date_24h As DateTime
	Declare @DefSlsRouteID As Varchar(10)
	
	Select @Current_date = getdate()

	Set @Current_Date_0h = 	convert(DateTime,
					convert(varchar, Month(@Current_date)) + '/' +
					convert(varchar, Day(@Current_date)) + '/' + 
					convert(varchar, Year(@Current_date)) + ' 00:00:00'
				)
	Set @Current_Date_24h =	convert(DateTime,
					convert(varchar, Month(@Current_date)) + '/' +
					convert(varchar, Day(@Current_date)) + '/' + 
					convert(varchar, Year(@Current_date)) + ' 23:59:59'
				)

	-- Set default salesroute follow day in week	
	-- Set @@DateFirst = 1 -- set default start day in week is Sunday
-- 	select @DefSlsRouteID= Case DATEPART(dw, @Current_date) 
-- 				When 1 Then 'THU_001' -- Sunday
-- 				When 2 Then 'THU_002' -- Monday
-- 				When 3 Then 'THU_003' -- Tuesday
-- 				When 4 Then 'THU_004' -- Wednesday
-- 				When 5 Then 'THU_005' -- Thursday
-- 				When 6 Then 'THU_006' -- Friday
-- 				When 7 Then 'THU_007' -- Saturday
-- 				End
	select @DefSlsRouteID= DATEPART(dw, @Current_date) - 1
	
	--Check if TimeStamp of current date is already existed
	Select @Count = Count(*) 
	From   fpt_PDAVNM_SystemDB 
	Where  LastSyncTime between @Current_Date_0h and @Current_Date_24h
 			And UserCode = @SlsPerID


	If(@Count = 0) -- the start of day, don't have any record in current day
	Begin
		Insert fpt_PDAVNM_SystemDB 
		Select  s.SlsPerID As UserCode, s.[Name] As CurrentUser, RTrim(s.User5) As CurrentRole,
				@Current_date As LastSyncTime, 0 As SyncTimeStamp,
				@DefSlsRouteID As DefSlsRouteID, 0 As StartCode,
			    0 As User1, 0 As User2, '' As User3, '' As User4 
		From	SalesPerson s
		Where	s.SlsPerID = @SlsPerID
	End
SET NOCOUNT OFF
	--Returned query
	Select  UserCode, CurrentUser, CurrentRole,
			LastSyncTime, SyncTimeStamp,
			DefSlsRouteID, StartCode,
		    User1, User2, User3, User4 
	From   fpt_PDAVNM_SystemDB 
	Where  UserCode = @SlsPerID
	       And LastSyncTime between @Current_Date_0h and @Current_Date_24h	
GO

--p_fpt_PDAVNM_ToolDisplayEvaluationDB.sql

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_ToolDisplayEvaluationDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_ToolDisplayEvaluationDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_ToolDisplayEvaluationDB @SlsPerID varchar(10)    
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_ToolDisplayEvaluationDB.sql
-- Purpose : Upload tool display information of salesperson
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		09-Jan-2007			Initial
-- TaiNT		18-Apr-2007			Modified (fix bug @CurrentDate)
-- TaiNT		20-Apr-2007			Modified (add CreatedDate field)
-- =============================================================================

/*    
The fields return are:    

CustomerCode
ProgramCode
Quantity
DisplayResult
  
*/

	
               
	Declare @CurrentDate As Datetime

	-- Get current date
	-- Select @CurrentDate = getdate() 
	SELECT @CurrentDate = convert(smalldatetime, floor(convert(float, getdate())))

	Select  @CurrentDate As EvaluateDate, t.CustID As CustomerCode, t.TypeCCTB As ProgramCode,
			t.Qty As Quantity, 0 As DisplayResult
	From	xtfpt_ManDis t
	Where	t.SlsPerID = @SlsPerID
			And @CurrentDate between t.StartDate And t.EndDate
	Order By t.CustID, t.TypeCCTB

	
	
	 
GO

--p_fpt_PDAVNM_TopOrderDB.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_TopOrderDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_TopOrderDB]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


CREATE  PROCEDURE p_fpt_PDAVNM_TopOrderDB
@SlsPerID varchar(10)    
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_TopOrderDB
-- Purpose : Upload history information of customer  
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		21-Mar-2007			Initial

-- =============================================================================

/*    
The fields return are:    

*/     
SELECT CustID, OrderNbr,  OrderDate , OrdAmt
FROM fptTopOrders
WHERE SlsPerID=@SlsPerID
ORDER BY CustID, OrderNbr
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO

--p_fpt_PDAVNM_TotalOrderDB.sql


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[p_fpt_PDAVNM_TotalOrderDB]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[p_fpt_PDAVNM_TotalOrderDB]
GO

CREATE  PROCEDURE p_fpt_PDAVNM_TotalOrderDB @SlsPerID varchar(10)    
AS    

-- =============================================================================
-- Script  : p_fpt_PDAVNM_TotalOrderDB.sql
-- Purpose : Upload total order information of salesperson
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		08-Jan-2007			Initial

-- =============================================================================

/*    
The fields return are:    
    
ProductCode
ProductName
Cases
Units
User1
User2
User3
User4

*/                    

SELECT  od.InvtID As ProductCode ,
		inv.Descr As ProductName ,
		Cast(Sum((od.Cases * od.UnitPerCase + od.Units)/od.UnitPerCase) As Int) As Cases,
		Cast(Sum((od.Cases * od.UnitPerCase + od.Units)% Cast(od.UnitPerCase As Int)) As Int) As Units,
		User1 = 0, -- temp
		User2 = 0, -- temp
		User3 = ' ', -- temp
		User4 = ' ' -- temp
FROM	fptOrderDetail od 
			Inner Join fptOrderHeader oh On oh.OrderCode = od.OrderCode
			Inner Join Inventory inv	On inv.InvtID = od.InvtID
WHERE	oh.Status In (0,-1) And oh.SlsPerID = @SlsPerID 
Group By	od.InvtID, od.UnitPerCase, inv.Descr
Order By 	od.InvtID


GO

--user_vr_PDAVNM_CurrentDiscount.sql

IF EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS
      WHERE TABLE_NAME = 'user_vr_PDAVNM_CurrentDiscount')
   DROP VIEW user_vr_PDAVNM_CurrentDiscount

GO

Create View user_vr_PDAVNM_CurrentDiscount As
-- =============================================================================
-- Script  : user_vr_PDAVNM_CurrentDiscount_Create.sql
-- Purpose : Create view user_vr_PDAVNM_CurrentDiscount
--         		
-- =============================================================================
-- User			    Date				Comments
-- =============================================================================
-- TaiNT		    09-Feb-2007			Created 
-- =============================================================================


	Select	s.ProgID As DiscID, s.SeqID As DiscSeq
	--Into	#CurrentDisc
	From 	xtfpt_PromProg d
		Inner Join xtfpt_PromSeq s On d.ProgID = s.ProgID 
	Where	s.Active = 1
		And (convert(varchar(10),s.FromDate,102) <= convert(varchar(10),getdate(),102)
		And convert(varchar(10),s.ToDate,102) >= convert(varchar(10),getdate(),102))
		And ( 
			(d.[Level] = 'L' and (EXISTS (SELECT ProgID FROM xtfpt_PromLine
											WHERE ProgID = d.ProgID Or ProgID01 = d.ProgID 
											  Or ProgID02 = d.ProgID Or ProgID03 = d.ProgID))
			)
			or
			(d.[Level] = 'D' and (EXISTS (SELECT ProgID FROM xtfpt_PromDoc
											WHERE ProgID = d.ProgID Or ProgID01 = d.ProgID 
											  Or ProgID02 = d.ProgID Or ProgID03 = d.ProgID))
			)
			or
			(d.[Level] = 'G' and (EXISTS (SELECT ProgID FROM xtfpt_PromGroup
											WHERE ProgID = d.ProgID Or ProgID01 = d.ProgID 
											  Or ProgID02 = d.ProgID Or ProgID03 = d.ProgID))
			)
		    )


GO

--xsw_pp05610.sql
ALTER  proc xsw_pp05610 @UserAddress varchar(21) as
declare 
  @DespatchNbr varchar(10),
  @DfltStatus varchar(1),
  @RefNbr varchar(10), 
  @rowcount smallint,
  @error smallint,
  @ProcId varchar(5),
  @MSG_PROCESSING smallint,
  @debug smallint,
  @InvoiceDate smalldatetime,
  @PerPost varchar(6),
  @Today smalldatetime

set nocount on
set deadlock_priority low

select 
  @procid = '610.D',
  @debug = CASE WHEN @UserAddress = 'DEBUG' THEN 1 ELSE 0 END,
  @MSG_PROCESSING = 30666

exec xsw_dboption 'select into/bulkcopy','on'

select * into #xswwrkprocess from xswwrkprocess where 1=0
if @@error!=0 return	

insert #xswwrkprocess (CpnyId, OrderClass, OrderNbr, UserAddress, ProcId, Result, UserId, HostId,
swfuture1, swfuture2, swfuture3, swfuture4, swfuture5, swfuture6, User1, User2, User3, User4, User5, User6, User7, User8)
select w.CpnyId, w.OrderClass, w.OrderNbr, w.UserAddress, w.ProcId, 0, w.UserId, w.HostId,
case 
  when d.DespatchNbr is null then 'N'
  when d.ARRefNbr != '' then 'N'
  when d.CuryVolDiscAmt >= power(convert(decimal(4,4),0.1),c.DecPl)/2 then 'N' 
  else w.SWFuture1 end, case when h.RefNbr is null then w.swfuture2 else 'A' end, w.swfuture3, w.swfuture4, w.swfuture5, w.swfuture6,/*User*/'','',0,0,'','',w.User7,w.User8
from xswwrkprocess w
left loop join xswDespatchOrd d on w.OrderClass = 'D' and d.CpnyId = w.CpnyID and d.DespatchNbr = w.OrderNbr
left loop join xswInvoiceHeader h on w.OrderClass = 'D' and h.RefNbr = d.ARRefNbr
left loop join Currncy c (nolock) on w.OrderClass = 'D' and c.CuryId = d.CuryId 
where useraddress = @useraddress and hostid = host_id() and procid = @procid and result = @MSG_PROCESSING OPTION (FORCE ORDER)
if @@error!=0 return

select top 1
  @Today = User7,
  @InvoiceDate = coalesce(nullif(User8, ''), nullif(User7, '')),
  @PerPost = nullif(SWFuture6,'')
from #xswWrkProcess
if @@error != 0 return(@@error)	

begin tran

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'BEGIN TRAN'
    PRINT 'Debug...Step 000: Check statuses'
  END

exec @error = xsw_ppCheckStatusForProc @UserAddress, @ProcId
if @@error!=0 or @error!=0 goto abort

if exists (select * from #xswwrkprocess where swfuture2 = 'A')
update w set
  w.result = case when #w.swfuture2 = 'A' then 30909 else 0 end, --Invoice exists
  w.swfuture2 = 'A'
from #xswwrkprocess #w
inner join xswwrkprocess w on w.useraddress = #w.useraddress and w.hostid = #w.hostid and w.cpnyid = #w.cpnyid and w.orderclass = #w.orderclass and w.ordernbr = #w.ordernbr
if @@error!=0 goto abort

/*
IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 009: Verify Ship-Complete'
  END

insert xswwrkprocess
(CpnyId, OrderClass, OrderNbr, UserAddress, ProcId, Result, UserId, HostId, swfuture1, swfuture2, swfuture3, swfuture4, swfuture5, 
 swfuture6, User1, User2, User3, User4, User5, User6, User7, User8)
select w.CpnyId, w.OrderClass, w.OrderNbr, w.UserAddress, w.ProcId, 30008, w.UserId, w.HostId, 
       w.SWFuture1, w.SWFuture2, w.SWFuture3, w.SWFuture4, w.SWFuture5, w.SWFuture6, w.User1, w.User2, 
       w.User3, w.User4, w.User5, w.User6, w.User7, w.User8
from #xswwrkprocess w
inner join (
  select distinct p.CpnyId, p.DespatchNbr
  from xswSalesOrd so 
  inner join xswSlsOrdDet s on s.CpnyId = so.CpnyId and s.OrderNbr = so.OrderNbr
  inner join xswSlsOrdDsp p on p.CpnyId = s.CpnyId and p.OrderNbr = s.OrderNbr
  where so.ShipComplete = 'C' and s.SlsType = 'GI' and s.DspStage != 'F') v on v.CpnyId = w.CpnyId and v.DespatchNbr = w.OrderNbr 
where w.OrderClass = 'D'
if @@error<>0 goto abort

if not exists (select wp.ordernbr from #xswwrkprocess w left join xswwrkprocess wp on w.cpnyid = wp.cpnyid 
               and w.orderclass = wp.orderclass and w.ordernbr = wp.ordernbr where wp.ordernbr is null)
   update w 
    set swfuture2 = 'A'
  from xswwrkprocess w join #xswwrkprocess #w on w.cpnyid = #w.cpnyid and w.orderclass = #w.orderclass and w.ordernbr = #w.ordernbr
  where w.orderclass = 'D'
if @@error<>0 goto abort

delete #w
from #xswwrkprocess #w 
inner join xswwrkprocess w on w.cpnyid = #w.cpnyid and w.orderclass = #w.orderclass and w.ordernbr = #w.ordernbr
if @@error<>0 goto abort
*/

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 010: UPDATE xswDespatchOrd, xswSalesOrd (CM,IN) statuses'
  END
  
update s set 
  s.status = f.ToStatus,
  s.crtdprog = w.ProcId,
  s.updprog = y.EditScrnNbr,
  s.upduser = w.UserId,
  s.upddatetime = getdate()
from #xswwrkprocess w 
inner join xswSalesOrd s on s.cpnyid = w.cpnyid and s.ordernbr = w.ordernbr
inner join xsworderflow f (nolock) on f.procid = w.procid and f.OrderType = s.OrderType and f.fromstatus = s.status
inner join xswOrderType y (nolock) on y.Ordertype = f.OrderType
where
w.orderclass = 'S'
if @@error<>0 goto abort

update s set 
  s.status = f.ToStatus,
  s.crtdprog = w.ProcId,
  s.updprog = y.EditScrnNbr,
  s.upduser = w.UserId,
  s.upddatetime = getdate()
from #xswwrkprocess w
inner join xswDespatchOrd s on s.cpnyid = w.cpnyid and s.despatchnbr = w.ordernbr 
inner join xsworderflow f (nolock) on f.procid = w.procid and f.OrderType = 'DO' and f.fromstatus = s.status
inner join xswOrderType y (nolock) on y.Ordertype = f.OrderType
where
w.orderclass = 'D' 
if @@error<>0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 020: UPDATE xswWrkProcess.ProcID'
  END

update w set 
  w.procid = #w.procid
from #xswwrkprocess #w
inner join xswwrkprocess w on w.useraddress = #w.useraddress and w.hostid = #w.hostid and w.cpnyid = #w.cpnyid and w.orderclass = #w.orderclass and w.ordernbr = #w.ordernbr
if @@error<>0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 101: LOCK OrderType'
  END

if exists(select * from #xswwrkprocess where orderclass = 'S')
update t set 
  @DespatchNbr = t.LastOrderNbr, 
  @DfltStatus = (select min(ToStatus) from xsworderflow where ordertype = t.ordertype and ProcId = @ProcId and flags & 0x10 = 0),
  @rowcount = 1,
  t.UpdProg = @procid,
  t.UpdDateTime = getdate()
from xswOrderType t (updlock)
where t.OrderType = 'DO'
if @@error!=0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 102: INSERT xswSlsOrdDsp for CM, IN'
  END

while @DespatchNbr is not null and @rowcount != 0 
  begin
  exec xsw_incstr @DespatchNbr, @DespatchNbr OUTPUT

  set rowcount 1

  insert xswSlsOrdDsp (CpnyId, OrderNbr, DespatchNbr, OrderType, DspType, ARBatNbr, ARRefNbr, ARDocDate, Terms, 
  VolDiscPct, VolDiscAmt, CuryVolDiscAmt, LineAmt, CuryLineAmt, FreightAmt, CuryFreightAmt, MiscAmt, CuryMiscAmt, TaxAmt, CuryTaxAmt, OrdQty, OrdAmt, CuryOrdAmt, 
  NoteId, CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime,
  SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8)
  select s.CpnyId, s.OrderNbr, @DespatchNbr, s.OrderType,'F', s.ARBatNbr, s.ARRefNbr, coalesce(nullif(s.ARDocDate,''),@InvoiceDate), s.Terms,
  s.VolDiscPct, s.VolDiscAmt, s.CuryVolDiscAmt, s.LineAmt, s.CuryLineAmt, s.FreightAmt, s.CuryFreightAmt, s.MiscAmt, s.CuryMiscAmt, s.TaxAmt, s.CuryTaxAmt, s.OrdQty, s.OrdAmt, s.CuryOrdAmt, 
  0, @ProcId,'',getdate(),@procid,'',getdate(),
  '','','','','','',/*User*/'','',0,0,'','','',''
  from #xswwrkprocess w
  inner join xswSalesOrd s on s.cpnyid = w.cpnyid and s.ordernbr = w.ordernbr
  left join xswSlsOrdDsp p on p.CpnyId = s.CpnyId and p.OrderNbr = s.OrderNbr
  where w.orderclass = 'S' and p.DespatchNbr IS NULL
  select @error = @@error, @rowcount = @@rowcount
  if @error != 0 goto abort 
    
  set rowcount 0
  end

if @DespatchNbr is not null
exec xsw_decstr @DespatchNbr, @DespatchNbr OUTPUT

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 103: INSERT xswDespatchOrd for CM, IN'
  END

if @DespatchNbr is not null
insert xswDespatchOrd(CpnyId, DespatchNbr, SOType, BOSeq, CustId, Status, SepInvoicing, Reserved3, ProjectId, CustOrderNbr, OrderDate, 
ExpiryDate, PromiseDate, ShipDate, ShipViaId, ShipPriority, ShipComplete, FOBId, CuryId, CuryRateType, CuryRate, CuryEffDate, CuryMultDiv, 
CreditMgrID, SlsPerId, CmmnPct, VolDiscPct, VolDiscAmt, CuryVolDiscAmt, LineDiscAmt, CuryLineDiscAmt, LineAmt, CuryLineAmt, FreightTermsID, 
OrderWeight, UnitsShipped, FreightCost, CuryFreightCost, FreightAllocAmt, CuryFreightAllocAmt, PremFreightAmt, CuryPremFreightAmt, 
FreightAmt, CuryFreightAmt, MiscAmt, CuryMiscAmt, TaxAmt, CuryTaxAmt, OrdQty, OrdAmt, CuryOrdAmt, PaymentID, PmtDate, PmtAmt, CuryPmtAmt, 
ManifestEntryNbr, PONbr, ARBatNbr, ARRefNbr, ARDocDate, INBatNbr, PerClosed, PerPost, Terms, NoteId, BillCRC, ShipCRC, OrdCRC, CrtdProg, 
CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime, SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, 
User3, User4, User5, User6, User7, User8)

select s.CpnyId, p.DespatchNbr, s.OrderType, s.BOSeq, s.CustId, @DfltStatus, '00', '', s.ProjectId, s.CustOrderNbr, s.OrderDate, '', '',
'', s.ShipViaId, s.ShipPriority, s.ShipComplete, s.FOBId, s.CuryId, s.CuryRateType, s.CuryRate, s.CuryEffDate, s.CuryMultDiv, s.CreditMgrId, s.SlsPerId, 
s.CmmnPct, s.VolDiscPct, s.VolDiscAmt, s.CuryVolDiscAmt, s.LineDiscAmt, s.CuryLineDiscAmt, s.LineAmt, s.CuryLineAmt, s.FreightTermsID, 
s.OrderWeight, s.UnitsShipped, s.FreightCost, s.CuryFreightCost, s.FreightAllocAmt, s.CuryFreightAllocAmt, s.PremFreightAmt, s.CuryPremFreightAmt, 
s.FreightAmt, s.CuryFreightAmt, s.MiscAmt, s.CuryMiscAmt, s.TaxAmt, s.CuryTaxAmt, s.OrdQty, s.OrdAmt, s.CuryOrdAmt, s.PaymentID, s.PmtDate, s.PmtAmt, 
s.CuryPmtAmt, s.ManifestEntryNbr, s.PONbr, s.ARBatNbr, s.ARRefNbr, s.ARDocDate, s.INBatNbr, '', s.PerPost, 
s.Terms, 0, s.OrdCRC, s.BillCRC, s.ShipCRC,
w.ProcID, w.UserID, getdate(), w.ProcID, w.UserID, getdate(),
'','','','',/*ToSiteID*/s.SWFuture5, '',/*User*/'','',0,0,'','','',''
from #xswwrkprocess w
inner join xswSalesOrd s on s.cpnyid = w.cpnyid and s.ordernbr = w.ordernbr 
inner join xswSlsOrdDsp p on p.CpnyId = w.CpnyId and p.OrderNbr = w.OrderNbr
where w.orderclass = 'S'
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 104: INSERT xswSlsOrdAddr for CM, IN'
  END

if @DespatchNbr is not null
insert xswSlsOrdAddr (CpnyId, OrderClass, OrderNbr, 
BillName, BillAttn, BillAddrLine1, BillAddrLine2, BillCity, BillStateID, BillCntryID, BillZip, BillPhone, BillFax, ShiptoID,
ShipName, ShipAttn, ShipAddrLine1, ShipAddrLine2, ShipCity, ShipStateID, ShipCntryID, ShipZip, ShipPhone, ShipFax, 
CheckNbr, CardNbr, CardName, CardExpDate, AuthCode, 
NoteId, CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime,
SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8) 
select a.CpnyId, 'D', p.DespatchNbr, 
a.BillName, a.BillAttn, a.BillAddrLine1, a.BillAddrLine2, a.BillCity, a.BillStateID, a.BillCntryID, a.BillZip, a.BillPhone, a.BillFax, a.ShiptoID,
a.ShipName, a.ShipAttn, a.ShipAddrLine1, a.ShipAddrLine2, a.ShipCity, a.ShipStateID, a.ShipCntryID, a.ShipZip, a.ShipPhone, a.ShipFax, 
a.CheckNbr, a.CardNbr, a.CardName, a.CardExpDate, a.AuthCode, 0, 
w.ProcID, w.UserID, getdate(), w.ProcID, w.UserID, getdate(),
'','','','','','',/*User*/'','',0,0,'','','',''
from #xswwrkprocess w
inner join xswSlsOrdAddr a on a.cpnyid = w.cpnyid and a.orderclass = w.orderclass and a.ordernbr = w.ordernbr 
inner join xswSlsOrdDsp p on p.CpnyId = w.CpnyId and p.OrderNbr = w.OrderNbr OPTION (FORCE ORDER)
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 105: INSERT xswDspOrdDet for CM, IN'
  END

if @DespatchNbr is not null
insert xswDspOrdDet (CpnyId, DespatchNbr, LineRef, SOType, Status, CustId, ProjectId, TaskId, SpecificCostID, AltOrderNbr, AltLineRef, 
SlsType, DspStage, InvtId, AlternateID, TaxCat, SiteId, WhseLoc, LineQty, AltQty, OpenQty, SlsUnit, UnitMultDiv, UnitRate, UnitWeight,
SlsPrice, CurySlsPrice, UnitCost, CuryUnitCost, LineAmt, CuryLineAmt, AltAmt, CuryAltAmt, L1TaxAmt, CuryL1TaxAmt, InclTaxAmt, CuryInclTaxAmt, CuryRate,
CuryMultDiv, CuryRateType, CuryId, CuryEffDate, SlsAcct, SlsSub, Descr, SlsPerId, CmmnPct, CmnblAmt, CuryCmnblAmt, DiscPct,
DiscCode, DiscAmt, CuryDiscAmt, NoteId, 
CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime,
SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8)

select d.CpnyId, p.DespatchNbr, d.LineRef, '', '', d.CustId, d.ProjectId, d.TaskId, d.SpecificCostID, d.OrderNbr, d.LineRef, 
d.SlsType, d.DspStage, d.InvtId, d.AlternateID, d.TaxCat, d.SiteId, d.WhseLoc, d.LineQty, d.AltQty, d.OpenQty, d.SlsUnit, d.UnitMultDiv, d.UnitRate, d.UnitWeight,
d.SlsPrice, d.CurySlsPrice, d.UnitCost, d.CuryUnitCost, d.LineAmt, d.CuryLineAmt, 0, 0, d.L1TaxAmt, d.CuryL1TaxAmt, d.InclTaxAmt, d.CuryInclTaxAmt, d.CuryRate,
d.CuryMultDiv, d.CuryRateType, d.CuryId, d.CuryEffDate, d.SlsAcct, d.SlsSub, d.Descr, d.SlsPerId, d.CmmnPct, d.CmnblAmt, d.CuryCmnblAmt, d.DiscPct,
d.DiscCode, d.DiscAmt, d.CuryDiscAmt, 0, 
w.ProcID, w.UserID, getdate(), w.ProcID, w.UserID, getdate(),
d.SWFuture1,'','','',d.SWFuture5,d.SWFuture6,/*User*/'',d.User2,0,0,'',d.User6,'',''
from #xswwrkprocess w
inner join xswSlsOrdDsp p on p.CpnyId = w.CpnyId and p.OrderNbr = w.OrderNbr
inner join xswSlsOrdDet d on d.cpnyid = w.cpnyid and d.ordernbr = w.ordernbr
where w.orderclass = 'S'
if @@error != 0 goto abort


IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 105a: INSERT xswDspOrdLot for CM, IN'
  END

if @DespatchNbr is not null
insert xswDspOrdLot (CpnyId, DespatchNbr, LineRef, WhseLoc, LotSerNbr, SpecificCostID, SOType, Status, InvtId, SiteId, MfctLotSerNbr, ExpDate,
Qty, AltQty, SlsUnit, UnitMultDiv, UnitRate, LotId, NoteId, 
CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser,  UpdDateTime,
SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8)
select l.CpnyId, p.DespatchNbr, l.LineRef, l.WhseLoc, l.LotSerNbr, l.SpecificCostID, l.OrderType, l.Status, l.InvtId, l.SiteId, l.MfctLotSerNbr, l.ExpDate,
l.Qty, 0, l.SlsUnit, l.UnitMultDiv, l.UnitRate, l.LotId, 0,
w.ProcID, w.UserID, getdate(), w.ProcID, w.UserID, getdate(),
'','','','','','',/*User*/'','',0,0,'','','',''
from #xswwrkprocess w
inner join xswSlsOrdDsp p on p.CpnyId = w.CpnyId and p.OrderNbr = w.OrderNbr
inner join xswSlsOrdLot l on l.cpnyid = w.cpnyid and l.ordernbr = w.ordernbr
where w.orderclass = 'S'
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 106: INSERT xswDspOrdTax for CM, IN'
  END

if @DespatchNbr is not null
insert xswDspOrdTax (CpnyId, DespatchNbr, LineRef, TaxId, TaxRate, TaxLevel, L2Exclude, TermsDisc, 
TxblAmt, CuryTxblAmt, TaxAmt, CuryTaxAmt, NoteId,  
CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime,
SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8)

select t.CpnyId, p.DespatchNbr, t.LineRef, t.TaxId, t.TaxRate, t.TaxLevel, t.L2Exclude, t.TermsDisc, 
t.TxblAmt, t.CuryTxblAmt, t.TaxAmt, t.CuryTaxAmt, 0,
w.ProcID, w.UserID, getdate(), w.ProcID, w.UserID, getdate(),
'','','','','','',/*User*/'','',0,0,'','','',''
from #xswwrkprocess w
inner join xswSlsOrdDsp p on p.CpnyId = w.CpnyId and p.OrderNbr = w.OrderNbr
inner join xswSlsOrdTax t on t.cpnyid = w.cpnyid and t.ordernbr = w.ordernbr
where w.orderclass = 'S'
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 107: INSERT #xswWrkProcess for CM, IN'
  END

if @DespatchNbr is not null
insert #xswwrkprocess (CpnyId, OrderClass, OrderNbr, UserAddress, ProcId, Result, UserId, HostId,
swfuture1, swfuture2, swfuture3, swfuture4, swfuture5, swfuture6, User1, User2, User3, User4, User5, User6, User7, User8)
select p.CpnyId, 'D', p.DespatchNbr, @UserAddress, @ProcId, 0, w.UserId, w.HostId,
w.SWFuture1, w.swfuture2, w.swfuture3, w.swfuture4, w.swfuture5, w.swfuture6,/*User*/'','',0,0,'','','',''
from 
#xswwrkprocess w
inner join xswSlsOrdDsp p on p.cpnyid = w.cpnyid and p.ordernbr = w.ordernbr
where w.orderclass = 'S'
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 110: INSERT xswInvoiceHeader for Non-AR Despatches'
  END

insert xswInvoiceHeader(CpnyId, HeaderClass, RefNbr, DocType, CustId, BatNbr, BatSeq, INBatNbr, PerEnt, PerPost, ProjectId, CustOrderNbr, SlsPerId, Terms, 
DocDate, DueDate,  DiscDate, 
CuryId, CuryRateType, CuryRate, CuryEffDate, CuryMultDiv, 
DocAmt, CuryDocAmt, 
LineAmt, CuryLineAmt, FreightAmt, CuryFreightAmt, MiscAmt, CuryMiscAmt, TaxAmt, CuryTaxAmt, Qty,
CmmnAmt, CuryCmmnAmt, ARAcct, ARSub, 
SiteId, 
WhseLoc, NoteId, 
CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime,
SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8)
select d.CpnyId, 'D', d.DespatchNbr, y.ARDocType, d.CustId, '', 0, '', xswSOSetup.PerNbr, coalesce(nullif(d.PerPost,''), @PerPost, xswSOSetup.PerNbr), d.ProjectId, d.CustOrderNbr, d.SlsPerId, d.Terms,
@InvoiceDate,'','',
d.CuryId, d.CuryRateType, d.CuryRate, d.CuryEffDate, d.CuryMultDiv,
0,0,0,0,0,0,0,0,0,
0,0,0,0,'','',
case 
  when y.INDocType != 'TR' then '' 
  else coalesce(nullif(d.SWFuture5,''), DfltCoSiteId) end, 
case 
  when y.INDocType != 'TR' then ''
  when d.SWFuture5 != '' then ''
  when DfltCoWhseLoc = '&C' then left(d.CustId,10)
  when DfltCoWhseLoc = '&T' then left(c.ClassId,10)
  else nullif(DfltCoWhseLoc,'') end, 0,
#w.ProcId, #w.UserId, getdate(), #w.ProcId, #w.UserId, getdate(),
'','',y.INDocType,'','','',/*User*/'','',0,0,'','','',''
from
#xswwrkprocess #w
inner join xswDespatchOrd d on d.CpnyId = #w.CpnyId and d.DespatchNbr = #w.OrderNbr
inner join Customer c (nolock) on c.CustID = d.CustID
inner join xswOrderType y (nolock) on y.OrderType = d.SOType
cross join xswSOSetup (nolock)
cross join INSetup (nolock)
where
#w.OrderClass = 'D' and y.ARDocType = 'NA'
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 110: INSERT xswInvoiceHeader, UPDATE xswSlsOrdDsp with RefNbr'
  END

create table #xswSOAcctDflts(
  CpnyID varchar(10),
  DespatchNbr varchar(10),
  ARDocType char(2),
  INDocType char(2),
  ARAcct varchar(10),
  ARSub varchar(24),
  VolumeDiscAcct varchar(10),
  VolumeDiscSub varchar(24))
if @@error != 0 goto abort

insert #xswSOAcctDflts
select v.CpnyID, v.DespatchNbr, max(v.ARDocType), max(v.INDocType), max(case when v.PmtRule = '1' then v.ChkAcct else v.ARAcct end), max(case when v.PmtRule = '1' then v.ChkSub else v.ARSub end),
max(v.VolumeDiscAcct), max(v.VolumeDiscSub)
from #xswwrkprocess w
inner join xsw_vpSOAcctDflts v on v.cpnyid = w.cpnyid and v.despatchnbr = w.ordernbr
inner join xswSlsOrdDsp p on p.cpnyid = w.cpnyid and p.despatchnbr = w.ordernbr 
where w.orderclass = 'D' and v.ARDocType != 'NA'
group by v.CpnyID, v.DespatchNbr
if @@error != 0 goto abort

select * into #xswInvoiceHeader from xswInvoiceHeader where 1=0
if @@error != 0 goto abort

/* swfuture1: N;No grouping, D;Default */
insert #xswInvoiceHeader(CpnyId, HeaderClass, RefNbr, DocType, CustId, BatNbr, BatSeq, INBatNbr, PerEnt, PerPost, ProjectId, CustOrderNbr, SlsPerId, Terms, 
DocDate, DueDate,  DiscDate, 
CuryId, CuryRateType, CuryRate, CuryEffDate, CuryMultDiv, 
DocAmt, CuryDocAmt, 
LineAmt, CuryLineAmt, FreightAmt, CuryFreightAmt, MiscAmt, CuryMiscAmt, TaxAmt, CuryTaxAmt, Qty,
CmmnAmt, CuryCmmnAmt, ARAcct, ARSub, SiteId, WhseLoc, NoteId, 
CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime,
SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8)

select d.CpnyId, 'I', d.ARRefNbr, v.ARDocType, d.CustId, '',0, '', '', d.PerPost,d.ProjectId, d.CustOrderNbr, d.SlsPerId, d.Terms,
coalesce(nullif(d.ARDocDate,''),@InvoiceDate), '', '',
d.CuryId, d.CuryRateType, d.CuryRate, d.CuryEffDate, d.CuryMultDiv,
d.OrdAmt, d.CuryOrdAmt, 
d.LineAmt, d.CuryLineAmt, d.FreightAmt, d.CuryFreightAmt, d.MiscAmt, d.CuryMiscAmt, d.TaxAmt, d.CuryTaxAmt, d.OrdQty,
0, 0, v.ARAcct, v.ARSub, '', '', 0,
w.ProcID, d.DespatchNbr, getdate(), w.ProcID, '',getdate(),
'','',v.INDocType,'','','',/*User*/'','',0,0,'','','',''
from
#xswwrkprocess w
inner join #xswSOAcctDflts v on v.cpnyid = w.cpnyid and v.despatchnbr = w.ordernbr
inner join xswdespatchord d on d.cpnyid = w.cpnyid and d.despatchnbr = w.ordernbr
where w.orderclass = 'D' and w.swfuture1 = 'N'  

  union all

select d.CpnyId, 'I', d.ARRefNbr, v.ARDocType, d.CustId, '',0,'','',d.PerPost,d.ProjectId, d.CustOrderNbr, d.SlsPerId, d.Terms,
coalesce(nullif(d.ARDocDate,''),@InvoiceDate), '', '',
d.CuryId, d.CuryRateType, d.CuryRate, max(d.CuryEffDate), d.CuryMultDiv,
0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, v.ARAcct, v.ARSub, '', '', d.BillCRC,
@ProcId, '', getdate(), @ProcId, '', getdate(),
'','',v.INDocType,'','','',/*User*/'','',0,0,'','','',''
from
#xswwrkprocess w
inner join #xswSOAcctDflts v on v.cpnyid = w.cpnyid and v.despatchnbr = w.ordernbr
inner join xswdespatchord d on d.cpnyid = w.cpnyid and d.despatchnbr = w.ordernbr
where 
  w.orderclass = 'D' and w.swfuture1 = 'D' 
group by
  d.CpnyId, v.ARDocType, v.INDocType, v.ARAcct, v.ARSub, d.CustId, d.PerPost, d.ARRefNbr, d.ARDocDate, d.ProjectId, d.CustOrderNbr, d.SlsPerId, d.Terms,
  d.CuryId, d.CuryRateType, d.CuryRate, d.CuryMultDiv, d.BillCRC 
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 100: Lock ARSetup (updlock), RefNbr (tablockx)'
  END

select top 1
  @RefNbr = s.LastRefNbr,
  @rowcount = 1
FROM ARSetup s (updlock)
left join RefNbr r on 1 = 1 --(tablockx)
if @@error != 0 goto abort

while @rowcount != 0
  begin
  IncLoop:
    EXEC xsw_incstr @RefNbr, @RefNbr OUTPUT

  if exists(select * from RefNbr (nolock) where RefNbr = @RefNbr) or 
     exists(select * from xswInvoiceHeader (nolock) where RefNbr = @RefNbr) goto IncLoop

  IF (@Debug = 1)
    BEGIN
    print @RefNbr
    END

  SET RowCount 1
  
  update #xswInvoiceHeader set RefNbr = @RefNbr where RefNbr = ''
  select @rowcount = @@rowcount, @error = @@error

  set rowcount 0

  if @error != 0 goto abort
  end

exec xsw_decstr @RefNbr, @RefNbr OUTPUT

update p set 
  p.ARRefNbr = i.RefNbr,
  p.ARDocDate = i.DocDate
from 
#xswwrkprocess w    
inner join xswDespatchOrd d on d.cpnyid = w.cpnyid and d.despatchnbr = w.ordernbr
inner join #xswSOAcctDflts v on v.cpnyid = w.cpnyid and v.despatchnbr = w.ordernbr
inner join #xswInvoiceHeader i on i.CpnyId = w.CpnyId and (
  w.swfuture1 = 'N' and i.CrtdUser = d.DespatchNbr or
  w.swfuture1 = 'D' and i.CrtdUser = '' and 
                        i.DocType = v.ARDocType and 
                        i.SWFuture3 = v.INDocType and
                        i.ARAcct = v.ARAcct and
                        i.ARSub = v.ARSub and 
                        i.CustId = d.CustId and 
                        i.PerPost = d.PerPost and 
                        (i.DocDate = d.ARDocDate or d.ARDocDate = '') and 

                        i.ProjectId = d.ProjectId and 
                        i.CustOrderNbr = d.CustOrderNbr and  
                        i.SlsPerId = d.SlsPerId and 
                        i.Terms = d.Terms and
                        i.CuryId = d.CuryId and 
                        i.CuryRateType = d.CuryRateType and 
                        i.CuryMultDiv = d.CuryMultDiv and 
                        i.CuryRate = d.CuryRate and
                        i.NoteId = d.BillCRC)
inner join xswSlsOrdDsp p on p.cpnyid = w.cpnyid and p.despatchnbr = w.ordernbr
where w.orderclass = 'D' and p.ARRefNbr = ''
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 120: UPDATE xswDespatchOrd ARRefNbr, ARDocDate'
  END

update d set 
  d.ARRefNbr = v.RefNbr,
  d.ARDocDate = v.ARDocDate
from 
#xswwrkprocess w
inner join xswDespatchOrd d on d.cpnyid = w.cpnyid and d.despatchnbr = w.ordernbr 
inner join (select CpnyId, DespatchNbr, RefNbr =  max(ARRefNbr), ARDocDate = max(ARDocDate) from xswSlsOrdDsp group by CpnyId, DespatchNbr) v on v.CpnyId = d.CpnyId and v.DespatchNbr = d.DespatchNbr
where w.orderclass = 'D'
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 130: DELETE Zero "FR" xswDspOrdDet, xswDspOrdTax'
  END

delete d from
#xswwrkprocess w 
inner join xswDspOrdDet d on d.CpnyId = w.CpnyId and d.DespatchNbr = w.OrderNbr 
inner join Currncy c (nolock) on c.CuryId = d.CuryId
where w.OrderClass = 'D' and d.SlsType = 'FR' and d.CuryLineAmt < power(convert(decimal(4,4),0.1),c.DecPl)/2
if @@error!=0 goto abort

delete t from
#xswwrkprocess w 
inner join xswDspOrdTax t on t.CpnyId = w.CpnyId and t.DespatchNbr = w.OrderNbr
where
w.OrderClass = 'D' and t.LineRef != 'ORDER' and not exists (select * from xswDspOrdDet d where d.CpnyId = t.CpnyId and d.DespatchNbr = t.DespatchNbr and d.LineRef = t.LineRef)
if @@error!=0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 131: INSERT Non-Zero "VD" xswDspOrdDet'
  END

insert xswDspOrdDet(CpnyId, DespatchNbr, LineRef, SOType, Status, CustId, ProjectId, TaskId, SpecificCostID, AltOrderNbr, AltLineRef, SlsType, DspStage, 
InvtId, AlternateID, TaxCat, SiteId, WhseLoc, LineQty, AltQty, OpenQty, SlsUnit, UnitMultDiv, UnitRate, UnitWeight, SlsPrice, CurySlsPrice, 
UnitCost, CuryUnitCost, LineAmt, CuryLineAmt, AltAmt, CuryAltAmt, L1TaxAmt, CuryL1TaxAmt, InclTaxAmt, CuryInclTaxAmt, CuryRate, CuryMultDiv, 
CuryRateType, CuryId, CuryEffDate, SlsAcct, SlsSub, 
Descr, SlsPerId, CmmnPct, CmnblAmt, CuryCmnblAmt, DiscPct, DiscCode, DiscAmt, 
CuryDiscAmt, NoteId, 
CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime, 
SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8)
select d.CpnyId, d.DespatchNbr, 'DISCT', '', '', d.CustId, d.ProjectId, '', '', p.OrderNbr, '', 'VD', 'N', 
'', '', '', '', '', 0, 0, 0, '', '', 0, 0, 0, 0, 
0, 0, d.VolDiscAmt, d.CuryVolDiscAmt, 0, 0, 0, 0, 0, 0, d.CuryRate, d.CuryMultDiv, 
d.CuryRateType, d.CuryId, d.CuryEffDate, v.VolumeDiscAcct, v.VolumeDiscSub, 
'Volume Discount', d.SlsPerId, d.CmmnPct, 0, 0, 0, '', 0, 
0, 0, 
w.ProcId, w.UserId, getdate(), w.ProcId, w.UserId, getdate(), 
'', '', '', '', '', '', '', '', 0, 0, '', '', '', ''
from
#xswwrkprocess w
inner join xswDespatchOrd d on d.CpnyId = w.CpnyId and d.DespatchNbr = w.OrderNbr 
inner join xswSlsOrdDsp p on p.CpnyId = w.CpnyId and p.DespatchNbr = w.OrderNbr
inner join #xswSOAcctDflts v on v.cpnyid = w.cpnyid and v.despatchnbr = w.OrderNbr
inner join Currncy c (nolock) on c.CuryId = d.CuryId
where w.OrderClass = 'D' and d.CuryVolDiscAmt >= power(convert(decimal(4,4),0.1),c.DecPl)/2
if @@error!=0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 132a: UPDATE SWFuture1 to "1" for default grouped orders'
  END

update w set
  w.swfuture1 = '1'
from #xswwrkprocess w 
inner join (
  select p.CpnyId, p.ARRefNbr, DespatchNbr = max(p.DespatchNbr), DspCount=count(distinct p.DespatchNbr) 
  from #xswwrkprocess w
  inner join xswSlsOrdDsp p on p.CpnyId = w.CpnyId and p.DespatchNbr = w.OrderNbr 
  where w.OrderClass = 'D' and p.ARRefNbr != ''
  group by p.CpnyId, p.ARRefNbr
  having count(distinct p.DespatchNbr) = 1) v on v.CpnyId = w.CpnyId and v.DespatchNbr = w.OrderNbr
where
w.OrderClass = 'D' and w.SWFuture1 = 'D'
if @@error!=0 goto abort

select * into #xswInvoiceTax from xswInvoiceTax where 1=0
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 132b: INSERT xswInvoiceTax for 1:1 Despatch-Invoice'
  END

insert #xswInvoiceTax (CpnyId, HeaderClass, RefNbr, TaxId, TaxRate, TaxCalcType, TaxLevel, L2Exclude, 
TermsDisc, TxblAmt, CuryTxblAmt, TaxAmt, CuryTaxAmt, NoteId, 
CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime,
SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8)
select t.CpnyId, 'I', max(w.ARRefNbr), t.TaxId, max(t.TaxRate), max(x.TaxCalcType), max(t.TaxLevel), max(t.L2Exclude), 
max(t.TermsDisc), case when max(x.TaxCalcType) = 'I' then sum(t2.TxblAmt) else max(t.TxblAmt) end, case when max(x.TaxCalcType) = 'I' then sum(t2.CuryTxblAmt) else max(t.CuryTxblAmt) end, max(t.TaxAmt), max(t.CuryTaxAmt), 0, 
max(w.ProcId), max(w.UserId), getdate(), max(w.ProcId), max(w.UserId), getdate(),
max(t.SWFuture1), max(t.SWFuture2), max(t.SWFuture3), max(t.SWFuture4), max(t.SWFuture5), max(t.SWFuture6), max(t.User1), max(t.User2), max(t.User3), max(t.User4), max(t.User5), max(t.User6), max(t.User7), max(t.User8)
from 
(select w.CpnyId, w.OrderNbr, ARRefNbr = max(p.ARRefNbr), ProcId = max(w.ProcId), UserId = max(w.UserId) 
 from #xswwrkprocess w
 inner join xswSlsOrdDsp p on p.CpnyId = w.CpnyId and p.DespatchNbr = w.OrderNbr
 where w.OrderClass = 'D' and p.ARRefNbr != '' and w.SWFuture1 in ('N','1') 
 group by w.CpnyId, w.OrderNbr) w
inner join xswDspOrdTax t on t.CpnyId = w.CpnyId and t.DespatchNbr = w.OrderNbr and t.LineRef = 'ORDER' 
inner join xswDspOrdTax t2 on t2.CpnyId = t.CpnyId and t2.DespatchNbr = t.DespatchNbr and t2.LineRef <> t.LineRef and t2.TaxID = t.TaxID
inner join SalesTax x (nolock) on x.TaxId = t.TaxId 
group by t.CpnyID, t.DespatchNbr, t.TaxID option (force order)  
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 133: Calc invoice taxes: INSERT xswInvoiceTax'
  END

exec @error = xsw_pp05610TaxSummarize 
if @error != 0 or @@error != 0 goto abort

insert xswInvoiceTax (CpnyId, HeaderClass, RefNbr, TaxId, TaxRate, TaxCalcType, TaxLevel, L2Exclude, TermsDisc, TxblAmt, CuryTxblAmt, 
TaxAmt, CuryTaxAmt, NoteId, 
CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime, 
SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8)
select CpnyId, HeaderClass, RefNbr, TaxId, TaxRate, TaxCalcType, TaxLevel, L2Exclude, TermsDisc, TxblAmt, CuryTxblAmt, 
TaxAmt, CuryTaxAmt, NoteId, 
CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime, 
SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8
from #xswInvoiceTax
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 150: INSERT xswInvoiceHeader, totals, due and disc dates'
  END

insert xswInvoiceHeader(CpnyId, HeaderClass, RefNbr, DocType, CustId, BatNbr, BatSeq, INBatNbr, PerEnt, PerPost, ProjectId, CustOrderNbr, SlsPerId, Terms, 
DocDate, DueDate,  DiscDate, 
CuryId, CuryRateType, CuryRate, CuryEffDate, CuryMultDiv, 
DocAmt, 
CuryDocAmt, 
LineAmt, 
CuryLineAmt, 
FreightAmt, 
CuryFreightAmt, 
MiscAmt, 
CuryMiscAmt, 
TaxAmt, 
CuryTaxAmt, 
Qty,
CmmnAmt, CuryCmmnAmt, ARAcct, ARSub, SiteId, WhseLoc, NoteId, 
CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime,
SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8)

select d.CpnyId, d.HeaderClass, d.RefNbr, d.DocType, d.CustId, d.BatNbr, d.BatSeq, d.INBatNbr, 
coalesce(nullif(d.PerEnt,''), xswSOSetup.PerNbr), coalesce(@PerPost, xswSOSetup.PerNbr), 
d.ProjectId, d.CustOrderNbr, d.SlsPerId, d.Terms, d.DocDate, 
CASE WHEN m.DueType='D' THEN DATEADD(day,m.DueIntrv,d.DocDate) ELSE DATEADD(day, m.DueIntrv-DATEPART(day,DATEADD(month,1,d.DocDate)),DATEADD(month,1,d.DocDate)) END,  
CASE WHEN m.DiscType='D' THEN DATEADD(day,m.DiscIntrv,d.DocDate) ELSE DATEADD(day, m.DiscIntrv-DATEPART(day,DATEADD(month,1,d.DocDate)),DATEADD(month,1,d.DocDate)) END, 
CuryId, CuryRateType, CuryRate, CuryEffDate, CuryMultDiv, 
case when v.DspCount in ('N', '1') then d.DocAmt else v.LineAmt + v.MiscAmt + v.FreightAmt + COALESCE(x.TaxAmt,0) end, 
case when v.DspCount in ('N', '1') then d.CuryDocAmt else v.CuryLineAmt + v.CuryMiscAmt + v.CuryFreightAmt + COALESCE(x.CuryTaxAmt,0) end, 
case when v.DspCount in ('N', '1') then d.LineAmt else v.LineAmt end, 
case when v.DspCount in ('N', '1') then d.CuryLineAmt else v.CuryLineAmt end, 
case when v.DspCount in ('N', '1') then d.FreightAmt else v.FreightAmt end, 
case when v.DspCount in ('N', '1') then d.CuryFreightAmt else v.CuryFreightAmt end, 
case when v.DspCount in ('N', '1') then d.MiscAmt else v.MiscAmt end, 
case when v.DspCount in ('N', '1') then d.CuryMiscAmt else v.CuryMiscAmt end, 
case when v.DspCount in ('N', '1') then d.TaxAmt else coalesce(x.TaxAmt, 0) end, 
case when v.DspCount in ('N', '1') then d.CuryTaxAmt else coalesce(x.CuryTaxAmt, 0) end, 
case when v.DspCount in ('N', '1') then d.qty else v.qty end,
d.CmmnAmt, d.CuryCmmnAmt, d.ARAcct, d.ARSub, d.SiteId, d.WhseLoc, 0, 
d.CrtdProg, v.UserID, d.CrtdDateTime, d.UpdProg, v.UserID, d.UpdDateTime,
'P', d.SWFuture2, d.SWFuture3, d.SWFuture4, d.SWFuture5, d.SWFuture6, d.User1, d.User2, d.User3, d.User4, d.User5, d.User6, d.User7, d.User8
from 
(select p.CpnyId, p.ARRefNbr, 
  DspCount = max(w.SWFuture1), 
  LineAmt = sum(case t.SlsType when 'GI' then t.LineAmt else 0 end),
  CuryLineAmt = sum(case t.SlsType when 'GI' then t.CuryLineAmt else 0 end),
  FreightAmt = sum(case t.SlsType when 'FR' then t.LineAmt else 0 end),
  CuryFreightAmt = sum(case t.SlsType when 'FR' then t.CuryLineAmt else 0 end),
  MiscAmt = sum(case t.SlsType when 'MI' then t.LineAmt else 0 end),
  CuryMiscAmt = sum(case t.SlsType when 'MI' then t.CuryLineAmt else 0 end),
  Qty = sum(case t.SlsType when 'GI' then t.LineQty else 0 end),
  UserID = max(w.UserId)
 from  #xswwrkprocess w
 inner join xswSlsOrdDsp p on p.CpnyId = w.CpnyId and p.DespatchNbr = w.OrderNbr 
 inner join xswDspOrdDet t on t.CpnyId = p.CpnyId and t.DespatchNbr = p.DespatchNbr and t.AltOrderNbr = p.OrderNbr 
 where w.OrderClass = 'D'
 group by p.CpnyId, p.ARRefNbr) v 
inner join #xswInvoiceHeader d on d.CpnyId = v.CpnyId and d.RefNbr = v.ARRefNbr 
inner join terms m (nolock) on m.termsid = d.terms
left join (select CpnyId, RefNbr, TaxAmt = sum(TaxAmt), CuryTaxAmt = sum(CuryTaxAmt) 
           from #xswInvoiceTax where taxlevel != 0 group by cpnyid, refnbr) x on x.cpnyid = d.cpnyid and x.refnbr = d.refnbr
cross join ARSetup ar
cross join xswSOSetup (nolock)
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 151: UPDATE xswSalesOrd ARRefNbr, ARDocDate'
  END

update s set
  s.ARRefNbr = p.ARRefNbr,
  s.ARDocDate = p.ARDocDate,
  s.PerClosed = PerNbr
from
#xswwrkprocess #w
inner join xswSlsOrdDsp p on p.CpnyId = #w.cpnyID and p.DespatchNBr = #w.OrderNBr
inner join xswSalesOrd s on s.CpnyId = p.CpnyId  and s.OrderNbr = p.OrderNbr 
cross join xswSOSetup (nolock)
where
#w.OrderClass = 'D'
if @@error != 0 goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 160: INSERT RefNbr, UPDATE ARSetup.LastRefNbr'
  END
  
insert RefNbr (Crtd_DateTime, Crtd_Prog, Crtd_User, DocType, LUpd_DateTime, LUpd_Prog, LUpd_User, RefNbr, S4Future01,
               S4Future02, S4Future03, S4Future04, S4Future05, S4Future06, S4Future07, S4Future08, S4Future09,
               S4Future10, S4Future11, S4Future12, User1, User2, User3, User4, User5, User6, User7, User8)

select distinct 0, '', '', '', 0, '', '', p.ARRefNbr, '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', 0, 0, '', '', 0, 0
from #xswWrkProcess w 
inner join xswSlsOrdDsp p on p.CpnyId = w.CpnyId and p.DespatchNbr = w.OrderNbr
left join RefNbr r on r.RefNbr = p.ARRefNbr
where w.orderclass = 'D' and p.ARRefNbr != '' AND r.RefNbr IS NULL
if (@@ERROR != 0) GOTO abort

update ARSetup 
  set LastRefNbr = @RefNbr
if (@@ERROR != 0) goto abort

IF (@Debug = 1)
  BEGIN
    PRINT CONVERT(varchar(30), GETDATE(), 113)
    PRINT 'Debug...Step 161: UPDATE OrderType.LastOrderNbr'
  END

if @DespatchNbr is not null
update t
  set t.LastOrderNbr = @DespatchNbr  
from xswOrderType t
where t.OrderType = 'DO'
if @@error != 0 goto abort

update w set
  w.Result = 0
from #xswwrkprocess #w
inner join xswwrkprocess w on w.useraddress = #w.useraddress and w.hostid = #w.hostid and w.cpnyid = #w.cpnyid and w.ordernbr = #w.ordernbr and w.orderclass = #w.orderclass
if @@error != 0 goto abort

insert xswwrkprocess(CpnyId, OrderClass, OrderNbr, UserAddress, ProcId, Result, UserID, HostID, SWFuture1, SWFuture2, 
SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8)
select w.cpnyid, 'I', h.RefNbr, max(w.useraddress), max(w.ProcID), max(w.Result), max(w.UserID), max(w.HostID), max(w.SWFuture1), max(w.SWFuture2), 
max(w.SWFuture3), max(w.SWFuture4), max(w.SWFuture5), max(w.SWFuture6), max(w.User1), max(w.User2), max(w.User3), max(w.User4), max(w.User5), 
max(w.User6), max(w.User7), max(w.User8)
from #xswwrkprocess w
inner join xswdespatchord d on d.cpnyid = w.cpnyid and d.despatchnbr = w.ordernbr
inner join xswinvoiceheader h on h.CpnyId = w.cpnyid and h.HeaderClass = 'I' and h.RefNbr = d.arrefnbr
where w.orderclass = 'D'
group by w.cpnyid, h.RefNbr
if @@error != 0 goto abort

if (@debug = 1)
  begin

    select * from #xswinvoiceheader
    select * from #xswwrkprocess
    select * from xswwrkprocess

    goto abort
  end
   
    
  
		 /*  
		 - Modified by: TaiNT 27Mar07  
		 - Project: PDAVNM  
		 - Purpose: Update status of order (status = 2) and User3 (NVGH)  in fptOrderHeader 
		 - Modified by: TaiNT 16Apr07  -- Update InvoiceDate 		 
		 **************** Begin **********************  
		*/  
		 Declare @IsPrintStatus int  
		 
		 --Check PDAVNM project is installed or not  
		 if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptOrderHeader]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)   
		 Begin  
			Set @IsPrintStatus = 0  
			
		  	-- check N->C (which not update IN&AR) business   
		  	Select @IsPrintStatus = count(*)  
		  	From #xswwrkprocess w  
		   		Inner Join xswSalesOrd s on s.cpnyid = w.cpnyid and s.OrderNbr = w.OrderNbr  
			Where w.orderclass = 'S' And s.Status = 'C'  
		   			
		  	If @IsPrintStatus > 0  
		  	Begin  
				
		   		-- Create table to contain OrderCode and DeliveryID  
		   		Select s.ARRefNbr As OrderCode, s.User5 As DeliveryID
				Into  #fptOrderStatus
		   		From  #xswwrkprocess w  
		    		Inner Join xswSalesOrd s on s.cpnyid = w.cpnyid and s.OrderNbr = w.OrderNbr  
		       		Where w.orderclass = 'S' And s.Status = 'C'    
		     
		   		-- Update order in fptOrderHeader to Status = 2, User3 = <NVGH>, OrderDate = @InvoiceDate  
		   		Update oh   
		   		Set 	oh.Status = 2,
						oh.User3 = nbr.DeliveryID,
						oh.OrderDate = @InvoiceDate -- TaiNT Update InvoiceDate 16Apr07
		       	From  fptOrderHeader oh  
		    		Inner Join #fptOrderStatus nbr On (oh.OrderCode = nbr.OrderCode  
														And oh.Status = 1)
		  	End  
		       
		  	if @@error != 0 goto abort  
		End
	/*  
	 **************** End **********************  
	 - Modified by: TaiNT 26Mar07  
	 - Modified by: TaiNT 16Apr07 
	*/  

commit tran
return

abort:
rollback tran




GO


--job_DeleteOldWeeklyData.sql
USE Vietlink
GO
-- Script generated on 12/5/2007 9:39 AM
-- By: FSOFT-HCM\thanhnq
-- Server: (LOCAL)

BEGIN TRANSACTION            
  DECLARE @JobID BINARY(16)  
  DECLARE @ReturnCode INT    
  SELECT @ReturnCode = 0     
IF (SELECT COUNT(*) FROM msdb.dbo.syscategories WHERE name = N'REPL-History Cleanup') < 1 
  EXECUTE msdb.dbo.sp_add_category @name = N'REPL-History Cleanup'

  -- Delete the job with the same name (if it exists)
  SELECT @JobID = job_id     
  FROM   msdb.dbo.sysjobs    
  WHERE (name = N'job_DeleteOldWeeklyData')       
  IF (@JobID IS NOT NULL)    
  BEGIN  
  -- Check if the job is a multi-server job  
  IF (EXISTS (SELECT  * 
              FROM    msdb.dbo.sysjobservers 
              WHERE   (job_id = @JobID) AND (server_id <> 0))) 
  BEGIN 
    -- There is, so abort the script 
    RAISERROR (N'Unable to import job ''job_DeleteOldWeeklyData'' since there is already a multi-server job with this name.', 16, 1) 
    GOTO QuitWithRollback  
  END 
  ELSE 
    -- Delete the [local] job 
    EXECUTE msdb.dbo.sp_delete_job @job_name = N'job_DeleteOldWeeklyData' 
    SELECT @JobID = NULL
  END 

BEGIN 

  -- Add the job
  EXECUTE @ReturnCode = msdb.dbo.sp_add_job @job_id = @JobID OUTPUT , @job_name = N'job_DeleteOldWeeklyData', @owner_login_name = N'FSOFT-HCM\ThanhNQ', @description = N'Xoa du lieu tuan cu nhat vao dau moi tuan', @category_name = N'REPL-History Cleanup', @enabled = 1, @notify_level_email = 0, @notify_level_page = 0, @notify_level_netsend = 0, @notify_level_eventlog = 2, @delete_level= 0
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  -- Add the job steps
  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobstep @job_id = @JobID, @step_id = 1, @step_name = N'DeleteOldWeeklyData_HK', @command = N'DECLARE @CurWeek int
DECLARE @CurYear int
DECLARE @FromYearWeek int
DECLARE @Month varchar(2)
DECLARE @Day varchar(2)
DECLARE @CurYearMonthDay varchar(8)
DECLARE @HouseKeeping int

--Get current date -> YYYYmmdd
SET @Month = CAST(Month(Getdate()) AS VARCHAR(2))
If LEN(@Month) = 1
	SET @Month = ''0'' + @Month
SET @Day = CAST(Day(Getdate())  AS VARCHAR(2))
If LEN(@Day) = 1
	SET @Day = ''0'' + @Day


SET @CurYearMonthDay = CAST(Year(Getdate()) AS VARCHAR(4)) + @Month + @Day
--select @CurYearMonthDay
--Calculate FromWeek , ToWeek
SELECT @CurWeek = CAST(SUBSTRING(TIER_1,2,2)AS INT) , @CurYear = CAST(SUBSTRING(TIER_1,5,4) AS INT) from BKM_0_X where tier_0 = @CurYearMonthDay

--Calculate @FromYearWeek
SELECT  @HouseKeeping = NVALUE FROM dbo.SYSTEM_PARAMETERS WHERE DEFNAME = ''DEF_HOUSEKEEPING_PERIOD''
If @CurWeek < @HouseKeeping + 6
	Begin
		SET @FromYearWeek = (@CurYear-1)*100 + 52 + @CurWeek - (@HouseKeeping + 6)
	End
Else
	Begin
		SET @FromYearWeek = @CurYear*100 + @CurWeek - (@HouseKeeping + 6)
	End

--Delete oldest data
DELETE A From WEEKLY_DATA_HK A
INNER JOIN UPLOAD_WEEKLY_EVENTS B ON A.UPLOADID = B.UPLOADID
WHERE (B.YEAR*100 + B.WEEK)  = @FromYearWeek', @database_name = N'Vietlink', @server = N'', @database_user_name = N'', @subsystem = N'TSQL', @cmdexec_success_code = 0, @flags = 0, @retry_attempts = 0, @retry_interval = 1, @output_file_name = N'', @on_success_step_id = 0, @on_success_action = 1, @on_fail_step_id = 0, @on_fail_action = 2
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 
  EXECUTE @ReturnCode = msdb.dbo.sp_update_job @job_id = @JobID, @start_step_id = 1 

  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  -- Add the job schedules
  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id = @JobID, @name = N'DeleteOldWeeklyData', @enabled = 1, @freq_type = 8, @active_start_date = 20071201, @active_start_time = 120000, @freq_interval = 2, @freq_subday_type = 1, @freq_subday_interval = 0, @freq_relative_interval = 0, @freq_recurrence_factor = 1, @active_end_date = 99991231, @active_end_time = 235959
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  -- Add the Target Servers
  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @JobID, @server_name = N'(local)' 
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

END
COMMIT TRANSACTION          
GOTO   EndSave              
QuitWithRollback:
  IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION 
EndSave: 



GO

--sp_CheckSumWeekReport.sql
USE Vietlink
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_CheckSumWeekReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_CheckSumWeekReport]
GO



CREATE   PROCEDURE sp_CheckSumWeekReport 
@Region int, 
@Week int,  
@Year int  

AS  


declare @uploadId1 int  
declare @uploadId2 int  
declare @uploadId3 int  
declare @uploadId4 int  
  
DECLARE @intWeek1 AS INT  
DECLARE @intYear1 AS INT  
DECLARE @intWeek2 AS INT  
DECLARE @intYear2 AS INT  
DECLARE @intWeek3 AS INT  
DECLARE @intYear3 AS INT  
DECLARE @intWeek4 AS INT  
DECLARE @intYear4 AS INT  


SET NOCOUNT ON
 --chuoi week_year cua tuan hien tai  
 if (@Week >= 5 AND @Week<=52)  
  begin  
   SET @intWeek1 = @Week - 1  
   SET @intYear1 = @Year  
   SET @intWeek2 = @Week - 2  
   SET @intYear2 = @Year  
   SET @intWeek3 = @Week - 3  
   SET @intYear3 = @Year  
   SET @intWeek4 = @Week - 4  
   SET @intYear4 = @Year  
  end  
  
 else if(@Week=4)  
  begin  
   SET @intWeek1 = @Week - 1  
   SET @intYear1 = @Year  
   SET @intWeek2 = @Week - 2  
   SET @intYear2 = @Year  
   SET @intWeek3 = @Week - 3  
   SET @intYear3 = @Year  
   SET @intWeek4 = 52  
   SET @intYear4 = @Year - 1  
  end  
  
 else if(@Week=3)  
  begin  
   SET @intWeek1 = @Week - 1  
   SET @intYear1 = @Year  
   SET @intWeek2 = @Week - 2  
   SET @intYear2 = @Year  
   SET @intWeek3 = 52  
   SET @intYear3 = @Year - 1  
   SET @intWeek4 = 51  
   SET @intYear4 = @Year - 1  
  end  
  
 else if(@Week=2)  
  begin  
   SET @intWeek1 = @Week - 1  
   SET @intYear1 = @Year  
   SET @intWeek2 = 52  
   SET @intYear2 = @Year - 1  
   SET @intWeek3 = 51  
   SET @intYear3 = @Year - 1  
   SET @intWeek4 = 50  
   SET @intYear4 = @Year - 1  
  end  
  
 else if(@Week=1)  
  begin  
   SET @intWeek1 = 52  
   SET @intYear1 = @Year  
   SET @intWeek2 = 51  
   SET @intYear2 = @Year - 1  
   SET @intWeek3 = 50  
   SET @intYear3 = @Year - 1  
   SET @intWeek4 = 49  
   SET @intYear4 = @Year - 1  
  end  


  
 CREATE TABLE #Prev_Weekly_Data(  
  UPLOADID int,  
  CMCUST numeric(6,0) ,
  KG  decimal(15, 2) default NULL,  
  PRIMARY KEY(UPLOADID, CMCUST)  
 )   
  
 CREATE TABLE #Cur_Weekly_Data(  
  UPLOADID int, 
  CMCUST numeric(6,0) ,
  KG  decimal(15, 2) default NULL,  
  PRIMARY KEY(UPLOADID, CMCUST)  
 )   
  
 -- Create temporary table to calculate average  
 CREATE TABLE #TMP1 (  
  CMCUST numeric(6,0) PRIMARY KEY,  
  AVG_4_WEEK decimal(15, 2) default NULL,  
  KG_THIS_WEEK decimal(15, 2) default NULL ,  
  RATE decimal(15, 2) default NULL   
  )  
  
 --sp_SecondarySalesReport 0,41,2007
 --Insert product's data cho 4 tuan  

  INSERT INTO #Prev_Weekly_Data(UPLOADID,CMCUST, KG)  
   SELECT A.UPLOADID,B.CMCUST,  SUM(A.NETWEIGHT) AS KG 
   FROM WEEKLY_DATA_HK AS A INNER JOIN UPLOAD_WEEKLY_EVENTS   B ON A.UPLOADID = B.UPLOADID
   WHERE  [WEEK] IN (@intWeek1,@intWeek2,@intWeek3,@intWeek4)  AND [YEAR] IN (@intYear1,@intYear2,@intYear3,@intYear4)  --(@Year1,@Year2,@Year3,2007) 
   GROUP BY A.UPLOADID,B.CMCUST

 
  
 --Insert product's data cho  tuan hien tai  
 INSERT INTO #Cur_Weekly_Data(UPLOADID,CMCUST, KG)  
   SELECT A.UPLOADID,B.CMCUST,  SUM(A.NETWEIGHT) AS KG  
   FROM WEEKLY_DATA_HK AS A INNER JOIN UPLOAD_WEEKLY_EVENTS   B ON A.UPLOADID = B.UPLOADID
   WHERE  [WEEK] = @Week  AND [YEAR] = @Year
   GROUP BY A.UPLOADID,B.CMCUST

 INSERT INTO #TMP1( CMCUST, KG_THIS_WEEK,  AVG_4_WEEK, RATE)  
  SELECT A.CMCUST AS CMCUST  
   , ISNULL(A.KG,0) AS KG_THIS_WEEK  
   , AVG(B.KG) AS AVG_4_WEEK  
   , CASE   
    WHEN AVG(B.KG ) IS NULL THEN 0  
    WHEN (AVG(B.KG ) =0 AND A.KG=0) THEN 0  
    WHEN (AVG(B.KG ) =0 AND A.KG <> 0 ) THEN 1  
    WHEN (AVG(B.KG ) <> 0 AND A.KG = 0 ) THEN 1  
    WHEN (AVG(B.KG ) <> 0 AND A.KG <> 0 ) THEN ABS((AVG(B.KG ) - A.KG )/AVG(B.KG ))  
    ELSE 1  
    END AS RATE  
  FROM  #Cur_Weekly_Data  AS A  
    LEFT JOIN  #Prev_Weekly_Data  AS B  
   ON ( A.CMCUST = B.CMCUST)  
  GROUP BY A.CMCUST, A.KG  
  
  --RETURN RESULT
SELECT DCM.REAL_DIST_CODE,TEMP1.*,TEMP2.BANTTKG,TEMP2.AVERAGE,TEMP2.RATE FROM 
		(SELECT B.CMCUST
		, SUM(A.TONDT1) AS TONDT1
		, SUM(A.TONDT2)AS TONDT2
		, SUM(A.NHANTT) AS NHANTT
		, SUM(A.NHANTTO) AS NHANTTO
		, SUM(A.NHANTT3) AS NHANTT3
		, SUM(A.BANTT) AS  BANTT
		, SUM(A.BANTTO) AS BANTTO
		, SUM(A.BANTT3) AS BANTT3
		, SUM(A.TONCT1) AS TONCT1
		, SUM(A.TONCT2) AS   TONCT2
		, SUM(A.AMOUNT) AS AMOUNT  
		
		FROM  WEEKLY_DATA_HK A
		INNER JOIN UPLOAD_WEEKLY_EVENTS B ON A.UPLOADID = B.UPLOADID  
		WHERE B.Week = @Week AND B.Year = @Year
		GROUP BY B.CMCUST
		) TEMP1 
	
	INNER JOIN 

		(SELECT CMCUST
		, ISNULL(B.KG_THIS_WEEK, 0) AS BANTTKG  
		, ISNULL( B.AVG_4_WEEK, B.KG_THIS_WEEK) AS AVERAGE  
		, ISNULL(B.RATE, 1) AS RATE  
		
		FROM #TMP1 B
		) TEMP2

 	ON TEMP1.CMCUST = TEMP2.CMCUST
	
	INNER JOIN DIST_CODE_MAPPING DCM ON TEMP1.CMCUST = DCM.PSEUDO_DIST_CODE
	INNER JOIN PTRCM_DIST_STATUS P ON DCM.PSEUDO_DIST_CODE = P.CMCUST AND P.Active = 1
	WHERE (@Region = 0) OR (LEFT(DCM.PSEUDO_DIST_CODE,1) = @Region)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GO

--sp_TurnoverSubCatReport.sql
USE Vietlink
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_TurnoverSubCatReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_TurnoverSubCatReport]
GO

-- =============================================================================
-- Script  : sp_TurnoverSubCatReport.sql
-- Purpose : Get report Thong Ke Doanh So SUB-CAT data
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- Thanhnq		13-Dec-2007			Created
-- =============================================================================

CREATE  PROCEDURE sp_TurnoverSubCatReport  
@Region int,
@Week int,
@Year int

AS   

DECLARE @CreateTableSQL AS NVARCHAR(4000)
DECLARE @RowValue AS nvarchar(255)

--drop table #SubCat
SET NOCOUNT ON

CREATE TABLE #SubCat
(
RowNumber int IDENTITY(1, 1),
PrivateID NVARCHAR(50) NULL,
SUB_CAT_ID NVARCHAR(50)
)
INSERT INTO #SubCat(SUB_CAT_ID)
SELECT SUB_CAT_ID FROM 
	(SELECT DISTINCT CAT_ID,SUB_CAT_ID 
	FROM WEEKLY_DESC 
	) TMP
ORDER BY CAT_ID

UPDATE #SubCat
SET PrivateID = 'SUB_CAT' + CAST(RowNumber AS VARCHAR)  

SET @CreateTableSQL = 'if exists (select * from dbo.sysobjects where id = object_id(''' +'[dbo].[fpt_Result]''' + ') and OBJECTPROPERTY(id, ''' + 'IsUserTable''' + ') = 1)
drop table [dbo].[fpt_Result]'


SET @CreateTableSQL = @CreateTableSQL + '
CREATE TABLE fpt_Result( '
SET @CreateTableSQL = @CreateTableSQL + 'CMCUST VARCHAR(5), '

-- Declare cursor var
DECLARE Lop_Cursor CURSOR FOR

SELECT PrivateID 
FROM #SubCat 
ORDER BY RowNumber

-- Open declared cursor
OPEN Lop_Cursor

-- Fetch value of SUB_CAT_ID in the first row into @RowValue
FETCH NEXT FROM Lop_Cursor
INTO @RowValue

-- Interate all rows
WHILE @@FETCH_STATUS = 0
BEGIN
-- Generate column name from current LName value
SET @CreateTableSQL = @CreateTableSQL + @RowValue + ' NUMERIC(18,0),'
-- Next row
FETCH NEXT FROM Lop_Cursor
INTO @RowValue

END
-- Close and delocate
CLOSE Lop_cursor
DEALLOCATE Lop_cursor

-- End CREATE TABLE script
SET @CreateTableSQL = LEFT(@CreateTableSQL,LEN(@CreateTableSQL)-1)
SET @CreateTableSQL = @CreateTableSQL + ')'
--PRINT @CreateTableSQL
EXEC(@CreateTableSQL)

--OK
--Insert and select  result
DECLARE @InsertSQL AS NVARCHAR(4000)

DECLARE @SelectSQL AS NVARCHAR(4000)
SET @SelectSQL = 'SELECT CMCUST '

-- Declare cursor var
DECLARE Loop_Cursor CURSOR FOR

SELECT PrivateID 
FROM #SubCat 
ORDER BY RowNumber
-- Open declared cursor
OPEN Loop_Cursor

-- Fetch value of SUB_CAT_ID in the first row into @RowValue
FETCH NEXT FROM Loop_Cursor
INTO @RowValue

-- Interate all rows in TBLLop
WHILE @@FETCH_STATUS = 0
BEGIN

-- Generate column name from current LName value

--insert result
SET @InsertSQL = 'INSERT INTO fpt_Result(CMCUST,' + @RowValue + ')
SELECT DCM.REAL_DIST_CODE, SUM(A.AMOUNT)
	FROM WEEKLY_DATA_HK A  
	INNER JOIN UPLOAD_WEEKLY_EVENTS C ON A.UPLOADID = C.UPLOADID 
	INNER JOIN DIST_CODE_MAPPING DCM ON C.CMCUST = DCM.PSEUDO_DIST_CODE
	INNER JOIN PTRCM_DIST_STATUS P ON DCM.PSEUDO_DIST_CODE = P.CMCUST AND P.Active = 1
	LEFT JOIN WEEKLY_DESC B ON A.PRCODE=B.P_ID 
	--where a.uploadid = 38109
	WHERE SUB_CAT_ID IN (SELECT SUB_CAT_ID FROM #SubCat WHERE PrivateID = ''' + @RowValue + ''')'

IF(@Region <> 0) SET @InsertSQL = @InsertSQL +' AND (LEFT(RIGHT(REAL_DIST_CODE,4),1) = ' + CAST(@Region AS VARCHAR ) + ')	'
SET @InsertSQL = @InsertSQL +' AND C.Week = ' + CAST(@Week AS VARCHAR(2))
SET @InsertSQL = @InsertSQL +' AND C.Year = ' + CAST(@Year AS VARCHAR(4))
SET @InsertSQL = @InsertSQL +' GROUP BY  B.SUB_CAT_ID ,DCM.REAL_DIST_CODE'
--PRINT @InsertSQL
EXEC(@InsertSQL)
----------------------

--Build select query
SET @SelectSQL = @SelectSQL + ' ,ISNULL(SUM(' + @RowValue + '),0) AS ' + @RowValue


-----------
-- Next row
FETCH NEXT FROM Loop_Cursor
INTO @RowValue

END
-- Close and delocate
CLOSE Loop_Cursor
DEALLOCATE Loop_Cursor

SET @SelectSQL = @SelectSQL + '
FROM fpt_Result
group by CMCUST
order by CMCUST '
PRINT @SelectSQL
EXEC(@SelectSQL)


--select * from fpt_Result
--drop table fpt_Result
--drop table #SubCat

DROP TABLE fpt_Result


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GO

--tbl_Create_WEEKLY_DATA_HK.sql
USE Vietlink
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[WEEKLY_DATA_HK]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[WEEKLY_DATA_HK]
GO

CREATE TABLE [dbo].[WEEKLY_DATA_HK] (
	[UPLOADID] [int] NULL ,
	[DIVISION] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PRCODE] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DESC] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[COLOR] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SIZE] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MEASURE] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PACKAGE] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[UNIT] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[TONDT1] [numeric](15, 2) NULL ,
	[TONDT2] [numeric](15, 2) NULL ,
	[NHANTT] [numeric](15, 2) NULL ,
	[NHANTTO] [numeric](15, 2) NULL ,
	[TONCT1] [numeric](15, 2) NULL ,
	[TONCT2] [numeric](15, 2) NULL ,
	[BANTT] [numeric](15, 2) NULL ,
	[BANTTO] [numeric](15, 2) NULL ,
	[DATHANG1] [numeric](15, 2) NULL ,
	[DATHANG2] [numeric](15, 2) NULL ,
	[DIEUCHINH] [numeric](15, 2) NULL ,
	[THUCDAT1] [numeric](15, 2) NULL ,
	[THUCDAT2] [numeric](15, 2) NULL ,
	[NHANTT3] [numeric](15, 2) NULL ,
	[BANTT3] [numeric](15, 2) NULL ,
	[DONGIA] [numeric](15, 2) NULL ,
	[CASEQTY] [numeric](18, 2) NULL ,
	[NETWEIGHT] [numeric](18, 2) NULL ,
	[AMOUNT] [numeric](18, 0) NULL 
) ON [PRIMARY]


create clustered index WEEKLY_DATA_HK1 on WEEKLY_DATA_HK (UPLOADID)
create nonclustered index WEEKLY_DATA_HK2 on WEEKLY_DATA_HK (PRCODE)

GO

--Create data from Weekly_Data: last (houseKeeping + 5) week data
DECLARE @CurWeek int
DECLARE @CurYear int
DECLARE @FromYearWeek int
DECLARE @ToYearWeek int
DECLARE @CurYearWeek int

DECLARE @Month varchar(2)
DECLARE @Day varchar(2)
DECLARE @CurYearMonthDay varchar(8)
DECLARE @HouseKeeping int

--Get current date -> YYYYmmdd
SET @Month = CAST(Month(Getdate()) AS VARCHAR(2))
If LEN(@Month) = 1
	SET @Month = '0' + @Month
SET @Day = CAST(Day(Getdate())  AS VARCHAR(2))
If LEN(@Day) = 1
	SET @Day = '0' + @Day


SET @CurYearMonthDay = CAST(Year(Getdate()) AS VARCHAR(4)) + @Month + @Day
--select @CurYearMonthDay
--Calculate FromWeek , ToWeek
SELECT @CurWeek = CAST(SUBSTRING(TIER_1,2,2)AS INT) , @CurYear = CAST(SUBSTRING(TIER_1,5,4) AS INT) from BKM_0_X where tier_0 = @CurYearMonthDay

If @CurWeek = 1
	Begin
		SET @ToYearWeek = (@CurYear-1)*100 + 52
	End
Else
	Begin
		SET @ToYearWeek = @CurYear*100 + @CurWeek - 1
	End

SELECT  @HouseKeeping = NVALUE FROM dbo.SYSTEM_PARAMETERS WHERE DEFNAME = 'DEF_HOUSEKEEPING_PERIOD'
If @CurWeek <= @HouseKeeping + 5
	Begin
		SET @FromYearWeek = (@CurYear-1)*100 + 52 + @CurWeek - (@HouseKeeping + 5)
	End
Else
	Begin
		SET @FromYearWeek = @CurYear*100 + @CurWeek - (@HouseKeeping + 5)
	End


--select @CurWeek,@CurYear,@ToYearWeek,@FromYearWeek


--Insert data
--DELETE WEEKLY_DATA_HK

INSERT INTO WEEKLY_DATA_HK
SELECT B.YEAR,B.WEEK, A.* FROM WEEKLY_DATA A INNER JOIN UPLOAD_WEEKLY_EVENTS B ON A.UPLOADID =B.UPLOADID
WHERE (B.YEAR*100 + B.WEEK) BETWEEN @FromYearWeek AND @ToYearWeek

--End

GO

GO

--TRIG_DELETE_WEEKLY_DATA.sql
USE Vietlink
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TRIG_DELETE_WEEKLY_DATA]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TRIG_DELETE_WEEKLY_DATA]
GO


CREATE TRIGGER [TRIG_DELETE_WEEKLY_DATA] ON [dbo].[WEEKLY_DATA] 
FOR DELETE 
AS
BEGIN

	SET NOCOUNT ON

	DELETE A FROM  WEEKLY_DATA_HK A 
		INNER JOIN DELETED B ON A.UPLOADID = B.UPLOADID
	
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
GO

--TRIG_INSERT_WEEKLY_DATA.sql
USE Vietlink
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TRIG_INSERT_WEEKLY_DATA]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TRIG_INSERT_WEEKLY_DATA]
GO


CREATE TRIGGER [TRIG_INSERT_WEEKLY_DATA] ON [dbo].[WEEKLY_DATA] 
FOR INSERT
AS
BEGIN

	SET NOCOUNT ON

	INSERT INTO WEEKLY_DATA_HK
	SELECT *
	FROM INSERTED

END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
GO

--TRIG_UPDATE_WEEKLY_DATA.sql
USE Vietlink
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TRIG_UPDATE_WEEKLY_DATA]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TRIG_UPDATE_WEEKLY_DATA]
GO


CREATE TRIGGER [TRIG_UPDATE_WEEKLY_DATA] ON [dbo].[WEEKLY_DATA] 
FOR INSERT
AS
BEGIN

	SET NOCOUNT ON

	UPDATE WEEKLY_DATA_HK
	SET DIVISION = U.DIVISION,
		PRCODE = U.PRCODE,
		[DESC] = U.[DESC],
		COLOR = U.COLOR,
		[SIZE] = U.[SIZE],
		MEASURE = U.MEASURE,
		PRCODE = U.PRCODE,
		PACKAGE = U.PACKAGE,
		UNIT = U.UNIT,
		TONDT1 = U.TONDT1,
		TONDT2 = U.TONDT2,
		NHANTT = U.NHANTT,
		NHANTTO = U.NHANTTO,
		TONCT1 = U.TONCT1,
		TONCT2 = U.TONCT2,
		BANTT = U.BANTT,
		BANTTO = U.BANTTO,
		DATHANG1 = U.DATHANG1,
		DATHANG2 = U.DATHANG2,
		DIEUCHINH = U.DIEUCHINH,
		THUCDAT1 = U.THUCDAT1,
		THUCDAT2 = U.THUCDAT2,
		NHANTT3 = U.NHANTT3,
		BANTT3 = U.BANTT3,
		DONGIA = U.DONGIA,
		CASEQTY = U.CASEQTY,
		NETWEIGHT = U.NETWEIGHT,
		AMOUNT = U.AMOUNT

		
	FROM WEEKLY_DATA_HK W
  	INNER JOIN INSERTED U  ON W.UPLOADID = U.UPLOADID
	

END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
GO


--fptCatDisplay_Create.sql
-- =============================================================================
-- Script  :  fptCatDisplay_Create.sql
-- Purpose : Create table  fptCatDisplay
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		09-Jan-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptCatDisplay]') and OBJECTPROPERTY(id, N'IsTable') = 1)
drop table [dbo].[fptCatDisplay]
GO

CREATE TABLE [fptCatDisplay] (
[SlsPerID] [varchar] (15)  NOT NULL ,
[CustID] [varchar] (15)   NOT NULL ,
[Category] [varchar] (4)   NOT NULL ,
[CreateDate] [datetime] NOT NULL ,
[DisplayResult] int  NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[fptCatDisplay] WITH NOCHECK ADD 
	CONSTRAINT [PK_fptCatDisplay] PRIMARY KEY  CLUSTERED 
	(
		[SlsPerID],
		[CustID],
		[Category],
		[CreateDate]
	)  ON [PRIMARY] 
GO


GO

--fptCurrentSale_Create.sql
-- =============================================================================
-- Script  : fptCurrentSale_Create.sql
-- Purpose : Create table fptCurrentSale
--         		
-- =============================================================================
-- User			          Ref     Date				Comments
-- =============================================================================
-- TaiNT		          1.0     10-May-2007		Created
-- =============================================================================


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptCurrentSale]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[fptCurrentSale]
GO

CREATE TABLE [dbo].[fptCurrentSale] (
	SlsperID varchar(10) not null,
	TotalSKU int not null,
	TotalSale float not null
	primary key clustered (SlsPerID DESC)
) ON [PRIMARY]
GO

--fptCurrentStrategic_Create.sql
-- =============================================================================
-- Script  : fptCurrentStrategic_Create.sql
-- Purpose : Create table fptCurrentStrategic
--         		
-- =============================================================================
-- User			          Ref     Date				Comments
-- =============================================================================
-- TaiNT		          1.0     10-May-2007		Created
-- =============================================================================


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptCurrentStrategic]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[fptCurrentStrategic]
GO

CREATE TABLE [dbo].[fptCurrentStrategic] (
	[SlsPerId] [varchar] (10) NOT NULL ,
	[TotalStrategic] [int] NOT NULL ,
	Primary Key Clustered (SlsperID)
) ON [PRIMARY]
GO

--fptCustomerHistory_Create.sql
-- =============================================================================
-- Script  : fptCustomerHistory_Create.sql
-- Purpose : Create table fptCustomerHistory
--         		
-- =============================================================================
-- User			          Ref     Date				Comments
-- =============================================================================
-- TaiNT		          1.0     19-Mar-2007		Created
-- =============================================================================


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptCustomerHistory]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[fptCustomerHistory]
GO

CREATE TABLE [dbo].[fptCustomerHistory] (
	[SaleM1] [float] NOT NULL ,
	[SaleM2] [float] NOT NULL ,
	[SaleM3] [float] NOT NULL ,
	[AverageSale] [float] NOT NULL ,
	[LastestSale1] [float] NOT NULL ,
	[LastestSale2] [float] NOT NULL ,
	[CustID] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SlsPerID] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	Primary Key Clustered (SlsPerID, CustID)
) ON [PRIMARY]
GO

--fptCustomerStock_Create.sql
-- =============================================================================
-- Script  : fptCustomerStock_Create.sql
-- Purpose : Create table fptCustomerStock
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		08-Jan-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptCustomerStock]') and OBJECTPROPERTY(id, N'IsTable') = 1)
drop table [dbo].[fptCustomerStock]
GO


CREATE TABLE [fptCustomerStock] (
	[SlsPerID] [varchar] (80)   NOT NULL ,
	[CustID] [varchar] (50)   NOT NULL ,
	[InvtID] [varchar] (50)   NOT NULL ,
	[OrderDate] [datetime] NOT NULL ,
	[Cases] [int] NULL ,
	[Units] [int] NULL ,
	[Checked] [char] (1) NULL ,
	[User1] [int] NULL ,
	[User2] [int] NULL ,
	[User3] [varchar] (50)   NULL ,
	[User4] [varchar] (50)   NULL ,
	CONSTRAINT [PK_CustomerStock] PRIMARY KEY  CLUSTERED 
	(
		[SlsPerID],
		[CustID] ,
		[InvtID],
		[OrderDate]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO

GO

--fptCustomerVisit_Create.sql
-- =============================================================================
-- Script  : fptCustomerVisit_Create.sql
-- Purpose : Create table fptCustomerVisit
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		08-Jan-2007			Initial
-- ThanhNQ 		02-May-2007			Modified (add StartDateTime, EndDateTime fields)

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptCustomerVisit]') and OBJECTPROPERTY(id, N'IsTable') = 1)
drop table [dbo].[fptCustomerVisit]
GO

CREATE TABLE [fptCustomerVisit] (
	[CreateDate] datetime NULL,
	[SlsPerID] [varchar] (50)    NULL ,
	[CustomerCode] [varchar] (50)   NULL ,
	[StartTime] [varchar] (17)   NULL ,
	[EndTime] [varchar] (17)   NULL,
	[StartDateTime] [datetime] NULL ,
	[EndDateTime] [datetime] NULL  
) ON [PRIMARY]
GO

GO

--fptDisplayResult_Create.sql
-- =============================================================================
-- Script  :  fptDisplayResult_Create.sql
-- Purpose : Create table  fptCatDisplay
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		01-Mar-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptDisplayResult]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[fptDisplayResult]
GO

CREATE TABLE [dbo].[fptDisplayResult] (
	[CustID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ProgramCode] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[InvtID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Quantity] [int] NULL ,
	[CreateDate] [datetime] NULL ,
	[SlsPerID] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO


GO

--fptIncentivePayment_Create.sql
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptIncentivePayment]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[fptIncentivePayment]
GO

CREATE TABLE [dbo].[fptIncentivePayment] (
	[SlsPerID] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[CustID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ProgramCode] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Amount] [int] NULL ,
	[CreatedDate] [datetime] NULL ,
	[Status] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[User1] [int] NULL ,
	[User2] [int] NULL ,
	[User3] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[User4] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO


GO

--fptMonthReport_Create.sql
-- =============================================================================
-- Script  : fptMonthReport_Create.sql
-- Purpose : Create table fptMonthReport
--         		
-- =============================================================================
-- User			          Ref     Date				Comments
-- =============================================================================
-- TaiNT		          1.0     19-Mar-2007		Created
-- =============================================================================


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptMonthReport]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[fptMonthReport]
GO

CREATE TABLE [dbo].[fptMonthReport] (
	[HoaDon] [int] NOT NULL ,
	[SKU] [int] NOT NULL ,
	[DoanhSoThang] [float] NOT NULL ,
	[No_QH] [float] NOT NULL ,
	[No_DH] [float] NOT NULL ,
	[No_TH] [float] NOT NULL ,
	[SlsPerId] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TongThu] [float] NOT NULL,
	[CT_DSo] float not null,
	[CT_SKU] int not null,
 	[CT_DSoMHTT] float not null,
	[DS_MHTT] float not null
	Primary Key Clustered (SlsperID)
) ON [PRIMARY]
GO

--fptOrderDetail_Create.sql
-- =============================================================================
-- Script  : fptOrderDetail_Create.sql
-- Purpose : Create table fptOrderDetail
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		08-Jan-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptOrderDetail]') and OBJECTPROPERTY(id, N'IsTable') = 1)
drop table [dbo].[fptOrderDetail]
GO

CREATE TABLE [fptOrderDetail] (
	[OrderCode] [varchar] (50)  NOT NULL ,
	[InvtID] [varchar] (50)  NOT NULL ,
	[PromotionTitleID] [varchar] (50)  NOT NULL ,
	[FreeItem] [char] (1)  NOT NULL ,
	[BudgetID] [varchar] (50)  NULL ,
	[Cases] [int] NULL ,
	[Units] [int] NULL ,
	[UnitPerCase] [int] NULL ,
	[UnitPrice] [int] NULL ,
	[Discount] [int] NULL ,
	[AutoOrManual] [char] (1)  NULL ,
	[User1] [int] NULL ,
	[User2] [int] NULL ,
	[User3] [varchar] (50)  NULL ,
	[User4] [varchar] (50)  NULL ,
	CONSTRAINT [PK_OrderDetail] PRIMARY KEY  CLUSTERED 
	(
		[OrderCode],
		[InvtID],
		[PromotionTitleID],
		[FreeItem]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO





GO

--fptOrderDiscount_Create.sql
-- =============================================================================
-- Script  : fptOrderDiscount_Create.sql
-- Purpose : Create table fptOrderDiscount
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		08-Jan-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptOrderDiscount]') and OBJECTPROPERTY(id, N'IsTable') = 1)
drop table [dbo].[fptOrderDiscount]
GO

CREATE TABLE [fptOrderDiscount] (
	[OrderCode] [varchar] (50) NOT NULL ,
	[DiscID] [varchar] (50)   NOT NULL ,
	[DiscSeq] [varchar] (50)   NOT NULL ,
	[DisctblAmt] [int] NULL ,
	[DisctblQty] [int] NULL ,
	[DiscAmt] [int] NULL ,
	[FreeItemQty] [int] NULL ,
	[DiscType] [char] (10)   NULL ,
	[BreakBy] [char] (10)   NULL ,
	[DiscFor] [char] (10)   NULL ,
	[DItem] [varchar] (50)  NOT NULL ,
	[FreeItemID] [varchar] (50)   NOT NULL ,
	[User1] [int] NULL ,
	[User2] [int] NULL ,
	[User3] [varchar] (50)   NULL ,
	[User4] [varchar] (50)   NULL ,
	CONSTRAINT [PK_OrderDiscount] PRIMARY KEY  CLUSTERED 
	(
		[OrderCode],
		[DiscID],
		[DiscSeq],
		[DItem],
		[FreeItemID]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO
GO

--fptOrderHeader_Create.sql
-- =============================================================================
-- Script  : fptOrderHeader_Create.sql
-- Purpose : Create table fptOrderHeader
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		08-Jan-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptOrderHeader]') and OBJECTPROPERTY(id, N'IsTable') = 1)
drop table [dbo].[fptOrderHeader]
GO

CREATE TABLE [fptOrderHeader] (
	[OrderCode] [varchar] (50)   NOT NULL ,
	[CustID] [varchar] (50)   NULL ,
	[OrderDate] [datetime] NULL ,
	[TotalSKU] [int] NULL ,
	[TotalCase] [int] NULL ,
	[TotalUnit] [int] NULL ,
	[BeforeDiscount] [int] NULL ,
	[OrderDiscount] [int] NULL ,
	[Discount_Amo] [int] NULL ,
	[Discount_Qua] [int] NULL ,
	[OrderType] [char] (10)   NULL ,
	[Status] [char] (10)   NULL ,
	[CreatedTime] [varchar] (18)   NULL ,
	[LUpdatedTime] [varchar] (18)   NULL ,
	[CreatedTStamp] [int] NULL ,
	[LUpdatedTStamp] [int] NULL ,
	[bCompleted] [char] (10)   NULL ,
	[CompletedTime] [varchar] (18)   NULL ,
	[User1] [int] NULL ,
	[User2] [int] NULL ,
	[User3] [varchar] (50)   NULL ,
	[User4] [varchar] (50)   NULL ,
	[SlsPerID] [varchar] (80)   NULL ,
	CONSTRAINT [PK_OrderHeader] PRIMARY KEY  CLUSTERED 
	(
		[OrderCode]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO


GO

--fptParameters_Create.sql
-- =============================================================================
-- Script  : fptParameters_Create.sql
-- Purpose : Create table fptParameters
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		17-Mar-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptParameters]') and OBJECTPROPERTY(id, N'IsTable') = 1)
drop table [dbo].[fptParameters]
GO

CREATE TABLE [fptParameters] (
	[ID] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Descr] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Value] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO




GO

--fptPayment_Create.sql
-- =============================================================================
-- Script  : fptOrderHeader_Create.sql
-- Purpose : Create table fptOrderHeader
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- ThanhNQ		10-Mar-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptPayment]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[fptPayment]
GO

CREATE TABLE [dbo].[fptPayment] (
	[CustID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[OrderCode] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[PayDate] [datetime] NOT NULL ,
	[Amount] [int] NULL ,
	[Type] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Status] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CreatedTime] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LUpdatedTime] [varchar] (18) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CreatedTStamp] [int] NULL ,
	[LUpdatedTStamp] [int] NULL ,
	[CashPay] [int] NULL ,
	[User1] [int] NULL ,
	[User2] [int] NULL ,	
	[PayCode] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SlsPerID] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DeliverID] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, 
	[User3] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[User4] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
) ON [PRIMARY]
GO


GO

--fptPOSMDisplay_Create.sql
-- =============================================================================
-- Script  : fptPOSMDisplay_Create.sql
-- Purpose : Create table fptPOSMDisplay
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		09-Jan-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptPOSMDisplay]') and OBJECTPROPERTY(id, N'IsTable') = 1)
drop table [dbo].[fptPOSMDisplay]
GO

CREATE TABLE fptPOSMDisplay (
[SlsPerID] varchar (10)  NOT NULL ,
[CustID] varchar (15)  NOT NULL ,
[POSMCode] varchar (30)  NOT NULL ,
[Quantity] int NULL ,
[CreateDate] datetime NOT NULL ,
[Result] char(1)  NULL 
) 
GO

ALTER TABLE [dbo].[fptPOSMDisplay] WITH NOCHECK ADD 
	CONSTRAINT [PK_fptPOSMDisplay] PRIMARY KEY  CLUSTERED 
	(
		[SlsPerID],
		[CustID],
		[POSMCode],
		[CreateDate]
	)  ON [PRIMARY] 
GO


GO

--fptSalesPlan_Create.sql
-- =============================================================================
-- Script  : fptSalesPlan_Create.sql
-- Purpose : Create table fptSalesPlan
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		09-Mar-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptSalesPlan]') and OBJECTPROPERTY(id, N'IsTable') = 1)
drop table [dbo].[fptSalesPlan]
GO

CREATE  TABLE fptSalesPlan 
(
	[SlsPerID] [varchar] (50)   NULL ,
	[TargetSKU] [int]    NULL ,
	[TargetSale] [int] NULL ,
	[TargetStrategic] [int] NULL
)ON [PRIMARY]
GO



GO

--fptSKUSuggest_Create.sql
-- =============================================================================
-- Script  : fptSKUSuggest_Create.sql
-- Purpose : Create table fptSKUSuggest
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		02-Jan-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptSKUSuggest]') and OBJECTPROPERTY(id, N'IsTable') = 1)
drop table [dbo].[fptSKUSuggest]
GO

CREATE  TABLE fptSKUSuggest 
(
	[CreateDate] [datetime] NULL ,
	[SlsPerID] [varchar] (50)   NULL ,
	[CustID] [varchar] (50)   NULL ,
	[InvtID] [varchar] (50)   NULL ,
	[Qty] [int] NULL 
)ON [PRIMARY]
GO


GO

--fptTargetSale_Create.sql
-- =============================================================================
-- Script  : fptTargetSale_Create.sql
-- Purpose : Create table fptTargetSale
--         		
-- =============================================================================
-- User			          Ref     Date				Comments
-- =============================================================================
-- TaiNT		          1.0     10-May-2007		Created
-- =============================================================================


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptTargetSale]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[fptTargetSale]
GO

CREATE TABLE [dbo].[fptTargetSale] (
	SlsperID varchar(10) not null,
	TotalSKU int not null,
	TotalSale float not null
	primary key clustered (SlsPerID DESC)
) ON [PRIMARY]
GO

--fptTargetStrategic_Create.sql
-- =============================================================================
-- Script  : fptTargetStrategic_Create.sql
-- Purpose : Create table fptTargetStrategic
--         		
-- =============================================================================
-- User			          Ref     Date				Comments
-- =============================================================================
-- TaiNT		          1.0     10-May-2007		Created
-- =============================================================================


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptTargetStrategic]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[fptTargetStrategic]
GO

CREATE TABLE [dbo].[fptTargetStrategic] (
	[SlsPerId] [varchar] (10) NOT NULL ,
	[TotalStrategic] [int] NOT NULL ,
	Primary Key Clustered (SlsperID)
) ON [PRIMARY]
GO

--fptTopOrders_Create.sql
-- =============================================================================
-- Script  : fptTopOrders_Create.sql
-- Purpose : Create table fptTopOrders
--         		
-- =============================================================================
-- User			          Ref     Date				Comments
-- =============================================================================
-- TaiNT		          1.0     19-Mar-2007		Created
-- =============================================================================


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptTopOrders]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[fptTopOrders]
GO

CREATE TABLE [dbo].[fptTopOrders] (
	[CpnyID] varchar(10) not null,
	[OrderNbr]	varchar(10) not null,
	[OrderDate] smalldatetime not null,
	[OrdAmt]	float not null,
	[CustID] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SlsPerID] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	Primary Key Clustered (CpnyID,OrderNbr)
) ON [PRIMARY]
GO

--fptTopSKUs_Create.sql
-- =============================================================================
-- Script  : fptTopSKUs_Create.sql
-- Purpose : Create table fptTopSKUs
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		02-Jan-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fptTopSKUs]') and OBJECTPROPERTY(id, N'IsTable') = 1)
drop table [dbo].[fptTopSKUs]
GO

CREATE  TABLE fptTopSKUs 
(
	[SlsPerID] [varchar] (50)   NULL ,
	[InvtID] [varchar] (50)   NULL ,
	[SalesVol] [float] NULL 
)ON [PRIMARY]
GO



GO

--fpt_PDAVNM_SystemDB_Create.sql
-- =============================================================================
-- Script  : fpt_PDAVNM_SystemDB_Create.sql
-- Purpose : Create table fpt_PDAVNM_SystemDB
--         		
-- =============================================================================
-- User			Date				Comments
-- =============================================================================
-- TaiNT		09-Jan-2007			Initial

-- =============================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fpt_PDAVNM_SystemDB]') and OBJECTPROPERTY(id, N'IsTable') = 1)
drop table [dbo].[fpt_PDAVNM_SystemDB]
GO

CREATE TABLE [fpt_PDAVNM_SystemDB] (
	[UserCode] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CurrentUser] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CurrentRole] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[LastSyncTime] [datetime] NULL ,
	[SyncTimeStamp] [int] NULL ,
	[DefSlsRouteID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[StartCode] [int] NULL ,
	[User1] [int] NULL ,
	[User2] [int] NULL ,
	[User3] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[User4] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO



GO

# ---------------------------------------------------------------------- #
# Script generated with: DeZign for Databases v4.1.3                     #
# Target DBMS:           MySQL 4                                         #
# Project file:          dethinghe.dez                                   #
# Project name:                                                          #
# Author:                                                                #
# Script type:           Database drop script                            #
# Created on:            2010-01-30 15:07                                #
# ---------------------------------------------------------------------- #


# ---------------------------------------------------------------------- #
# Drop foreign key constraints                                           #
# ---------------------------------------------------------------------- #

ALTER TABLE JobList DROP FOREIGN KEY JobCategory_JobList;

ALTER TABLE Jobs DROP FOREIGN KEY JobList_Jobs;

ALTER TABLE Jobs DROP FOREIGN KEY Candidates_Jobs;

# ---------------------------------------------------------------------- #
# Drop table "Employers"                                                 #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE Employers DROP PRIMARY KEY;

# Drop table #

DROP TABLE Employers;

# ---------------------------------------------------------------------- #
# Drop table "Candidates"                                                #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE Candidates DROP PRIMARY KEY;

# Drop table #

DROP TABLE Candidates;

# ---------------------------------------------------------------------- #
# Drop table "JobList"                                                   #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE JobList DROP PRIMARY KEY;

# Drop table #

DROP TABLE JobList;

# ---------------------------------------------------------------------- #
# Drop table "JobCategory"                                               #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE JobCategory DROP PRIMARY KEY;

# Drop table #

DROP TABLE JobCategory;

# ---------------------------------------------------------------------- #
# Drop table "Jobs"                                                      #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE Jobs DROP PRIMARY KEY;

# Drop table #

DROP TABLE Jobs;

# ---------------------------------------------------------------------- #
# Script generated with: DeZign for Databases v4.1.3                     #
# Target DBMS:           MySQL 5                                         #
# Project file:          quocgia_skill.dez                               #
# Project name:                                                          #
# Author:                                                                #
# Script type:           Database drop script                            #
# Created on:            2008-07-08 12:41                                #
# ---------------------------------------------------------------------- #


# ---------------------------------------------------------------------- #
# Drop foreign key constraints                                           #
# ---------------------------------------------------------------------- #

ALTER TABLE taikhoan DROP FOREIGN KEY sinhvien_taikhoan;

ALTER TABLE dangky DROP FOREIGN KEY sinhvien_dangky;

ALTER TABLE dangky DROP FOREIGN KEY monhoc_dangky;

ALTER TABLE lichhoc DROP FOREIGN KEY monhoc_lichhoc;

# ---------------------------------------------------------------------- #
# Drop table "taikhoan"                                                  #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE taikhoan DROP PRIMARY KEY;

DROP INDEX TUC_taikhoan_1 ON taikhoan;

# Drop table #

DROP TABLE taikhoan;

# ---------------------------------------------------------------------- #
# Drop table "sinhvien"                                                  #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE sinhvien DROP PRIMARY KEY;

# Drop table #

DROP TABLE sinhvien;

# ---------------------------------------------------------------------- #
# Drop table "monhoc"                                                    #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE monhoc DROP PRIMARY KEY;

# Drop table #

DROP TABLE monhoc;

# ---------------------------------------------------------------------- #
# Drop table "dangky"                                                    #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE dangky DROP PRIMARY KEY;

# Drop table #

DROP TABLE dangky;

# ---------------------------------------------------------------------- #
# Drop table "lichhoc"                                                   #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE lichhoc DROP PRIMARY KEY;

# Drop table #

DROP TABLE lichhoc;

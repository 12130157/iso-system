# ---------------------------------------------------------------------- #
# Script generated with: DeZign for Databases v4.1.3                     #
# Target DBMS:           MySQL 5                                         #
# Project file:          quocgia_skill.dez                               #
# Project name:                                                          #
# Author:                                                                #
# Script type:           Database creation script                        #
# Created on:            2008-07-08 12:41                                #
# ---------------------------------------------------------------------- #


# ---------------------------------------------------------------------- #
# Tables                                                                 #
# ---------------------------------------------------------------------- #

# ---------------------------------------------------------------------- #
# Add table "taikhoan"                                                   #
# ---------------------------------------------------------------------- #

CREATE TABLE taikhoan (
    taikhoan CHAR(10) NOT NULL,
    matkhau CHAR(200) NOT NULL,
    masv CHAR(10),
    CONSTRAINT PK_taikhoan PRIMARY KEY (taikhoan),
    CONSTRAINT TUC_taikhoan_1 UNIQUE (masv)
);

# ---------------------------------------------------------------------- #
# Add table "sinhvien"                                                   #
# ---------------------------------------------------------------------- #

CREATE TABLE sinhvien (
    masv CHAR(10) NOT NULL,
    hoten CHAR(200) NOT NULL,
    ngaysinh DATE NOT NULL,
    phai BOOL NOT NULL,
    diachi CHAR(200) NOT NULL,
    CONSTRAINT PK_sinhvien PRIMARY KEY (masv)
);

# ---------------------------------------------------------------------- #
# Add table "monhoc"                                                     #
# ---------------------------------------------------------------------- #

CREATE TABLE monhoc (
    mamh CHAR(10) NOT NULL,
    tenmh CHAR(200) NOT NULL,
    sotc INTEGER(1) NOT NULL,
    hocphi DOUBLE NOT NULL,
    CONSTRAINT PK_monhoc PRIMARY KEY (mamh)
);

# ---------------------------------------------------------------------- #
# Add table "dangky"                                                     #
# ---------------------------------------------------------------------- #

CREATE TABLE dangky (
    mamh CHAR(10) NOT NULL,
    masv CHAR(10) NOT NULL,
    CONSTRAINT PK_dangky PRIMARY KEY (mamh, masv)
);

# ---------------------------------------------------------------------- #
# Add table "lichhoc"                                                    #
# ---------------------------------------------------------------------- #

CREATE TABLE lichhoc (
    mamh CHAR(10) NOT NULL,
    ngayhoc INTEGER NOT NULL,
    tiethoc INTEGER NOT NULL,
    CONSTRAINT PK_lichhoc PRIMARY KEY (mamh)
);

CREATE INDEX IDX_lichhoc_1 ON lichhoc (mamh);

# ---------------------------------------------------------------------- #
# Foreign key constraints                                                #
# ---------------------------------------------------------------------- #

ALTER TABLE taikhoan ADD CONSTRAINT sinhvien_taikhoan 
    FOREIGN KEY (masv) REFERENCES sinhvien (masv) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE dangky ADD CONSTRAINT sinhvien_dangky 
    FOREIGN KEY (masv) REFERENCES sinhvien (masv) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE dangky ADD CONSTRAINT monhoc_dangky 
    FOREIGN KEY (mamh) REFERENCES monhoc (mamh) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE lichhoc ADD CONSTRAINT monhoc_lichhoc 
    FOREIGN KEY (mamh) REFERENCES monhoc (mamh) ON DELETE CASCADE ON UPDATE CASCADE;

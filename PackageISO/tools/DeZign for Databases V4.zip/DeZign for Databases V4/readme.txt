----------------------------------------------------------------------------
                         DEZIGN FOR DATABASES NOTES
----------------------------------------------------------------------------

In this file:
1. What is DeZign for Databases?
2. Supported Databases
3. Limitations in the Trial Version
4. Changes Between DeZign for Databases V3 and V4 (What's New)

For more information, visit http://www.datanamic.com

1. What is DeZign for Databases?
----------------------------------------------------------------------------
DeZign for Databases is a visual database design and modeling tool that can
be used to design complex databases targeting multiple database platforms. 
DeZign for Databases uses an entity relationship diagram. It visually
supports the lay out of the entities and relationships and automatically
generates your database based on your data model. With the reverse
engineering capabilities you can derive a graphical data model from your
already existing database. You can update a database from a data model.
DeZign for Databases allows you to apply design changes made to your data
model to a database.

2. Supported Databases
----------------------------------------------------------------------------
Oracle, MySQL, InterBase, Firebird, MS Access, MS SQL Server, PostgreSQL,
NexusDB, FoxPro, dBase, Paradox, Clipper, DB2, Informix, Pervasive, Sybase,
DBISAM.

3. Limitations in the Trial Version
----------------------------------------------------------------------------
You can evaluate the application for 30 days. When importing/reverse
engineering an existing database, not all columns will be imported. Max 8
columns per table will be imported. Key columns will not be removed. Please
note that this limitation only applies to the trial version.

4. Changes Between DeZign for Databases V3 and V4 (What's New)
----------------------------------------------------------------------------

DeZign for Databases V4 comes in three editions:
- Standard: Diagramming and forward engineering/generating databases.
- Professional: Diagramming, forward engineering/generating databases and
  reverse engineering.
- Expert: Diagramming, forward engineering/generating databases, reverse
  engineering, modifying databases and compare data models.

1. General Changes
2. Target Database Related Changes

1. General Changes
------------------

Diagramming Environment
-----------------------
- New: IDEF1X modeling notation support. Each subdiagram can use its own
  notation: Relational/Crow's Feet or IDEF1X.
- Improved: Better mouse-wheel support. The diagram doesn't scroll anymore
  when the diagram does not have the focus. The steps taken are smaller
  which results in much smoother scrolling.
- New: Move selected objects using the keyboard arrows.
- New: Smooth direct scrolling when using the scrollbar.
- New: Group entities or other diagram objects by using the groupbox object.
- New: Pan around a diagram with the Hand tool (like in Adobe Reader).
- New: Add entities to a subdiagram by dragging them from the Object Browser
  and drop them on the diagram.

User Interface
--------------
- New: New editors for attributes, indexes, table constraints, domains,
  sequences, procedures and views. You can now edit the properties of these
  database objects directly a spreadsheet-like grid. At the bottom of such a
  grid, a property editor is shown which will display the property values
  for the selected object. You can move in the list by using the TAB-key,
  Enter-key and keyboard arrows.
- Improved: Larger New relationship dialog so that entities with long names
  will be readable also.

Modeling
--------
- New: Compare versions of a data model to find differences (Expert edition
  only).
- New: Reusable user-defined attributes. Attribute packages are reusable
  user-defined attributes that promote consistent attribute definitions.
  Reuse these attribute packages in your data model by applying them to
  entities.
- Improved: Key field's data type changes are now propagated throughout
  the model where relationships link to that key field.
- New: Column level collation support.
- New: Not null and default constraint names support.
- New: Position property for sequences/generators, procedures, domains and
  views. This position property is used to determine the creation order.
- Improved: More flexible trigger definition possible. Predefined event
  types aren't used anymore.
- New: You can now apply the default name templates to all objects or to
  unnamed objects by using the Apply name templates menu item under Tools.
- New: Define data type synonyms (fro example BOOL and BOOLEAN). Data types
  are better recognized when reverse engineering or switching target DBMS.
- New: High level data type definition id. By using definition id's you can
  control the way data types are converted when switching to a new target
  DBMS.
- New: Support for expressions, character sets, blob subtypes and segment
  sizes in data types.
- Improved: Improved data model validation. Check for unnamed constraints.
- Improved: Link attributes easier by dragging the attributes from the
  parent's list to the child's list in the Relationship dialog.
- New: Update indexes on keys by using the "Update indexes on keys" menu.
  Indexes on keys will be created and/or dropped automatically.

Reverse Engineering (Professional and Expert edition)
-----------------------------------------------------
See "Target Database Related Changes" for more information regarding the
reverse engineering feature for a specific target DBMS.
- New: Reverse engineering integrated. Use the File | Import menu item to
  import existing databases. You don't need the separate ImportER products
  anymore.
- New: Reverse engineer a database from a SQL script file into a new or
  already existing project.
- New: Reverse engineer a database using a direct native connection to the
  database.
- New: Import an existing database into a subdiagram of an already existing
  project.
- New: Improved trigger and procedures import when importing a SQL script
  file.
- Improved: When importing a SQL script file, data types with spaces in the
  data type name are now imported correctly (for example: CHARACTER
  VARYING).
- New: RECREATE statement is now recognized and treated as a normal CREATE
  statement when importing a SQL script file.
- New: Integrated Smart Relationship Finder. The improved Smart relationship
  finder will be started after reverse engineering a database. It will find
  potential relationships which are not declared in the database.

Forward Engineering
-------------------
See "Target Database Related Changes" for more information regarding the
forward engineering feature for a specific target DBMS.
- New: Added forward engineering support for NexusDB 2, PostgreSQL 8, MS SQL
  Server 2005, Oracle 10g, Firebird 2, MS Access 2003 and MySQL 5.
- New: Define a prefix for all entities. The prefix will be added when the
  tables are generated.
- New: The code to create your database is no longer generated based on
  templates. The definitions of the commands to generate the database are
  now stored in the database definition files.
- New: A data model version is archived automatically when generating your
  database. This archived version describes your physical database and will
  be used to alter your database in a later stadium.
- Improved: Generated drop scripts now contain drop statements for
  constraints also.

Modify Databases (Expert edition)
---------------------------------
See "Target Database Related Changes" for more information regarding the
modify database feature for a specific target DBMS.
- New: Generate intelligent alteration code to modify an existing database
  based on a comparison between two data model version.
- New: A data model version is archived automatically when modifying your
  database. This archived version describes your physical database and will
  be used to alter your database in a later stadium.

Version Control
---------------
- Improved: New Manage versions dialog.
- New: Compare versions of a data model to find differences.
- New: Export an overview of the differences between two versions to a HTML
  file.
- New: Versions are automatically created (optionally) when generating or
  altering your database.
- New: Two types of versions: data dictionary only version and data
  dictionary and diagrams version.
- New: Regenerate the database for an archived data model version.

Miscellaneous
-------------
- Improved: Large files are loaded faster.
- Improved: Improved conversion of autonumber attributes when switching
  target DBMS.
- New: Log file generation when generating, modifying and importing a
  database.
- Improved: Reorder diagrams by dragging the diagram to a new position in
  the Object Browser.
- New: Project's file name is now visible in the Windows taskbar.
- Improved: Easier to use internal code editor with better SQL syntax
  highlighter.
- Improved: View last generated file now can contain multiple files and has
  been renamed to View last generated files.
- New: Generate select, update and insert SQL for an entity. Available
  through the popup menu of an entitybox.
- New: New way of working with non user defined names. The entry field
  for a name may now contain a variable (for example %table%). You can
  quickly select the default template used for a name by selecting it from
  the editable combobox.

2. Target Database Related Changes
----------------------------------

Below you'll find a list of target database specific changes.

Oracle 10g Support
------------------
- Reverse engineer Oracle 10g databases with a direct connection or through
  SQL scripts.
- Generate Oracle 10g databases.
- Alter Oracle 10g databases. Generate intelligent alteration code for
  Oracle 10g databases by comparing two versions of your data model. 
- Compare Oracle 10g data models.

Enhanced Oracle 7,8,9 Support
-----------------------------
In addition to forward engineering (generating) Oracle 7,8 and 9 databases,
DeZign for Databases now also offers:
- Reverse engineer Oracle 7,8,9 databases with a direct connection or through
  SQL scripts.
- Alter Oracle 7,8,9 databases. Generate intelligent alteration code for
  Oracle 7,8,9 databases by comparing two versions of your data model. 
- Compare Oracle 7,8,9 data models.
- Support for Not null constraint names.

MySQL 5 Support
---------------
- Reverse engineer MySQL 5 databases with a direct connection or through SQL
  scripts.
- Generate MySQL 5 databases including triggers, procedures and views.
- Alter MySQL 5 databases. Generate intelligent alteration code for MySQL 5
  databases by comparing two versions of your data model. 
- Compare MySQL 5 data models.

Enhanced MySQL 3,4 Support
--------------------------
In addition to forward engineering (generating) MySQL 3,4 databases, DeZign
for Databases now also offers:
- Reverse engineer MySQL 3,4 databases with a direct connection or through
  SQL scripts.
- Alter MySQL 3,4 databases. Generate intelligent alteration code for MySQL
  3,4 databases by comparing two versions of your data model. 
- Compare MySQL 3,4 data models.

PostgreSQL 8 Support
--------------------
- Reverse engineer PostgreSQL 8 databases through SQL scripts.
- Generate PostgreSQL 8 databases.
- Compare PostgreSQL 8 data models.

Enhanced PostgreSQL 7 Support
-----------------------------
In addition to forward engineering (generating) PostgreSQL 7 databases,
DeZign for Databases now also offers:
- Reverse engineer PostgreSQL 7 databases through SQL scripts.
- Compare PostgreSQL 7 data models.
- Support for Not null constraint names.

Firebird 2 Support
------------------
- Reverse engineer Firebird 2 databases with a direct connection or through
  SQL scripts.
- Generate Firebird 2 databases.
- Alter Firebird 2 databases. Generate intelligent alteration code for
  Firebird 2 databases by comparing two versions of your data model. 
- Compare Firebird 2 data models.

Enhanced Firebird 1.5 Support
-----------------------------
In addition to forward engineering (generating) Firebird 1.5 databases,
DeZign for Databases now also offers:
- Reverse engineer Firebird 1.5 databases with a direct connection or
  through SQL scripts.
- Alter Firebird 1.5 databases. Generate intelligent alteration code for
  Firebird 1.5 databases by comparing two versions of your data model. 
- Compare Firebird 1.5 data models.
- Character sets, blob subtypes and segment sizes supported.
- Collations support.
- RECREATE TABLE recognized by the SQL parser.

Enhanced InterBase 5,6,7 Support
--------------------------------
In addition to forward engineering (generating) InterBase 5,6,7 databases,
DeZign for Databases now also offers:
- Reverse engineer InterBase 5,6,7 databases with a direct connection or
  through SQL scripts.
- Alter InterBase 5,6,7 databases. Generate intelligent alteration code for
  InterBase 5,6,7 databases by comparing two versions of your data model. 
- Compare InterBase 5,6,7 data models.
- Character sets, blob subtypes and segment sizes supported.
- Collations support.

MS SQL Server 2005 Support
--------------------------
- Reverse engineer MS SQL Server 2005 databases with a direct connection or
  through SQL scripts.
- Generate MS SQL Server 2005 databases.
- Alter MS SQL Server 2005 databases. Generate intelligent alteration code
  for MS SQL Server 2005 databases by comparing two versions of your data
  model. 
- Compare MS SQL Server 2005 data models.

Enhanced MS SQL Server 6.5,7,2000 Support
-----------------------------------------
In addition to forward engineering (generating) MS SQL Server 6.5,7,2000
databases, DeZign for Databases now also offers:
- Reverse engineer MS SQL Server 6.5,7,2000 databases with a direct
  connection or through SQL scripts.
- Alter MS SQL Server 6.5,7,2000 databases. Generate intelligent alteration
  code for MS SQL Server 6.5,7,2000 databases by comparing two versions of
  your data model. 
- Compare MS SQL Server 6.5,7,2000 data models.
- Support for Not null constraint names.
- Support for Default constraint names.

MS Access 2003 Support
----------------------
- Reverse engineer MS Access 2003 databases with an ADO connection.
- Generate MS Access 2003 databases.
- Alter MS Access 2003 databases.
- Compare MS Access 2003 data models.

Enhanced MS Access 95,97,2000 Support
-------------------------------------
In addition to forward engineering (generating) MS Access 95,97,2000
databases, DeZign for Databases now also offers:
- Reverse engineer MS Access 95,97,2000 databases with an ADO connection.
- Alter MS Access 95,97,2000 databases by comparing two versions of your
  data model. 
- Compare MS Access 95,97,2000 data models.

Enhanced DB2 Universal DB 7,8 Support
-------------------------------------
In addition to forward engineering (generating) DB2 Universal DB 7,8
databases, DeZign for Databases now also offers:
- Reverse engineer DB2 Universal DB 7,8 databases through SQL scripts.
- Compare DB2 Universal DB 7,8 data models.
- Support for Not null constraint names.
- Support for Default constraint names.

Enhanced Sybase 11,12 Support
-----------------------------
In addition to forward engineering (generating) Sybase 11,12 databases,
DeZign for Databases now also offers:
- Reverse engineer Sybase 11,12 databases through SQL scripts.
- Compare Sybase 11,12 data models.
- Support for Not null constraint names.
- Support for Default constraint names.

Enhanced Pervasive 8,9 Support
------------------------------
In addition to forward engineering (generating) Pervasive 8,9 databases,
DeZign for Databases now also offers:
- Reverse engineer Pervasive 8,9 databases through SQL scripts.
- Compare Pervasive 8,9 data models.

Enhanced Informix 9 Support
---------------------------
In addition to forward engineering (generating) Informix 9 databases, DeZign
for Databases now also offers:
- Reverse engineer Informix 9 databases through SQL scripts.
- Compare Informix 9 data models.

Enhanced MaxDB Support
----------------------
In addition to forward engineering (generating) MaxDB databases, DeZign for
Databases now also offers:
- Reverse engineer MaxDB databases through SQL scripts.
- Compare MaxDB data models.

Enhanced DBISAM 3,4 Support
---------------------------
In addition to forward engineering (generating) DBISAM 3,4 databases, DeZign
for Databases now also offers:
- Reverse engineer DBISAM 3,4 databases with a direct connection.

Enhanced dBase Support
----------------------
In addition to forward engineering (generating) dBase databases, DeZign for
Databases now also offers:
- Reverse engineer dBase databases with a direct connection.
- A new and more reliable database connectivity component is used to connect
  to dBase tables. The BDE is not used anymore to connect to dBase tables.

Enhanced Clipper Support
------------------------
In addition to forward engineering (generating) Clipper databases, DeZign
for Databases now also offers:
- Reverse engineer Clipper databases with a direct connection.
- A new and more reliable database connectivity component is used to connect
  to Clipper tables.

Enhanced FoxPro Support
-----------------------
In addition to forward engineering (generating) FoxPro databases, DeZign for
Databases now also offers:
- Reverse engineer FoxPro databases with a direct connection.
- A new and more reliable database connectivity component is used to connect
  to FoxPro tables.

Enhanced Paradox Support
------------------------
In addition to forward engineering (generating) Paradox databases, DeZign
for Databases now also offers:
- Reverse engineer Paradox databases with a direct connection.

NexusDB 2 Support
-----------------
- Reverse engineer NexusDB 2 databases with a direct connection.
- Generate NexusDB 2 databases including triggers, procedures and views.

Enhanced NexusDB 1 Support
--------------------------
In addition to forward engineering (generating) NexusDB 1 databases, DeZign
for Databases now also offers:
- Reverse engineer NexusDB 1 databases with a direct connection.


=======================================================
Unless otherwise noted, all materials provided in this
release are Copyright 1999 - 2006 by DATANAMIC.
=======================================================
DATANAMIC
Ir Driessenstraat 94F
2312 KZ Leiden
The Netherlands
tel: +31 71-5140901
fax: +31 71-5143593
http://www.datanamic.com
======================= END ===========================


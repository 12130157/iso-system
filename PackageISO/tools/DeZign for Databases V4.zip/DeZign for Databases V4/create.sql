# ---------------------------------------------------------------------- #
# Script generated with: DeZign for Databases v4.1.3                     #
# Target DBMS:           MySQL 4                                         #
# Project file:          dethinghe.dez                                   #
# Project name:                                                          #
# Author:                                                                #
# Script type:           Database creation script                        #
# Created on:            2010-01-30 15:07                                #
# ---------------------------------------------------------------------- #


# ---------------------------------------------------------------------- #
# Tables                                                                 #
# ---------------------------------------------------------------------- #

# ---------------------------------------------------------------------- #
# Add table "Employers"                                                  #
# ---------------------------------------------------------------------- #

CREATE TABLE Employers (
    Title VARCHAR(5) NOT NULL,
    FirstName VARCHAR(30) NOT NULL,
    LastName VARCHAR(30) NOT NULL,
    Company VARCHAR(40) NOT NULL,
    Phone VARCHAR(20) NOT NULL,
    Fax VARCHAR(20),
    Cell VARCHAR(40),
    Email VARCHAR(40) NOT NULL,
    Street VARCHAR(40) NOT NULL,
    City VARCHAR(40) NOT NULL,
    Province VARCHAR(40),
    Hiddenfield VARCHAR(40),
    Password VARCHAR(40) NOT NULL,
    CONSTRAINT PK_Employers PRIMARY KEY (Email)
);

# ---------------------------------------------------------------------- #
# Add table "Candidates"                                                 #
# ---------------------------------------------------------------------- #

CREATE TABLE Candidates (
    Title VARCHAR(5) NOT NULL,
    FirstName VARCHAR(30) NOT NULL,
    LastName VARCHAR(30) NOT NULL,
    Company VARCHAR(40) NOT NULL,
    Phone VARCHAR(20) NOT NULL,
    Fax VARCHAR(20),
    Cell VARCHAR(40),
    Email VARCHAR(40) NOT NULL,
    Street VARCHAR(40) NOT NULL,
    City VARCHAR(40) NOT NULL,
    Province VARCHAR(40),
    Hiddenfield VARCHAR(40),
    Password VARCHAR(40) NOT NULL,
    CONSTRAINT PK_Candidates PRIMARY KEY (Email)
);

# ---------------------------------------------------------------------- #
# Add table "JobList"                                                    #
# ---------------------------------------------------------------------- #

CREATE TABLE JobList (
    Job_id INTEGER NOT NULL,
    JobName VARCHAR(40),
    Cat_id INTEGER NOT NULL,
    CONSTRAINT PK_JobList PRIMARY KEY (Job_id, Cat_id)
);

# ---------------------------------------------------------------------- #
# Add table "JobCategory"                                                #
# ---------------------------------------------------------------------- #

CREATE TABLE JobCategory (
    Cat_id INTEGER NOT NULL,
    CategoryName VARCHAR(40) NOT NULL,
    CONSTRAINT PK_JobCategory PRIMARY KEY (Cat_id)
);

# ---------------------------------------------------------------------- #
# Add table "Jobs"                                                       #
# ---------------------------------------------------------------------- #

CREATE TABLE Jobs (
    CV BLOB,
    JobApplication BLOB,
    sercure VARCHAR(40),
    Job_id INTEGER NOT NULL,
    Cat_id INTEGER NOT NULL,
    Email VARCHAR(40) NOT NULL,
    CONSTRAINT PK_Jobs PRIMARY KEY (Job_id, Cat_id, Email)
);

# ---------------------------------------------------------------------- #
# Foreign key constraints                                                #
# ---------------------------------------------------------------------- #

ALTER TABLE JobList ADD CONSTRAINT JobCategory_JobList 
    FOREIGN KEY (Cat_id) REFERENCES JobCategory (Cat_id);

ALTER TABLE Jobs ADD CONSTRAINT JobList_Jobs 
    FOREIGN KEY (Job_id, Cat_id) REFERENCES JobList (Job_id,Cat_id);

ALTER TABLE Jobs ADD CONSTRAINT Candidates_Jobs 
    FOREIGN KEY (Email) REFERENCES Candidates (Email);
